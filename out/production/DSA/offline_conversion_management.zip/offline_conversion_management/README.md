Offline Conversions

API doc http://localhost:8080/swagger-ui/#/

##### Todo
Endpoints
1. ~~Config~~
2. Create
3. Update
4. UpdateStatus
5. Index
6. History

