/*
Reference:
 - http://p.internal.media.net/w/sem/sre/ecs_plugin_v2/
*/

def constants = [:]


/*production*/
constants["ecsProdClusterName"] = "SEM-NV-ECS"
constants["productionBranch"] = "release"
constants["ecsProdFamily"] = "sem-offline-conv-mgmt"
constants["ecsProdServiceName"] = "sem-offline-conv-mgmt"
constants["ecsProdDesiredCountInteger"] = 2
constants['ecsProdCreateServiceElb'] =  "true"
constants['ecsProdCreateServiceElbName'] =  "sem-nv-ecs-internal-1"
constants['ecsProdCreateServiceElbTargetGroupName'] =  "sem-offline-conv-mgmt"
constants['ecsProdCreateServiceElbPortsMappingIntegerArray'] = [80]
constants['ecsProdCreateServiceElbDomainsToRegisterStringArray'] = ["api.offline-conv-mgmt.app.sem.infra","offline-conv-mgmt.api.gizmo.app.sem.infra"]
constants["dockerfileProdPath"] = "./deploy/dockerfile.production"
constants["ecsProdMemoryReservationForTaskInteger"] = 2500
constants["ecsProdMemoryForTask"] = "3072"



/*staging*/

constants["ecsStageClusterName"] = "SEM-NV-ECS-STAGE"
constants["stagingBranch"] = "master"
constants["ecsStageFamily"] = "sem-stg-offline-conv-mgmt"
constants["ecsStageServiceName"] = "sem-stg-offline-conv-mgmt"
constants["ecsStageDesiredCountInteger"] = 1
constants['ecsStageCreateServiceElb'] =  "true"
constants['ecsStageCreateServiceElbName'] =  "sem-nv-ecs-stage-1"
constants['ecsStageCreateServiceElbTargetGroupName'] =  "sem-stg-offline-conv-mgmt"
constants['ecsStageCreateServiceElbPortsMappingIntegerArray'] = [80]
constants['ecsStageCreateServiceElbDomainsToRegisterStringArray'] = ["api.offline-conv-mgmt.stage.sem.infra","offline-conv-mgmt.api.gizmo.stage.sem.infra"]
constants["dockerfileStagePath"] = "./deploy/dockerfile.staging"
constants["ecsStageMemoryReservationForTaskInteger"] = 2500
constants["ecsStageMemoryForTask"] = "3072"

constants['flockWebhook'] = "https://webhook-app.sem.nv.reports.mn/api/v1/flock/c5410ad8-4a08-446b-8538-0847acfc7ecf"
constants["ecsContainerPortInteger"] = 8080
constants['ecsCreateTargetGroupHealthCheckPath'] = "/health"
constants["ecrRepoName"] = "sem-offline-conv-mgmt"

return constants