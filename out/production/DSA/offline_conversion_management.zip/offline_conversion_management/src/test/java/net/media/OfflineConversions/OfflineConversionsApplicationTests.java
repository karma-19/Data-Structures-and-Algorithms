package net.media.OfflineConversions;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OfflineConversionsApplicationTests {

	@Test
	void contextLoads() {
	}

}
