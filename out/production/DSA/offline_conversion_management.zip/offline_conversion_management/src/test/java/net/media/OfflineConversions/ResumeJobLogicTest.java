package net.media.OfflineConversions;

import net.media.OfflineConversions.enums.SchedulerFreq;
import net.media.OfflineConversions.schedulers.TimeLogic;
import org.junit.jupiter.api.Test;
import org.springframework.util.Assert;

import java.text.ParseException;

public class ResumeJobLogicTest {

//    @Test
//    public void testResumeJobLogic() throws ParseException {
//        String endTime = TimeLogic.getResumeJobDataEndTime("20210803",SchedulerFreq.DAILY);
//        Assert.isTrue(endTime.equals("20210804") ,"Failed");
//
//        endTime = TimeLogic.getResumeJobDataEndTime("20210805",SchedulerFreq.DAILY);
//        Assert.isTrue(endTime.equals("20210805") ,"Failed");
//
//        endTime = TimeLogic.getResumeJobDataEndTime("2021080300",SchedulerFreq.HOURLY);
//        Assert.isTrue(endTime.equals("2021080601") ,"Failed");
//
//        endTime = TimeLogic.getResumeJobDataEndTime("2021080605",SchedulerFreq.HOURLY);
//        Assert.isTrue(endTime.equals("2021080605") ,"Failed");
//
//    }
}
