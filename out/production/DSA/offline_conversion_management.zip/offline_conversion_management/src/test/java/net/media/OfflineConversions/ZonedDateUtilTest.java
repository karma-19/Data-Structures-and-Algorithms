package net.media.OfflineConversions;

import net.media.OfflineConversions.utils.DateFormats;
import net.media.OfflineConversions.utils.ZonedDateUtil;
import net.media.OfflineConversions.enums.SchedulerFreq;
import org.springframework.util.Assert;

import java.text.ParseException;
import java.time.ZonedDateTime;

public class ZonedDateUtilTest {

    //@Test
    public void testHourlyFormat() throws ParseException {
        String testTime = "20200506";
        //ZonedDateTime zonedDateTime1 = ZonedDateUtil.getDateFromString(testTime, DateTimeFormatter.ofPattern("yyyyMMdd"));
        ZonedDateTime zonedDateTime = ZonedDateUtil.getDateFromString(testTime, DateFormats.getFormatter());
        String result = ZonedDateUtil.getStringFromDate(zonedDateTime,DateFormats.getFormat(SchedulerFreq.HOURLY));
        Assert.isTrue(testTime.equals(result) ,"Failed");
    }
    //@Test
    public void testDailyFormat() throws ParseException {
        String testTime = "2021061322";
        ZonedDateTime zonedDateTime = ZonedDateUtil.getDateFromString(testTime, DateFormats.getFormatter());
        String result = ZonedDateUtil.getStringFromDate(zonedDateTime,DateFormats.getFormat(SchedulerFreq.DAILY));
        Assert.isTrue(testTime.equals(result) ,"Failed");
    }
}
