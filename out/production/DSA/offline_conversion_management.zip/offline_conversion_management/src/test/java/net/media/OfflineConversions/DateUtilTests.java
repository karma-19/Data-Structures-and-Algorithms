package net.media.OfflineConversions;

import net.media.OfflineConversions.utils.DateFormats;
import net.media.OfflineConversions.utils.DateUtil;
import org.junit.jupiter.api.Test;
import org.springframework.util.Assert;

import java.text.ParseException;
import java.util.Date;

public class DateUtilTests {
    @Test
    public void testCurrentTime() throws ParseException {
        String dateString = DateUtil.getStringFromDate(DateUtil.getCurrentTime(),"yyyyMMdd00");
        Date date = DateUtil.getDateFromString("2021083000","yyyyMMddHH");
    }
}
