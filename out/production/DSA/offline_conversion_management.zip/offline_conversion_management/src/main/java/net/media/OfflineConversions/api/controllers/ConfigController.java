package net.media.OfflineConversions.api.controllers;

import net.media.OfflineConversions.api.models.response.ConfigResponse;
import net.media.OfflineConversions.api.services.ConfigService;
import net.media.OfflineConversions.exceptions.SPFailedException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class ConfigController {
    ConfigService configService;


    public ConfigController(ConfigService configService) {
        this.configService = configService;
    }

    @GetMapping("/config/read")
    public ResponseEntity<ConfigResponse> readConfig() {
        try {
            return ResponseEntity.ok(configService.read());
        } catch (SPFailedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ConfigResponse.builder().message(e.getMessage()).build());
        }
    }
}
