package net.media.OfflineConversions.schedulers;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.dao.RedisDao;
import net.media.OfflineConversions.enums.JobRunStatus;
import net.media.OfflineConversions.exceptions.SPFailedException;
import net.media.OfflineConversions.jobs.models.GlobalJobContext;
import net.media.OfflineConversions.jobs.models.JobRunContext;
import net.media.OfflineConversions.jobs.models.JobRunDetailsStatus;
import net.media.OfflineConversions.jobs.repository.JobRepository;
import net.media.OfflineConversions.utils.JsonUtil;
import org.springframework.context.ApplicationListener;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

@Slf4j
@Component
//stores the main Map which will be used on Shutdown to call redis and DB
public class ContextHolder implements ApplicationListener<ContextClosedEvent> {
    public static Boolean shutdownInitiated = false;
    private static final Long WAIT_TIME = 5000L;
    private final Map<Thread, Map<Integer, GlobalJobContext>> threadMap = new ConcurrentHashMap<>();
    private final JobRepository jobRepository;
    private final RedisDao redisDao;
    private final RealtimeJobRunService realtimeJobRunService;

    public ContextHolder(JobRepository jobRepository, RedisDao redisDao, RealtimeJobRunService realtimeJobRunService) {
        this.jobRepository = jobRepository;
        this.redisDao = redisDao;
        this.realtimeJobRunService = realtimeJobRunService;
    }

    public void createGlobalJobContext(GlobalJobContext globalJobContext) {
        Integer jobId = globalJobContext.getJob().getId();
        JobRunContext oldContext = redisDao.fetchContextBean(jobId);
        if (oldContext != null) {
            oldContext.setIsCachedData(true);
            globalJobContext.setJobRunContext(oldContext);
        }

        this._setGlobalContextInThreadMap(jobId, globalJobContext);
    }

    private void _setGlobalContextInThreadMap(Integer jobId, GlobalJobContext globalJobContext) {
        Thread currentThread = Thread.currentThread();
        threadMap.computeIfAbsent(currentThread, t -> new ConcurrentHashMap<>()).put(jobId, globalJobContext);
    }

    public void resetJobRunContext(GlobalJobContext globalJobContext) {
        Integer jobId = globalJobContext.getJob().getId();
        log.info("Job Id : {} resetJobRunContext", jobId);

        globalJobContext.resetJobRunContext();
        this._setGlobalContextInThreadMap(jobId, globalJobContext);
    }

    // todo : this needs to be transactional, what if 3rd statement fails
    public void removeGlobalContext(Integer jobId) {
        Thread currentThread = Thread.currentThread();
        threadMap.computeIfAbsent(currentThread, t -> new ConcurrentHashMap<>()).remove(jobId);
        redisDao.deleteContextBean(jobId);
    }

    public void refreshRunDetailsContext(GlobalJobContext globalJobContext) {
        log.info("Job Id : {} refreshRunDetailsContext", globalJobContext.getJob().getId());

        this.removeGlobalContext(globalJobContext.getJob().getId());
        this.resetJobRunContext(globalJobContext);
    }

    public void saveGlobalContext(Integer jobId) {
        Thread currentThread = Thread.currentThread();
        if (threadMap.containsKey(currentThread) && threadMap.get(currentThread).containsKey(jobId)) {
            try {
                log.info("Job Id : {} saveGlobalContext", jobId);
                GlobalJobContext globalJobContext = threadMap.get(currentThread).get(jobId);
                this._processRemainingStepsFromGlobalContext(globalJobContext);
                redisDao.saveContextBean(globalJobContext.getJobRunContext(), jobId);
            } catch (Exception e) {
                log.error("Exception in saveGlobalContext : {}", e.getMessage());
                e.printStackTrace();
            }
        }
        threadMap.computeIfAbsent(currentThread, t -> new ConcurrentHashMap<>()).remove(jobId);
    }

    private boolean _processRemainingStepsFromGlobalContext(GlobalJobContext globalJobContext) throws SPFailedException, JsonProcessingException {
        if (globalJobContext.getJob() != null && globalJobContext.getJobRunDetails() != null) {
            // one slot is completed but update in job run table remaining/failed
            if (globalJobContext.getJobRunContext().getCurrentSlotCompletionStatus() != null &&
                    globalJobContext.getJobRunContext().getCurrentSlotCompletionStatus() &&
                    globalJobContext.getJobRunContext().getCurrentSlotCompletionUpdateStatus() != null &&
                    !globalJobContext.getJobRunContext().getCurrentSlotCompletionUpdateStatus()) {
                System.out.println("Job Id : " + globalJobContext.getJob().getId() + " updating successful slot thread: " + Thread.currentThread());
                boolean updateSlotCompletion = jobRepository.updateSlotCompletion(globalJobContext.getJobRunDetails(),
                        globalJobContext.getSlotConversionResponse(), globalJobContext.getJob(), JobRunStatus.PENDING, globalJobContext.getPreviousRunSlotConversionProcessedCount());
                System.out.println("Job Id : " + globalJobContext.getJob().getId() + " updating successful slot status: " + updateSlotCompletion + " thread: " + Thread.currentThread());
                globalJobContext.getJobRunContext().setCurrentSlotCompletionUpdateStatus(updateSlotCompletion);

                globalJobContext.getJobRunContext().setCurrentConversionIndex(null);
                globalJobContext.getJobRunContext().setCurrentConversionUploadStatus(null);
                return true;
            }
            System.out.println("Job Id : " + globalJobContext.getJob().getId() + " updating partial slot thread: " + Thread.currentThread());
            globalJobContext.getJobRunDetails().setConversion_details(JsonUtil.getJsonNodeFromObject(globalJobContext.getSlotConversionResponse()));
            globalJobContext.getJobRunDetails().setMessage("partial update");
            globalJobContext.getJobRunDetails().setStatus(JobRunDetailsStatus.partial_update);
            if (globalJobContext.getSlotConversionResponse() != null) {
                globalJobContext.getJobRunDetails().setUploadedConversions(globalJobContext.getSlotConversionResponse().getUploadCount());
                globalJobContext.getJobRunDetails().setConversions(globalJobContext.getSlotConversionResponse().getConversionsFromDb());
            }
            return jobRepository.updateJobDetailsAndJobOnFailure(globalJobContext.getJob(), globalJobContext.getJobRunDetails());
        }
        return true;
    }

    private void pushInSortedSet() {
        try {
            if (this.realtimeJobRunService.getStartTimeOfPoppedPair() != null) {
                redisDao.insertJobInRealtimeSortedSet(this.realtimeJobRunService.getJobIdStartTime(), this.realtimeJobRunService.getStartTimeOfPoppedPair());
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("Null pointer occurred while inserting in sorted set. " + this.realtimeJobRunService.getJobIdStartTime());
        }
    }

    private void pushMapInRedis() {
        try {
            if (this.realtimeJobRunService.getPoppedSlotConversionMap() != null) {
                redisDao.insertJobInRealtimeHashMap(this.realtimeJobRunService.getJobIdStartTime(),
                        this.realtimeJobRunService.getPoppedSlotConversionMap());
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("ConversionResponse: " + this.realtimeJobRunService.getPoppedSlotConversionMap() + "Exception occurred while inserting map in redis.");
        }
    }

    @Override
    public void onApplicationEvent(ContextClosedEvent event) {
        System.out.println("Shut Down Initiated");
        shutdownInitiated = true;
        Map<Integer, GlobalJobContext> jobRunDetailsContextMap = new ConcurrentHashMap<>();
        threadMap.values().forEach(jobRunDetailsContextMap::putAll);
        try {
            Thread.sleep(WAIT_TIME);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        jobRunDetailsContextMap.forEach((jobId, globalJobContext) -> {
            boolean redisUpdate = false;
            while (!redisUpdate) {
                try {
                    System.out.println("Job Id : " + jobId + " Before Db update in shutdown");
                    boolean dbUpdateStatus = this._processRemainingStepsFromGlobalContext(globalJobContext);
                    System.out.println("Job Id : " + jobId + " Db update status in shutdown: " + dbUpdateStatus);
                    if (dbUpdateStatus) {
                        System.out.println("Job Id : " + jobId + " Before Redis update in shutdown");
                        redisUpdate = redisDao.saveContextBean(globalJobContext.getJobRunContext(), jobId);
                        System.out.println("Job Id : " + jobId + " Redis update status in shutdown: " + redisUpdate);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    System.out.println("Job Id : " + jobId + " Exception in shutdown" + e.getMessage());
                }
            }
        });

        if (this.realtimeJobRunService.getJobIdStartTime() != null) {
            int poppedJobId = this.realtimeJobRunService.getJobId();
            System.out.println("Job Id : " + poppedJobId + " in Context Holder.");
            try {
                if (this.realtimeJobRunService.isPoppedSlotReadyForDB(this.realtimeJobRunService.getMaxBufferedDataStartTime())) {
                    this.realtimeJobRunService.processAndSavePoppedSlot();
                    System.out.println("Job Id : " + poppedJobId + " processed successfully in Context Holder.");
                } else {
                    this.pushInSortedSet();
                    this.pushMapInRedis();
                    System.out.println("Job Id : " + poppedJobId + " Saved in Redis in Context Holder.");
                }
            } catch (Exception e) {
                System.out.println("Job Id : " + poppedJobId + " Exception on interrupt: " + e.getMessage());
                e.printStackTrace();
                this.pushInSortedSet();
                this.pushMapInRedis();
                System.out.println("Job Id : " + poppedJobId + " ReSaved in Redis in Context Holder.");
            }
        }
    }
}

//SD --> Conversion --> Ho Gya -->
//Redis --> MySQL --> DB --> redis reinitiate

//Redis --> MySQL

//Conversion --> Kafka Poll --> Shutdown --> Kafka will not be commited that time