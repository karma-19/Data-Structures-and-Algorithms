package net.media.OfflineConversions.conversions.repository;


import net.media.OfflineConversions.enums.RevenueSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class LastDateProcessedByIdRepository {
    private final JdbcTemplate semArbJdbcTemplate;
    String maxProcessedSp = "EXEC Get_Last_Buy_Click_ID_Processed_Hour @rev_source_id=%s";
    public static String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

    public LastDateProcessedByIdRepository(@Qualifier("semArbJdbcTemplate") JdbcTemplate semArbJdbcTemplate) {
        this.semArbJdbcTemplate = semArbJdbcTemplate;
    }

    public List<Map<String, String>> getLastDateProcessed(String revenueSourceName) {
        String query = String.format(maxProcessedSp,
                Enum.valueOf(RevenueSource.class, revenueSourceName.toUpperCase()).getRevenueSourceId());
        return semArbJdbcTemplate.query(query, (resultSet, i) -> {
            Map<String, String> row = new HashMap<>();
            row.put("stats", resultSet.getString("stats"));
            row.put("lastRevenueProcessDateTime", resultSet.getString("max_rev_processed_hour"));
            row.put("lastStatsProcessDateTime", resultSet.getString("max_stats_date_hour"));
            return row;
        });
    }
}
