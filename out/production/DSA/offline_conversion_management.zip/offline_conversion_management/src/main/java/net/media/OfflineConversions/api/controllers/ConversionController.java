package net.media.OfflineConversions.api.controllers;


import net.media.OfflineConversions.conversions.models.ConversionRequestBean;
import net.media.OfflineConversions.conversions.ConversionUploadApi;
import org.springframework.http.HttpStatus;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.concurrent.CompletableFuture;


@Validated
@RestController
@CrossOrigin(origins = "*")
public class ConversionController {
    private final ConversionUploadApi conversionUploadApi;

    public ConversionController(ConversionUploadApi conversionUploadApi) {
        this.conversionUploadApi = conversionUploadApi;
    }

    @PostMapping("/conversion/upload")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public void upload(@Valid @RequestBody ConversionRequestBean conversion) {
        CompletableFuture.runAsync(() -> conversionUploadApi.sendAsync(conversion));
    }
}
