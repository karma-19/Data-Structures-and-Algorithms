package net.media.OfflineConversions.conversions.repository;

import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.Conversion;
import net.media.OfflineConversions.conversions.ConversionUploadApi;
import net.media.OfflineConversions.conversions.models.KeywordClickSPResponse;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.utils.DateFormats;
import net.media.OfflineConversions.utils.DateUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class KeywordClickRepository extends ConversionRepository<KeywordClickSPResponse> {

    JdbcTemplate dataSource;
    LastDateProcessedRepository lastDateProcessedRepository;
    String sp = "exec Get_Kwd_log_master_BuySource_Click_id\n" +
            "     @adword_account_id ='%s'\n" +
            "    ,@from_date= '%s' ";

    private static HashMap<String, String> inMemoryDates;

    static {
        inMemoryDates = new HashMap<>();
        inMemoryDates.put("API Response", "2023-05-25 21:00:00.000");
        inMemoryDates.put("GNSU Max Kw Log DateHour", "2023-05-25 21:00:00.000");
        inMemoryDates.put("CS LOG", "2023-05-25 21:00:00.000");
    }

    public KeywordClickRepository(@Qualifier("semArbJdbcTemplate") JdbcTemplate dataSource, LastDateProcessedRepository lastDateProcessedRepository) {
        this.dataSource = dataSource;
        this.lastDateProcessedRepository = lastDateProcessedRepository;
    }

    @Override
    public Date getMaxDateProcessed(String managementGroup) throws ParseException {
        List<Map<String, String>> rows = lastDateProcessedRepository.getLastDateProcessed();
        List<String> dates = new ArrayList<>();
        for (Map<String, String> row : rows) {
            switch (row.get("stats")) {
                case "API Response":
                    String adwdTime = row.get("lastProcessDateTime");
                    if (adwdTime == null) {
                        adwdTime = inMemoryDates.get("API Response");
                        log.info("KeywordClick : Taking Value from inmemory : API Response : {}", adwdTime);
                    } else {
                        inMemoryDates.put("API Response", adwdTime);
                    }
                    dates.add(adwdTime);
                    break;
                case "GNSU Max Kw Log DateHour":
                    String kwdLogTime = row.get("lastProcessDateTime");
                    if (kwdLogTime == null) {
                        kwdLogTime = inMemoryDates.get("GNSU Max Kw Log DateHour");
                        log.info("KeywordClick : Taking Value from inmemory : GNSU Max Kw Log DateHour : {}", kwdLogTime);
                    } else {
                        inMemoryDates.put("GNSU Max Kw Log DateHour", kwdLogTime);
                    }
                    dates.add(kwdLogTime);
                    break;
                case "CS LOG":
                    String csLogTime = row.get("lastProcessDateTime");
                    if (csLogTime == null) {
                        csLogTime = inMemoryDates.get("CS LOG");
                        log.info("KeywordClick : Taking Value from inmemory : CS LOG : {}", csLogTime);
                    } else {
                        inMemoryDates.put("CS LOG", csLogTime);
                    }
                    dates.add(csLogTime);
                    break;
            }
        }
        return DateUtil.getMinDate(dates, LastDateProcessedRepository.DATE_FORMAT);
    }

    @Override
    protected List<KeywordClickSPResponse> getSPResponse(Date start, Date end, Job job, SPRowMapper rowMapper, String revenueSource) {
        String formatStart = "yyyyMMdd HH:00:00";//20210628 00:25:02
        String sql = String.format(sp,
                job.getAccountId(),
                DateUtil.getStringFromDate(start, formatStart)
        );
        return dataSource.query(sql, rowMapper);
    }

    @Override
    protected List<Conversion> transformSPResponseToConversion(List<KeywordClickSPResponse> SPResponse, Job job) {
        return SPResponse.stream()
                .flatMap(it -> this.getConversionsAsPerKwdClicks(it, job).stream())
                .collect(Collectors.toList());
    }

    private List<Conversion> getConversionsAsPerKwdClicks(KeywordClickSPResponse spResponse, Job job) {
        List<Date> conversionTimeList;
        if (job.getSourceName().equals(ConversionUploadApi.FACEBOOK_SOURCE_NAME)) {
            conversionTimeList = DateUtil.getNRandomDates(spResponse.getMinLogTime(), spResponse.getMaxLogTime(),
                    spResponse.getClickCount());
        } else {
            conversionTimeList = Collections.singletonList(spResponse.getStatsDate());
        }

        return conversionTimeList.stream()
                .map(date -> Conversion.builder()
                        .accountId(job.getAccountId())
                        .conversionName(job.getConversionName())
                        .conversionTime(date)
                        .gclid(spResponse.getBuySourceClickId())
                        .param_1(spResponse.getParam1())
                        .param_2(spResponse.getParam2())
                        .logHash(spResponse.getLogHash())
                        .ip(spResponse.getIpAddress())
                        .ua(spResponse.getUserAgent())
                        .url(spResponse.getUrl())
                        .device(spResponse.getDevice())
                        .testDataDevice(spResponse.getTestDataDevice())
                        .build())
                .collect(Collectors.toList());
    }

    @Override
    protected KeywordClickSPResponse rowMapperFunction(ResultSet resultSet) throws SQLException, ParseException {
        return KeywordClickSPResponse.builder()
                .statsDate(DateUtil.getDateFromString(resultSet.getString("log_datetime"), DateFormats.CONVERSION_SP_DATE_FORMAT))//2021-09-02 10:16:13.000
                .minLogTime(DateUtil.getDateFromString(resultSet.getString("min_log_time"), DateFormats.CONVERSION_SP_DATE_FORMAT))//2021-09-02 10:16:13.000
                .maxLogTime(DateUtil.getDateFromString(resultSet.getString("max_log_time"), DateFormats.CONVERSION_SP_DATE_FORMAT))//2021-09-02 10:16:13.000
                .accountId(resultSet.getString("adword_account_id"))
                .buySourceClickId(resultSet.getString("buy_source_click_id"))
                .logHash(resultSet.getString("log_hash"))
                .param1(resultSet.getString("param_1"))
                .param2(resultSet.getString("param_2"))
                .userAgent(resultSet.getString("user_agent"))
                .ipAddress(resultSet.getString("ip_address"))
                .url(resultSet.getString("site_request_url"))
                .device(resultSet.getString("device"))
                .testDataDevice(resultSet.getString("test_data_device"))
                .clickCount(resultSet.getInt("kw_clicks"))
                .build();
    }

}
