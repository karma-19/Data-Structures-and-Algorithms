package net.media.OfflineConversions.api.models.response;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;
import net.media.OfflineConversions.enums.JobStatus;
import net.media.OfflineConversions.enums.JobType;
import net.media.OfflineConversions.jobs.models.ConversionTypeDetails;
import net.media.OfflineConversions.jobs.models.ManagementGroupNameId;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@Data
@SuperBuilder
public class ConfigResponse extends BaseResponse {
    List<ConversionTypeDetails> conversionTypes;
    List<ManagementGroupNameId> managementGroupNameIds;
    List<JobType> jobTypes;
    List<JobStatus> jobStatuses;
}
