package net.media.OfflineConversions.jobs.models;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.Builder;
import lombok.Data;
import net.media.OfflineConversions.enums.*;

@Data
@Builder
public class Job {
    Integer id;
    String accountId;
    String accountName;
    int conversionTypeId;
    String conversionName;
    ConversionType conversionType;
    SchedulerFreq schedulerFrequency;
    String scheduledTime;
    String successfulRunTime;
    String dataStartTime;
    String dataEndTime;
    JsonNode additionalData;
    JsonNode testData;
    JobStatus status;
    JobRunStatus jobRunStatus;
    int createdBy;
    String createdByUser;
    int modifiedBy;
    String modifiedByUser;
    String createdTime;
    String modifiedTime;

    int managementGroupId;
    int sourceId;
    String sourceName;
    String managementGroup;
    JobType jobType;
    Boolean skipTablet;
    String pixelId;
}
