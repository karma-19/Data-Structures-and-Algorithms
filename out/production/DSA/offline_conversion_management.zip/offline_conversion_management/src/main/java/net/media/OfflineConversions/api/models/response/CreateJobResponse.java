package net.media.OfflineConversions.api.models.response;

import lombok.Data;
import lombok.experimental.SuperBuilder;
import net.media.OfflineConversions.jobs.models.Job;

import java.util.List;

@SuperBuilder
@Data
public class CreateJobResponse extends BaseResponse {
    List<Job> alreadyExistingJobs;
    List<String> inValidAccountIds;
}
