package net.media.OfflineConversions.conversions;

import com.fasterxml.jackson.databind.JsonNode;

public enum ConversionApiResponse {
    SUCCESS, INVALID_CLICK, UNPARSEABLE_CLICK_ID, TOO_RECENT, DUPLICATE, UNKNOWN_ERROR, EXPIRED, FILTERED;

    public static ConversionApiResponse getError(int sourceId, JsonNode responseBody) {
        if (responseBody.get("message").asText().contains("OfflineConversionError.INVALID_CLICK")) {    // it is coming from AdminApi as error not from buy source
            return ConversionApiResponse.INVALID_CLICK;
        } else if (sourceId == 1) {
            return ConversionApiResponse.getGoogleError(responseBody.get("error_code").asText());
        } else {
            return ConversionApiResponse.getGenericError(responseBody.get("message").asText());
        }
    }

    private static ConversionApiResponse getGoogleError(String googleErrorCode) {
        switch (googleErrorCode) {
            case "EXPIRED_EVENT":
            case "EXPIRED_CALL":
                return EXPIRED;
            case "TOO_RECENT_EVENT":
            case "TOO_RECENT_CALL":
            case "TOO_RECENT_CONVERSION_ACTION":
                return TOO_RECENT;
            case "UNPARSEABLE_GCLID":
                return UNPARSEABLE_CLICK_ID;
            case "CLICK_CONVERSION_ALREADY_EXISTS":
            case "CALL_CONVERSION_ALREADY_EXISTS":
            case "DUPLICATE_CLICK_CONVERSION_IN_REQUEST":
            case "DUPLICATE_CALL_CONVERSION_IN_REQUEST":
                return DUPLICATE;
        }
        return UNKNOWN_ERROR;
    }

    private static ConversionApiResponse getGenericError(String message) {
        if (message.toUpperCase().contains("EVENT TIMESTAMP TOO OLD")) {
            return ConversionApiResponse.EXPIRED;
        } else if (message.contains("could not be decoded")) {
            return ConversionApiResponse.UNPARSEABLE_CLICK_ID;
        } else if (message.contains("occurred less than 6 hours ago, please retry after 6 hours have passed")) {
            return ConversionApiResponse.TOO_RECENT;
        }
        return UNKNOWN_ERROR;
    }

}
