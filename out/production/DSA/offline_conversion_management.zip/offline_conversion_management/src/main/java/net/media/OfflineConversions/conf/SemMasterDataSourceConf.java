package net.media.OfflineConversions.conf;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class SemMasterDataSourceConf {

    @Bean
    @RefreshScope
    @ConfigurationProperties("app.datasource.sem-master")
    public DataSourceProperties semMasterMemberDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean
    @RefreshScope
    @ConfigurationProperties("app.datasource.sem-master.configuration")
    @Qualifier("semMasterDataSourceHikari")
    public HikariDataSource semMasterDatasourceHikari() {
        return semMasterMemberDataSourceProperties().initializeDataSourceBuilder()
                .type(HikariDataSource.class).build();
    }

    @Bean
    @RefreshScope
    @Qualifier("semMasterJdbcTemplate")
    public JdbcTemplate semMasterJdbcTemplate(@Qualifier("semMasterDataSourceHikari") HikariDataSource hikariDataSource) {
        return new JdbcTemplate(hikariDataSource);
    }
}
