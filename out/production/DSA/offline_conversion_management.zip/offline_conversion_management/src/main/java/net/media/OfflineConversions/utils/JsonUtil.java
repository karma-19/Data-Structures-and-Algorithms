package net.media.OfflineConversions.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

@Slf4j
public class JsonUtil {

    private static final ObjectMapper objectMapper = new ObjectMapper();
    private static final ObjectMapper objectMapperSnakeCase = new ObjectMapper().setPropertyNamingStrategy(PropertyNamingStrategies.SNAKE_CASE);

    public static Map<String, String> convertObjectToMap(Object object) {
        Map<String, String> resultMap = new HashMap<>();
        try {
            Map<?, ?> objectAsMap = objectMapper.convertValue(object, Map.class);
            objectAsMap.forEach((key, value) -> {
                resultMap.put(String.valueOf(key), String.valueOf(value));
                // since redis template is <String, String> it is converting Integer to String
                //and throwing ClassCastException on inserting Map<String, Long or Integer> in redis
            });
        } catch (Exception e) {
            log.warn("Error while converting object to map: {} {}", object, e);
            throw e;
        }
        return resultMap;
    }

    public static Map<String, Long> convertObjectToLongMap(Object object) {
        Map<String, Long> resultMap = new HashMap<>();
        try {
            Map<?, ?> objectAsMap = objectMapper.convertValue(object, Map.class);
            objectAsMap.forEach((key, value) -> {
                resultMap.put(String.valueOf(key), Long.parseLong(String.valueOf(value)));
            });
        } catch (Exception e) {
            log.warn("Error while converting object to map: {} {}", object, e);
            throw e;
        }
        return resultMap;
    }

    public static boolean isNullOrEmpty(JsonNode json, String key) {
        if (isNullOrEmpty(json) || !json.hasNonNull(key)) {
            return true;
        }
        return isNullOrEmpty(json.get(key));
    }


    private static boolean isNullOrEmpty(JsonNode field) {
        if (field == null || field.isNull()) {
            return true;
        }
        if (field.isTextual()) {
            // field is an empty string
            return field.asText().isEmpty();
        } else if (field.isArray() || field.isObject()) {
            // field is an empty array or empty json object
            return field.isEmpty();
        }
        return false;
    }

    public static JsonNode getJsonNodeFromObject(Object object) {
        return objectMapper.valueToTree(object);
    }

    public static JsonNode getJsonNodeFromString(String string) throws JsonProcessingException {
        return objectMapper.readTree(string);
    }

    @SuppressWarnings("rawtypes")
    public static Object getObjectFromJsonNode(JsonNode jsonNode, Class object) throws JsonProcessingException {
        return objectMapper.treeToValue(jsonNode, object);
    }

    public static String getValueAsString(Object object) throws JsonProcessingException {
        return objectMapper.writeValueAsString(object);
    }

    public static String getValueAsSnakeCaseString(Object object) throws JsonProcessingException {
        return objectMapperSnakeCase.writeValueAsString(object);
    }

    public static ObjectNode getObjectNode() {
        return objectMapper.createObjectNode();
    }

    public static String getJsonFieldAsString(JsonNode json, String field) {
        JsonNode currentElement = json.get(field);
        if (currentElement == null || currentElement.isNull()) {
            return null;
        }
        return currentElement.asText();
    }

    public static Long getJsonFieldAsLong(JsonNode json, String field) {
        long jsonField;
        try {
            jsonField = Long.parseLong(Objects.requireNonNull(getJsonFieldAsString(json, field)));
        } catch (NullPointerException e) {
            return null;
        } catch (NumberFormatException e) {
            jsonField = 0L;
        }
        return jsonField;
    }

    public static Integer getJsonFieldAsInt(JsonNode json, String field) {
        int jsonField;
        try {
            jsonField = Integer.parseInt(Objects.requireNonNull(getJsonFieldAsString(json, field)));
        } catch (NullPointerException e) {
            return null;
        } catch (NumberFormatException e) {
            jsonField = 0;
        }
        return jsonField;
    }
}

