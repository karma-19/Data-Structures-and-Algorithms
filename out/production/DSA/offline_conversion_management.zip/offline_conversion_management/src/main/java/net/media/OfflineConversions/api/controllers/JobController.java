package net.media.OfflineConversions.api.controllers;

import com.fasterxml.jackson.core.JsonProcessingException;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.api.models.requests.*;
import net.media.OfflineConversions.api.models.response.*;
import net.media.OfflineConversions.api.services.ConfigService;
import net.media.OfflineConversions.api.services.JobService;
import net.media.OfflineConversions.exceptions.SPFailedException;
//import net.media.sem.JwtToken.model.User;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.io.IOException;
import java.text.ParseException;
import java.util.List;
import java.util.stream.Collectors;

@Slf4j
@Validated
@RestController
@CrossOrigin(origins = "*")
public class JobController {
    JobService jobService;
    ConfigService configService;

    public JobController(JobService jobService, ConfigService configService) {
        this.jobService = jobService;
        this.configService = configService;
    }

    @PostMapping(value = "/job/create", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Job created successfully"),
            @ApiResponse(code = 400, message = "Job already exists or Invalid AccountId")
    })
    public ResponseEntity<CreateJobResponse> create(@RequestBody @Valid List<CreateJobRequest> requestList, @RequestAttribute("user") User user) {
        try {
            if (!configService.isConfigValid(requestList.stream().map(CreateJobRequest::getConversionTypeId).collect(Collectors.toList()))) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(CreateJobResponse.builder().message("Invalid ConversionTypeIds").build());
            }
            configService.addSchedulerFreq(requestList);
            //TODO: temp code regarding pixel id to be removed
            requestList.forEach(jobService::populatePixelId);
            String accountToErrorMsg = jobService.validateSourceSpecificAdditionalData(requestList);
            if (accountToErrorMsg != null && !accountToErrorMsg.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(CreateJobResponse.builder().message(accountToErrorMsg).build());
            }

            accountToErrorMsg = jobService.validateJobsConstraints(requestList);
            if (accountToErrorMsg != null && !accountToErrorMsg.isEmpty()) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(CreateJobResponse.builder().message(accountToErrorMsg).build());
            }

            CreateJobResponse createJobResponse = jobService.create(requestList, user.getId());
            if (createJobResponse.getAlreadyExistingJobs() == null
                    && createJobResponse.getInValidAccountIds() == null
            ) {
                return ResponseEntity.ok(createJobResponse);
            }
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(createJobResponse);
        } catch (SPFailedException | IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(CreateJobResponse.builder().message(e.getMessage()).build());
        }
    }

    @PostMapping("/job/update")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Job updated successfully"),
            @ApiResponse(code = 400, message = "All Jobs don't exist")
    })
    public ResponseEntity<UpdateJobResponse> update(@Valid @RequestBody List<UpdateJobRequest> requestList, @RequestAttribute("user") User user) throws JsonProcessingException {
        try {
            //TODO: temp code regarding pixel id to be removed
            requestList.forEach(jobService::populatePixelId);
            UpdateJobResponse updateJobResponse = jobService.update(requestList, user.getId());
            if (updateJobResponse.getMissingJobs() == null && updateJobResponse.getNewDuplicateJobs() == null) {
                return ResponseEntity.ok(UpdateJobResponse.builder().message("Job updated successfully").build());
            }
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(updateJobResponse);
        } catch (SPFailedException | ParseException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(UpdateJobResponse.builder().message(e.getMessage()).build());
        }
    }

    @PostMapping("/job/updateStatus")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Job status updated successfully"),
            @ApiResponse(code = 400, message = "All Jobs don't exist")
    })
    public ResponseEntity<UpdateJobResponse> updateStatus(@Valid @RequestBody UpdateJobStatusRequest request, @RequestAttribute("user") User user) throws JsonProcessingException {
        try {
            UpdateJobResponse updateJobResponse = jobService.updateJobStatus(request, user.getId());
            if (updateJobResponse.getMissingJobs() == null) {
                return ResponseEntity.ok(updateJobResponse);
            }
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(updateJobResponse);
        } catch (SPFailedException | ParseException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(UpdateJobResponse.builder().message(e.getMessage()).build());
        }
    }

    @PostMapping("/job/index")
    public ResponseEntity<JobInterfaceResponse> index(@Valid @RequestBody GetJobRequest request, @RequestAttribute("user") User user) {
        try {
            return ResponseEntity.ok(jobService.getJobForInterface(request, user.getId()));
        } catch (SPFailedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(JobInterfaceResponse.builder().message(e.getMessage()).build());
        }
    }

    @GetMapping("/job/history")
    public ResponseEntity<JobHistoryResponse> getJobHistory(@RequestParam int jobId, @RequestParam int start, @RequestParam int end) throws JsonProcessingException {
        try {
            return ResponseEntity.ok(
                    JobHistoryResponse.builder()
                            .jobHistoryList(jobService.getJobHistory(jobId, start, end))
                            .build());
        } catch (SPFailedException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(JobHistoryResponse.builder().message(e.getMessage()).build());
        }
    }

    // if job is already running, suspended or doesn't exist, logging on server side but giving success on client response
    @PostMapping("/job/priority")
    public ResponseEntity<BaseResponse> run(@RequestParam Integer jobId, @RequestAttribute("user") User user) {
        try {
            log.info("Job Id : {} : Run Job on Priority", jobId);
            boolean successStatus = jobService.enqueueForPriorityProcessing(jobId, user.getId());
            if (!successStatus) {
                return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(BaseResponse.builder().message("Job Id : " + jobId + " Priority running Request failed.").build());
            }
            return ResponseEntity.ok(BaseResponse.builder().message("Job Id : " + jobId + " Priority running request has been logged in.").build());
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(BaseResponse.builder().message("Job Id : " + jobId + " Priority running Request failed due to error.").build());
        }
    }
}

//Component --> Repository, Service, Controller
//Bean --> Component


