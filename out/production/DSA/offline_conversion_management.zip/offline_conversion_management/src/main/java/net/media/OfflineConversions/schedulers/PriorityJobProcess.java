package net.media.OfflineConversions.schedulers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.api.models.requests.PriorityJobRequest;
import net.media.OfflineConversions.api.services.JobService;
import net.media.OfflineConversions.dao.RedisDao;
import net.media.OfflineConversions.enums.JobRunType;
import net.media.OfflineConversions.exceptions.SPFailedException;
import net.media.OfflineConversions.jobs.JobExecutorService;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.utils.JsonUtil;
import org.springframework.core.task.TaskExecutor;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Optional;


@Slf4j
@Component
public class PriorityJobProcess {

    private final TaskExecutor taskExecutor;
    private final JobExecutorService jobExecutorService;
    private final RedisDao redisDao;
    private final JobService jobService;
    private static final int MAX_PRIORITY_JOBS = 4;

    public PriorityJobProcess(TaskExecutor taskExecutor,
                              JobExecutorService jobExecutorService,
                              RedisDao redisDao,
                              JobService jobService) {
        this.taskExecutor = taskExecutor;
        this.jobExecutorService = jobExecutorService;
        this.redisDao = redisDao;
        this.jobService = jobService;
    }


    // Job is dequeued from redis queue
    // Get from DB by marking it as running
    // Added to Processing Redis Queue
    // Submit it to JobExecutorService.run
    @Scheduled(fixedDelay = 30 * 60 * 1000, initialDelay = 10 * 60 * 1000) // 30 mins
    public void jobRunOnPriority() throws SPFailedException, JsonProcessingException {
        log.info("Currently Requested Jobs : {} Running Jobs : {}  JobRunOnPriority Started.",
                redisDao.getPriorityJobCount(), redisDao.getPriorityProcessingJobCount());

        while (redisDao.getPriorityProcessingJobCount() < MAX_PRIORITY_JOBS && redisDao.getPriorityJobCount() > 0) {
            Optional<Object> jobRequestDetails = redisDao.dequeuePriorityJob();
            if (jobRequestDetails.isEmpty()) {
                log.warn("Popped Job Request from redis was null");
                continue;
            }

            JsonNode jsonNodeFromString = JsonUtil.getJsonNodeFromString(jobRequestDetails.get().toString());
            PriorityJobRequest priorityJobRequest = (PriorityJobRequest) JsonUtil.getObjectFromJsonNode(jsonNodeFromString, PriorityJobRequest.class);
            Integer jobId = priorityJobRequest.getJobId();
            Integer userId = priorityJobRequest.getUserId();
            if (userId == null || jobId == null) {
                log.warn("Job Id : null User Id : null Job Request Detail : {}", jobRequestDetails.get());
                return;
            }

            Job job;
            try {
                job = jobService.setJobAsProcessingInDbAndRedis(jobId, userId);
                if (job == null) {
                    continue;
                }
            } catch (Exception e) {
                log.warn("Job Id : {}, User Id : {} Exception : {} Exception occurred while setting job in db and redis.",
                        jobId, userId, e.getMessage());
                throw e;
            }

            taskExecutor.execute(() -> {
                this.run(job, userId);
            });
        }
        log.info("Currently Requested Jobs : {} Running Jobs : {}  JobRunOnPriority End.",
                redisDao.getPriorityJobCount(), redisDao.getPriorityProcessingJobCount());
    }

    @Async
    public void run(Job job, int userId) {
        log.info("Job Id : {} User Id : {} Thread : {}", Thread.currentThread().getName(), job.getId(), userId);
        try {
            jobExecutorService.run(job, JobRunType.PRIORITY);
        } catch (Exception e) {
            return;
        }
        log.info("Job Id : {} User Id : {} Job run completed.", job.getId(), userId);
        if (!redisDao.removeJobFromPriorityProcessingQueue(job.getId())) {
            log.warn("Job Id : {} User Id : {} Job not removed from redis.", job.getId(), userId);
        }
    }
}
