package net.media.OfflineConversions.conversions.repository;

import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.Conversion;
import net.media.OfflineConversions.conversions.models.AdClickSPResponse;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.utils.DateFormats;
import net.media.OfflineConversions.utils.DateUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class AdClickRepository extends ConversionRepository<AdClickSPResponse> {

    JdbcTemplate semArbJdbcTemplate;
    LastDateProcessedRepository lastDateProcessedRepository;
    String sp = "exec Get_Buysource_Click_Id\n" +
            "     @adword_account_id ='%s'\n" +
            "    ,@stats_date= '%s',@hour_id= '%s'";

    private static final HashMap<String, String> inMemoryDates;

    static {
        inMemoryDates = new HashMap<>();
        inMemoryDates.put("API Response", "2023-05-25 21:00:00.000");
        inMemoryDates.put("CM Adclick", "2023-05-25 21:00:00.000");
        inMemoryDates.put("CS LOG", "2023-05-25 21:00:00.000");
    }

    public AdClickRepository(@Qualifier("semArbJdbcTemplate") JdbcTemplate semArbJdbcTemplate,
                             LastDateProcessedRepository lastDateProcessedRepository) {
        this.semArbJdbcTemplate = semArbJdbcTemplate;
        this.lastDateProcessedRepository = lastDateProcessedRepository;
    }

    @Override
    public Date getMaxDateProcessed(String managementGroup) throws ParseException {
        List<Map<String, String>> rows = lastDateProcessedRepository.getLastDateProcessed();
        List<String> dates = new ArrayList<>();
        for (Map<String, String> row : rows) {
            switch (row.get("stats")) {
                case "API Response":
                    String adwdTime = row.get("lastProcessDateTime");
                    if (adwdTime == null) {
                        adwdTime = inMemoryDates.get("API Response");
                        log.info("AdClick : Taking Value from inmemory : API Response : {}", adwdTime);
                    } else {
                        inMemoryDates.put("API Response", adwdTime);
                    }
                    dates.add(adwdTime);
                    break;
                case "CM Adclick":
                    String adClickTime = row.get("lastProcessDateTime");
                    if (adClickTime == null) {
                        adClickTime = inMemoryDates.get("CM Adclick");
                        log.info("AdClick : Taking Value from inmemory : CM Adclick : {}", adClickTime);
                    } else {
                        inMemoryDates.put("CM Adclick", adClickTime);
                    }
                    dates.add(adClickTime);
                    break;
                case "CS LOG":
                    String csLogTime = row.get("lastProcessDateTime");
                    if (csLogTime == null) {
                        csLogTime = inMemoryDates.get("CS LOG");
                        log.info("AdClick : Taking Value from inmemory : CS LOG : {}", csLogTime);
                    } else {
                        inMemoryDates.put("CS LOG", csLogTime);
                    }
                    dates.add(csLogTime);
                    break;
            }
        }
        return DateUtil.getMinDate(dates, LastDateProcessedRepository.DATE_FORMAT);
    }

    @Override
    protected List<AdClickSPResponse> getSPResponse(Date start, Date end, Job job, SPRowMapper rowMapper, String revenueSource) {
        String format = "yyyyMMdd";//20210628
        String sql = String.format(sp,
                job.getAccountId(),
                DateUtil.getStringFromDate(start, format),
                DateUtil.getHour(start)
        );
        return semArbJdbcTemplate.query(sql, rowMapper);
    }

    @Override
    protected List<Conversion> transformSPResponseToConversion(List<AdClickSPResponse> SPResponse, Job job) {
        return SPResponse.stream().map(adClickSPResponse -> Conversion.builder()
                .accountId(job.getAccountId())
                .conversionName(job.getConversionName())
                .conversionTime(adClickSPResponse.getStatsDate())
                .logHash(adClickSPResponse.getLogHash())
                .gclid(adClickSPResponse.getBuySourceClickId())
                .param_1(adClickSPResponse.getParam1())
                .param_2(adClickSPResponse.getParam2())
                .ip(adClickSPResponse.getIpAddress())
                .ua(adClickSPResponse.getUserAgent())
                .url(adClickSPResponse.getUrl())
                .device(adClickSPResponse.getDevice())
                .testDataDevice(adClickSPResponse.getTestDataDevice())
                .build()
        ).collect(Collectors.toList());
    }

    @Override
    protected AdClickSPResponse rowMapperFunction(ResultSet resultSet) throws SQLException, ParseException {
        return AdClickSPResponse.builder()
                .statsDate(DateUtil.getDateFromString(resultSet.getString("stats_date"), DateFormats.CONVERSION_SP_DATE_FORMAT)) //2021-06-28 11:00:00.000
                .accountId(resultSet.getString("adword_account_id"))
                .buySourceClickId(resultSet.getString("buy_source_click_id"))
                .logHash(resultSet.getString("log_hash"))
                .param1(resultSet.getString("param_1"))
                .param2(resultSet.getString("param_2"))
                .userAgent(resultSet.getString("user_agent"))
                .ipAddress(resultSet.getString("ip_address"))
                .url(resultSet.getString("site_request_url"))
                .device(resultSet.getString("device"))
                .testDataDevice(resultSet.getString("test_data_device"))
                .build();
    }

}
