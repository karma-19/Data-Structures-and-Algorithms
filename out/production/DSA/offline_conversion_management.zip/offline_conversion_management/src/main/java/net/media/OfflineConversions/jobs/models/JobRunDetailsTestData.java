package net.media.OfflineConversions.jobs.models;


import lombok.Builder;
import lombok.Data;
import net.media.OfflineConversions.enums.JobRunType;

@Builder
@Data
public class JobRunDetailsTestData {
    private String newMinStartTime;
    private String newMaxStartTime;
    private String runTimeAsPerDefiniteGap;
    private String bufferedMaxStartTime;
    private JobRunType jobRunType;
    private int slotCount;
}
