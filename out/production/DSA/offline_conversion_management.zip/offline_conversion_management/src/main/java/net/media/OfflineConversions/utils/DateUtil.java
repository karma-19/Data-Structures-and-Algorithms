package net.media.OfflineConversions.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

public class DateUtil {

    public static Date getCurrentTime() {
        return new Date();
    }

    public static Date subtractHours(Date date, int hours) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.HOUR, -hours);
        return c.getTime();
    }

    public static Date subtractSec(Date date, int sec) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.SECOND, -sec);
        return c.getTime();
    }

    public static Date addHours(Date date, int hours) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.HOUR, hours);
        return c.getTime();
    }

    public static Date addSeconds(Date date, int seconds) {
        Calendar c = Calendar.getInstance();
        c.setTime(date);
        c.add(Calendar.SECOND, seconds);
        return c.getTime();
    }

    public static Date getDateFromString(String date, String format) throws ParseException {
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat.parse(date);
    }

    public static Date changeDateFormat(Date date, String toFormat, String fromFormat) throws ParseException {
        String dateString = DateUtil.getStringFromDate(date, fromFormat);
        return DateUtil.getDateFromString(dateString, toFormat);
    }

    public static String getStringFromDate(Date date, String format) {
        SimpleDateFormat dateFormat = new SimpleDateFormat(format);
        return dateFormat.format(date);
    }

    public static String getDayId(Date date, String dayIdFormat) {
        return getStringFromDate(date, dayIdFormat);
    }

    public static int getHour(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.HOUR_OF_DAY);
    }

    public static int getMinute(Date date) {
        Calendar calendar = Calendar.getInstance();
        calendar.setTime(date);
        return calendar.get(Calendar.MINUTE);
    }

    public static Date getMinDate(List<String> dates, String format) throws ParseException, IllegalArgumentException {
        if (dates.isEmpty())
            throw new IllegalArgumentException();
        Date minDate = getDateFromString(dates.get(0), format);
        for (String date : dates) {
            if (getDateFromString(date, format).before(minDate))
                minDate = getDateFromString(date, format);
        }
        return minDate;
    }

    public static Date getMinDate(List<Date> dates) throws IllegalArgumentException {
        if (dates.isEmpty())
            throw new IllegalArgumentException();
        Date minDate = dates.get(0);
        for (Date date : dates) {
            if (date.before(minDate))
                minDate = date;
        }
        return minDate;
    }

    public static List<Date> getDataTimeSlots(Date minStart, Date maxStart, int size) {
        List<Date> dates = new ArrayList<>();
        Date current = minStart;
        while (true) {
            if (current.before(maxStart) || current.equals(maxStart)) {
                dates.add(current);
                current = DateUtil.addHours(current, size);//24 or 1
            } else {
                break;
            }
        }
        return dates;
    }

    public static List<Date> getNRandomDates(Date start, Date end, int count) {
        if (start.after(end)) {
            throw new IllegalArgumentException();
        }

        long timeDifferenceInSeconds = (end.getTime() - start.getTime()) / 1000;

        List<Long> randomTimeDifferenceList = NumberUtil.getNRandomLong(0L, timeDifferenceInSeconds + 1, count);

        return randomTimeDifferenceList.stream()
                .map(time -> DateUtil.addSeconds(start, time.intValue()))
                .collect(Collectors.toList());
    }
}


