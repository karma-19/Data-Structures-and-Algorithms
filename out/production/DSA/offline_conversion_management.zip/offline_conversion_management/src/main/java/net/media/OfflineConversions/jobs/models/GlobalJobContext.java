package net.media.OfflineConversions.jobs.models;

import lombok.Data;

@Data
// Stores Context of current assigned running job
public class GlobalJobContext {
    private JobRunContext jobRunContext = new JobRunContext();
    private Job job;
    private JobRunDetails jobRunDetails;
    private JobRunDetailsTestData jobRunDetailsTestData;
    private ConversionResponse slotConversionResponse;
    private Integer previousRunSlotConversionProcessedCount;

    public GlobalJobContext(Job job) {
        this.job = job;
    }

    public void resetJobRunContext() {
        this.jobRunContext = new JobRunContext();
    }
}
