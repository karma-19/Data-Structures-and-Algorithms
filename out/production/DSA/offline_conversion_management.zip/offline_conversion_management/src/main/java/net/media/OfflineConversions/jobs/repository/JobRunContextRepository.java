package net.media.OfflineConversions.jobs.repository;

import net.media.OfflineConversions.jobs.models.JobRunContext;
import org.springframework.data.repository.CrudRepository;

public interface JobRunContextRepository extends CrudRepository<JobRunContext, String> {
}
