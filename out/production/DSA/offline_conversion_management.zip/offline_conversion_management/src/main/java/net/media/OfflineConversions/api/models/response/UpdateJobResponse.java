package net.media.OfflineConversions.api.models.response;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;
import net.media.OfflineConversions.jobs.models.Job;

import java.util.List;

@EqualsAndHashCode(callSuper = true)
@SuperBuilder
@Data
public class UpdateJobResponse extends BaseResponse {
    List<Integer> missingJobs;
    List<Job> newDuplicateJobs;
}
