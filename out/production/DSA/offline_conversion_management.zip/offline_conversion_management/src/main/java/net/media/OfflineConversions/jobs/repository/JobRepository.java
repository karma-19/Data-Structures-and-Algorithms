package net.media.OfflineConversions.jobs.repository;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.api.models.requests.GetJobRequest;
import net.media.OfflineConversions.api.models.requests.UpdateJobStatusRequest;
import net.media.OfflineConversions.api.models.response.JobInterfaceResponse;
import net.media.OfflineConversions.api.services.JobService;
import net.media.OfflineConversions.dao.RedisDao;
import net.media.OfflineConversions.enums.JobRunStatus;
import net.media.OfflineConversions.enums.JobRunType;
import net.media.OfflineConversions.enums.JobStatus;
import net.media.OfflineConversions.enums.SchedulerFreq;
import net.media.OfflineConversions.exceptions.SPFailedException;
import net.media.OfflineConversions.jobs.mappers.*;
import net.media.OfflineConversions.jobs.models.*;
import net.media.OfflineConversions.schedulers.TimeLogic;
import net.media.OfflineConversions.utils.DateFormats;
import net.media.OfflineConversions.utils.DateUtil;
import net.media.OfflineConversions.utils.JsonUtil;
import net.media.OfflineConversions.utils.ZonedDateUtil;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.text.ParseException;
import java.time.ZonedDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.Objects;
import java.util.stream.Collectors;


@Slf4j
@Repository
public class JobRepository {
    JdbcTemplate jobJdbcTemplate;
    RedisDao redisDao;

    String PING_MAKER = "SELECT 1 AS HealthCheck";
    String CREATE_JOB_SP = "CALL ocm_create_job (?,?);";
    String GET_JOB_SP = "CALL ocm_get_jobs_follower(?,'',1,0,?);";
    String SUSPEND_JOB_SP = "CALL ocm_job_suspend (?,?);";
    String RESUME_JOB_SP = "CALL ocm_job_resume(?,?);";
    String UPDATE_JOB_SP = "CALL ocm_update_jobs (?,?);";
    String GET_JOBS_INTERFACE_SP = "call ocm_get_jobs_interface_follower(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s);";
    String GET_CONVERSION_TYPE_DETAILS_SP = "call ocm_get_conversion_type_details_follower('')";
    String GET_JOB_HISTORY_SP = "call ocm_get_job_run_details_follower(? ,'',1,?,?);";
    String UPDATE_JOB_AND_JOB_RUN_DETAILS_SP = "CALL ocm_update_jobs_and_job_run_details (?,?,?,?,?,?,?,?);";

    String GET_STUCK_JOBS_SP = "CALL ocm_get_stuck_jobs ('running',%s,'%s');";
    String GET_SCHEDULED_JOBS_SP = "CALL ocm_get_scheduled_jobs (%s)";
    String UPDATE_RUN_COMPLETION_IN_JOB_DETAILS_AND_JOB = "call ocm_update_run_completion_in_job_details_and_job_v2(?,?,?,?,?,?)";  //last variable(run_completed) is for whether job finished successfully or to set historic modified time
    String UPDATE_RUN_COMPLETION_IN_JOB = "call ocm_update_completion_in_job(?)";
    String UPDATE_IN_JOBS_AND_UPSERT_IN_JOB_RUN_DETAILS = "call ocm_update_in_jobs_and_upsert_in_job_run_details(%s)";
    String GET_JOB_RUN_DETAILS = "call ocm_get_job_run_details(%s,%s)";
    String GET_JOB_RUN_ON_PRIORITY = "call ocm_get_job_on_priority(%d)";

    public JobRepository(@Qualifier("jobJdbcTemplate") JdbcTemplate jobJdbcTemplate, RedisDao redisDao) {
        this.jobJdbcTemplate = jobJdbcTemplate;
        this.redisDao = redisDao;
    }

    public boolean pingdb() {
        return Objects.requireNonNull(this.jobJdbcTemplate.queryForObject(PING_MAKER, Integer.class)) == 1;
    }

    public Job getJobOnPriority(Integer jobId) throws SPFailedException {
        String query = String.format(GET_JOB_RUN_ON_PRIORITY, jobId);
        try {
            List<GetJobSPRequest> requestList = new ArrayList<>();
            requestList.add(GetJobSPRequest.builder().jobId(jobId).build());

            Job job = this.getJobs(requestList).get(0);
            if (job == null || job.getJobRunStatus() == JobRunStatus.RUNNING || job.getStatus() == JobStatus.SUSPENDED) {
                return null;
            }
            return jobJdbcTemplate.queryForObject(query, new JobRowMapper());
        } catch (Exception e) {
            throw new SPFailedException(query + " failed." + e.getMessage());
        }
    }

    public List<Job> getScheduledJob() throws SPFailedException {
        try {
            long jobCount = redisDao.getPriorityProcessingJobCount() + JobService.MAX_SCHEDULED_JOBS_IN_PROCESS;
            // additional for priority job
            String message = String.format("ocm_get_scheduled_jobs (%d)",
                    jobCount
            );
            log.warn("message: {}", message);
            return jobJdbcTemplate.query(String.format(GET_SCHEDULED_JOBS_SP, jobCount), new JobRowMapper());
        } catch (Exception e) {
            throw new SPFailedException(GET_SCHEDULED_JOBS_SP + " failed ; " + e.getMessage());
        }
    }

    public void updateJobs(List<Job> requestList) throws JsonProcessingException, SPFailedException {
        List<Map<String, Object>> argMap = requestList.stream().map(
                request -> {
                    Map<String, Object> map = new HashMap<>();
                    map.put("job_id", request.getId());
                    map.put("conversion_name", request.getConversionName());
                    map.put("scheduler_frequency", request.getSchedulerFrequency());
                    map.put("scheduled_time", request.getScheduledTime());
                    map.put("modified_by", request.getModifiedBy());
                    map.put("test_data", request.getTestData());
                    map.put("pixel_id", request.getPixelId());
                    return map;
                }
        ).collect(Collectors.toList());
        String args = JsonUtil.getValueAsSnakeCaseString(argMap);
        commonUpdateSPExecution(requestList.get(0).getModifiedBy(), args, UPDATE_JOB_SP);
    }

    public void upsertJobRunDetailsAndJob(JobRunDetails jobRunDetails) throws JsonProcessingException, SPFailedException {
        ArrayList<JobRunDetails> list = new ArrayList<>();
        list.add(jobRunDetails);
        String arg = "'" + JsonUtil.getValueAsString(list) + "'";
        String query = String.format(UPDATE_IN_JOBS_AND_UPSERT_IN_JOB_RUN_DETAILS, arg);
        String message = String.format("ocm_update_in_jobs_and_upsert_in_job_run_details('%s')",
                arg
        );
        log.warn("Job Id : {} message: {}", jobRunDetails.getJobId(), message);
        List<ErrorResponse> errorResponse = jobJdbcTemplate.query(query, new ErrorRowMapper());
        log.warn("Job Id : {} Error Code {}", jobRunDetails.getJobId(), errorResponse.get(0).getErrorCode());
        if (errorResponse.isEmpty() || errorResponse.get(0).getErrorCode() != 0) { // cannot use commonUpdateSPExecution as modified by is absent
            String errorMsg = errorResponse.isEmpty() ? "No error response " : errorResponse.get(0).getErrorMessage();
            throw new SPFailedException(errorMsg);
        }
    }

    public List<JobRunDetails> getJobRunDetails(Integer jobId, String dataStartTime) throws SPFailedException {
        String query = String.format(GET_JOB_RUN_DETAILS, jobId, dataStartTime);
        try {
            return jobJdbcTemplate.query(query, new JobRunDetailsRowMapper());
        } catch (Exception e) {
            throw new SPFailedException(e.getMessage());
        }
    }

    private void commonUpdateSPExecution(int modifiedBy, String args, String spName) throws SPFailedException {
        String message = String.format("modified by %d args %s spName %s", modifiedBy, args, spName);
        log.warn("message: {}", message);
        List<ErrorResponse> errorResponse = jobJdbcTemplate.query(spName, new ErrorRowMapper(), args, modifiedBy);
        log.warn("Error code : {}", errorResponse.get(0).getErrorCode());
        if (errorResponse.isEmpty() || errorResponse.get(0).getErrorCode() != 0) {
            String errorMsg = errorResponse.isEmpty() ? "No error response " : errorResponse.get(0).getErrorMessage();
            throw new SPFailedException(errorMsg);
        }
    }

    private boolean commonErrorCheck(Integer errorCode, String spName) throws SPFailedException {
        if (errorCode == null || errorCode == 1)
            throw new SPFailedException("SP call failed : " + spName);
        return true;
    }

    private void updateJobAndJobRunDetails(Job job, List<JobRunDetails> jobRunDetailsList) throws SPFailedException, JsonProcessingException {
        String jobDetailsArg = JsonUtil.getValueAsSnakeCaseString(jobRunDetailsList);
        String message = String.format("ocm_update_jobs_and_job_run_details ('%s',%d,%d,%d,%d,%d,'%s','%s')",
                jobDetailsArg,
                job.getId(),
                Integer.parseInt(job.getScheduledTime()),
                Integer.parseInt(job.getSuccessfulRunTime()),
                Integer.parseInt(job.getDataStartTime()),
                Integer.parseInt(job.getDataEndTime()),
                JsonUtil.getValueAsSnakeCaseString(job.getAdditionalData()),
                JobRunStatus.PENDING.toString().toLowerCase()
        );
        log.warn("Job Id : {} message: {}", job.getId(), message);
        Integer errorCode = jobJdbcTemplate.queryForObject(UPDATE_JOB_AND_JOB_RUN_DETAILS_SP, Integer.TYPE,
                jobDetailsArg,
                job.getId(),
                Integer.parseInt(job.getScheduledTime()),
                Integer.parseInt(job.getSuccessfulRunTime()),
                Integer.parseInt(job.getDataStartTime()),
                Integer.parseInt(job.getDataEndTime()),
                JsonUtil.getValueAsSnakeCaseString(job.getAdditionalData()), //TODO: to be removed later; PS: this is not used in SP
                JobRunStatus.PENDING.toString().toLowerCase()
        );
        log.warn("Job Id : {} Error code : {}", job.getId(), errorCode);
        this.commonErrorCheck(errorCode, UPDATE_JOB_AND_JOB_RUN_DETAILS_SP);
    }

    public List<Job> getStuckJobs(int batch_size, int hour_threshold) throws SPFailedException {
        //5,'2021-06-10 00:00:00'
        ZonedDateTime date = ZonedDateUtil.getCurrentTime().minusHours(hour_threshold);
        String format = "yyyy-MM-dd HH:00:00";
        String sql = String.format(GET_STUCK_JOBS_SP, batch_size, ZonedDateUtil.getStringFromDate(date, format));
        try {
            return jobJdbcTemplate.query(sql, new JobRowMapper());
        } catch (Exception e) {
            throw new SPFailedException(sql + " failed ; " + e.getMessage());
        }
    }

    @SuppressWarnings("rawtypes")
    public List<Job> getJobs(List<GetJobSPRequest> requestList) throws SPFailedException {
        List args = requestList.stream().map(request -> Map.of(
                "job_id", request.getJobId() == null ? 0 : request.getJobId(),  // job id given while update else 0 to check account id,conversion type id
                "account_id", request.getAccountId() == null ? 0 : request.getAccountId(),
                "conversion_type_id", request.getConversionTypeId(),
                "conversion_name", request.getConversionName() == null ? "" : request.getConversionName(),
                "pixel_id", request.getPixelId() == null ? "" : request.getPixelId()
        )).collect(Collectors.toList());
        String arg;
        try {
            arg = JsonUtil.getValueAsString(args);
        } catch (JsonProcessingException e) {
            return new ArrayList<>();
        }
        try {
            String message = String.format("ocm_get_jobs_follower('%s','',1,0,%d)",
                    args,
                    requestList.size()
            );
            log.warn("message: {}", message);
            return jobJdbcTemplate.query(GET_JOB_SP, new JobRowMapper(), arg, requestList.size());
        } catch (Exception e) {
            throw new SPFailedException(GET_JOB_SP + "failed ; " + e.getMessage());
        }
    }

    public List<Job> getAllJobs() throws SPFailedException {
        GetJobRequest jobRequest = new GetJobRequest();
        return getJobForInterface(jobRequest, 1, 0).getJobs();
    }

    public void createJobs(List<Job> requestList) throws JsonProcessingException, SPFailedException {
        String arg = JsonUtil.getValueAsSnakeCaseString(requestList);
        List<ErrorResponse> errorResponse = jobJdbcTemplate.query(CREATE_JOB_SP, new ErrorRowMapper(), arg, requestList.get(0).getCreatedBy());
        if (errorResponse.isEmpty() || errorResponse.get(0).getErrorCode() != 0) {  // cannot use commonUpdateSPExecution as modified by is absent
            String errorMsg = errorResponse.isEmpty() ? "No error response " : errorResponse.get(0).getErrorMessage();
            log.warn("Job creation error: {}", errorResponse);
            throw new SPFailedException(errorMsg);
        }
    }

    public void suspendJob(UpdateJobStatusRequest request, int userId) throws JsonProcessingException, SPFailedException {
        String args = JsonUtil.getValueAsSnakeCaseString(request.getJobId().stream().map(jobId -> Map.of(
                "job_id", jobId,
                "status", JobStatus.SUSPENDED.toString().toLowerCase(),
                "modified_by", userId
        )).collect(Collectors.toList()));
        commonUpdateSPExecution(userId, args, SUSPEND_JOB_SP);
    }

    public void resumeJob(List<Job> requestList) throws JsonProcessingException, SPFailedException {
        if (requestList.isEmpty())
            return;
        String args = JsonUtil.getValueAsSnakeCaseString(requestList.stream().map(request -> Map.of(
                "job_id", request.getId(),
                "status", JobStatus.ACTIVE.toString().toLowerCase(),
                "modified_by", request.getModifiedBy(),
                "data_end_time", request.getDataEndTime(),
                "scheduled_time", request.getScheduledTime()
        )).collect(Collectors.toList()));
        commonUpdateSPExecution(requestList.get(0).getModifiedBy(), args, RESUME_JOB_SP);
    }

    public JobInterfaceResponse getJobForInterface(GetJobRequest request, int userId, int useLimitFlag) throws SPFailedException {
        String sql;
        try {
            String accountArg = this.getAccountIds(request.getAccountIds());
            String jobArg = this.getJobIds(request.getJobIds());

            sql = String.format(GET_JOBS_INTERFACE_SP,
                    jobArg,
                    accountArg,
                    request.getManagementGroupId(),
                    request.getSourceId(),
                    request.getConversionTypeId(),
                    null, //request.getAccountName()
                    userId,
                    request.getJobType() == null ? null : "'" + request.getJobType() + "'",
                    request.getJobStatus() == null ? null : "'" + request.getJobStatus() + "'",
                    useLimitFlag,
                    useLimitFlag == 0 ? null : request.getStart(),
                    useLimitFlag == 0 ? null : request.getEnd(),
                    null
            );
            return jobJdbcTemplate.query(sql, new JobRowExtractor());
        } catch (Exception e) {
            throw new SPFailedException(GET_JOBS_INTERFACE_SP + "failed ; " + e.getMessage());
        }
    }

    public String getAccountIds(List<String> accountIds) throws JsonProcessingException {
        String accountArg = null;

        if (accountIds != null) {
            List<Map<String, String>> accounts = new ArrayList<>();
            for (String account : accountIds) {
                accounts.add(Map.of("account_id", account));
            }
            if (!accounts.isEmpty()) {
                accountArg = "'" + JsonUtil.getValueAsSnakeCaseString(accounts) + "'";
            }
        }

        return accountArg;
    }

    public String getJobIds(List<Integer> jobIds) throws JsonProcessingException {
        String jobIdsArg = null;

        if (jobIds != null) {
            List<Map<String, Integer>> jobs = new ArrayList<>();
            for (Integer jobId : jobIds) {
                if (jobId > 0) {
                    jobs.add(Map.of("job_id", jobId));
                }
            }
            if (!jobs.isEmpty()) {
                jobIdsArg = "'" + JsonUtil.getValueAsSnakeCaseString(jobs) + "'";
            }
        }

        return jobIdsArg;
    }

    public List<ConversionTypeDetails> getConversionTypeDetails() throws SPFailedException {
        try {
            return jobJdbcTemplate.query(GET_CONVERSION_TYPE_DETAILS_SP, new ConversionTypeDetailsRowMapper());
        } catch (Exception e) {
            throw new SPFailedException(GET_CONVERSION_TYPE_DETAILS_SP + "failed ; " + e.getMessage());
        }
    }

    public List<JobRunDetails> getHistory(int jobId, int start, int end) throws JsonProcessingException, SPFailedException {
        String args = JsonUtil.getValueAsSnakeCaseString(List.of(
                Map.of(
                        "job_id", jobId
                )
        ));
        try {
            String message = String.format("ocm_get_job_run_details_follower('%s' ,'',1,%d,%d)",
                    args,
                    start,
                    end
            );
            log.warn("Job Id : {} message: {}", jobId, message);
            return jobJdbcTemplate.query(GET_JOB_HISTORY_SP, new JobRunDetailsRowMapper(), args, start, end);
        } catch (Exception e) {
            throw new SPFailedException(GET_JOB_HISTORY_SP + "failed ; " + e.getMessage());
        }
    }

    private boolean _updateRunCompletionJobDetailsAndJob(Job job, JobRunDetails jobRunDetails, JobRunStatus jobRunStatus) throws SPFailedException,
            JsonProcessingException {
        String message = String.format("ocm_update_run_completion_in_job_details_and_job_v2('%s',%d,%d,%d,'%s','%s')",
                JsonUtil.getValueAsSnakeCaseString(jobRunDetails),
                job.getId(),
                Integer.parseInt(job.getDataStartTime()),
                Integer.parseInt(job.getDataEndTime()),
                jobRunStatus.toString().toLowerCase(),
                true
        );
        log.warn("Job Id : {} message: {}", job.getId(), message);
        Integer errorCode = jobJdbcTemplate.queryForObject(UPDATE_RUN_COMPLETION_IN_JOB_DETAILS_AND_JOB, Integer.TYPE,
                JsonUtil.getValueAsSnakeCaseString(jobRunDetails),
                job.getId(),
                Integer.parseInt(job.getDataStartTime()),
                Integer.parseInt(job.getDataEndTime()),
                jobRunStatus.toString().toLowerCase(),
                true
        );
        log.warn("Job Id : {} Error code : {}", job.getId(), errorCode);
        return this.commonErrorCheck(errorCode, UPDATE_RUN_COMPLETION_IN_JOB_DETAILS_AND_JOB);
    }

    public boolean updateSlotCompletion(JobRunDetails jobRunDetails, ConversionResponse conversionResponse,
                                        Job job, JobRunStatus jobRunStatus, Integer previousRunSlotConversionProcessedCount) throws SPFailedException, JsonProcessingException {
        log.info("Job Id : {} Slot completion update in DB", job.getId());

        boolean successStatus = true;
        // decide status of the run as per count match
        String message = "";
        if ((conversionResponse.getTotalConversions() == conversionResponse.getConversionsToBeUploaded()) ||
                (previousRunSlotConversionProcessedCount != null &&
                        conversionResponse.getTotalConversions() + previousRunSlotConversionProcessedCount ==
                                conversionResponse.getConversionsToBeUploaded())) {
            jobRunDetails.setStatus(JobRunDetailsStatus.success);
            message += "success";
        } else {
            jobRunDetails.setStatus(JobRunDetailsStatus.failed);
            message += "failed to upload conversions";
            successStatus = false;
        }

        jobRunDetails.setConversion_details(JsonUtil.getJsonNodeFromObject(conversionResponse));
        jobRunDetails.setConversions(conversionResponse.getConversionsFromDb());
        jobRunDetails.setMessage(message);
        jobRunDetails.setUploadedConversions(conversionResponse.getUploadCount());

        boolean dbUpdateStatus = this._updateRunCompletionJobDetailsAndJob(job, jobRunDetails, jobRunStatus);

        log.info("Job Id : {} Slot completion update in DB with status:{}", job.getId(), successStatus);

        return dbUpdateStatus;
    }

    public boolean updateJobDetailsAndJobOnFailure(Job job, JobRunDetails jobRunDetails) throws SPFailedException,
            JsonProcessingException {
        log.info("Job Id : {} updateJobDetailsAndJobOnFailure", job.getId());
        String message = String.format("ocm_update_run_completion_in_job_details_and_job_v2('%s',%d,%d,%d,'%s','%s')",
                JsonUtil.getValueAsSnakeCaseString(jobRunDetails),
                job.getId(),
                Integer.parseInt(job.getDataStartTime()),
                Integer.parseInt(job.getDataEndTime()),
                JobRunStatus.PENDING.toString().toLowerCase(),
                false
        );
        log.warn("Job Id : {} message: {}", job.getId(), message);
        Integer errorCode = jobJdbcTemplate.queryForObject(UPDATE_RUN_COMPLETION_IN_JOB_DETAILS_AND_JOB, Integer.TYPE,
                JsonUtil.getValueAsSnakeCaseString(jobRunDetails),
                job.getId(),
                Integer.parseInt(job.getDataStartTime()),
                Integer.parseInt(job.getDataEndTime()),
                JobRunStatus.PENDING.toString().toLowerCase(),
                false
        );
        log.warn("Job Id : {} Error code : {}", job.getId(), errorCode);
        return this.commonErrorCheck(errorCode, UPDATE_RUN_COMPLETION_IN_JOB_DETAILS_AND_JOB);
    }

    public void updateJobCompletion(Job job) throws SPFailedException, JsonProcessingException {
        Map<String, Object> arg = Map.of(
                "job_id", job.getId(),
                "scheduled_time", job.getScheduledTime(),
                "successful_run_time", job.getSuccessfulRunTime(),
                "job_run_status", job.getJobRunStatus(),
                "modified_by", job.getModifiedBy()
        );
        String args = JsonUtil.getValueAsSnakeCaseString(arg);
        String message = String.format("ocm_update_completion_in_job ('%s')",
                args
        );
        log.warn("Job Id : {} message: {}", job.getId(), message);
        Integer errorCode = jobJdbcTemplate.queryForObject(UPDATE_RUN_COMPLETION_IN_JOB, Integer.TYPE,
                args
        );
        log.warn("Job Id : {} Error code : {}", job.getId(), errorCode);
        this.commonErrorCheck(errorCode, UPDATE_RUN_COMPLETION_IN_JOB);
    }

    public void handleZeroConversionsScenario(Job job, Date oldDataEndTime, int numberOfHourSlots, String message,
                                              JobRunDetailsStatus status, JobRunDetailsTestData jobRunDetailsTestData, SchedulerFreq schedulerFrequency)
            throws SPFailedException, JsonProcessingException, ParseException {
        log.info("Job id : {} updateTablesForNoConversions", job.getId());
        Date newDataEndTime = DateUtil.addHours(oldDataEndTime, numberOfHourSlots);
        List<JobRunDetails> jobRunDetailsList = List.of(
                JobRunDetails.builder()
                        .jobId(job.getId())
                        .conversions(0)
                        .hrId(DateUtil.getHour(jobRunDetailsTestData.getJobRunType().equals(JobRunType.STUCK) ?
                                DateUtil.getDateFromString(job.getDataStartTime(), DateFormats.HOURLY_FORMAT) : //TODO: recheck
                                oldDataEndTime))
                        .dayId(DateUtil.getDayId(jobRunDetailsTestData.getJobRunType().equals(JobRunType.STUCK) ?
                                        DateUtil.getDateFromString(job.getDataStartTime(), DateFormats.HOURLY_FORMAT) :
                                        oldDataEndTime,
                                DateFormats.DAY_ID_FORMAT))
                        .dataStartTime(DateUtil.getStringFromDate(oldDataEndTime, DateFormats.getFormat(schedulerFrequency)))
                        .dataEndTime(DateUtil.getStringFromDate(newDataEndTime, DateFormats.getFormat(schedulerFrequency)))
                        .message(message)
                        .status(status)
                        .test_data(JsonUtil.getJsonNodeFromObject(jobRunDetailsTestData))
                        .build()
        );
        job.setJobRunStatus(JobRunStatus.PENDING);
        job.setScheduledTime(TimeLogic.getNewScheduleTime(job.getScheduledTime(), job.getSchedulerFrequency()));
        this.updateJobAndJobRunDetails(job, jobRunDetailsList);
    }
}
