package net.media.OfflineConversions.jobs.mappers;

import com.fasterxml.jackson.databind.JsonNode;
import lombok.SneakyThrows;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.enums.*;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.utils.JsonUtil;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;

@Slf4j
public class JobRowMapper implements RowMapper<Job> {
    @SneakyThrows
    @Override
    public Job mapRow(ResultSet resultSet, int i) {
        String managementGroup = _checkAndReturnString(resultSet, "management_group");
        int managementGroupId = _checkAndReturnInt(resultSet, "management_group_id");
        int sourceId = _checkAndReturnInt(resultSet, "source_id");
        String sourceName = _checkAndReturnString(resultSet, "source_name");
        String conversionTypeName = _checkAndReturnString(resultSet, "conversion_type");
        String createdByUser = _checkAndReturnString(resultSet, "created_by_user");
        String modifiedByUser = _checkAndReturnString(resultSet, "modified_by_user");
        String accountName = _checkAndReturnString(resultSet, "account_name");
        String pixelId = _checkAndReturnString(resultSet, "pixel_id");
        JsonNode additionalData = (pixelId == null || pixelId.isEmpty()) ? JsonUtil.getObjectNode() :
                JsonUtil.getObjectNode().put("pixel_id", pixelId);
        if (conversionTypeName == null) {
            conversionTypeName = _checkAndReturnString(resultSet, "conversion_type_name");
        }
        ConversionType conversionType = conversionTypeName == null ? null : ConversionType.valueOf(conversionTypeName);
        return Job.builder()
                .id(resultSet.getInt("id"))
                .accountId(resultSet.getString("account_id"))
                .accountName(accountName)
                .conversionTypeId(resultSet.getInt("conversion_type_id"))
                .conversionType(conversionType)
                .conversionName(resultSet.getString("conversion_name"))
                .schedulerFrequency(SchedulerFreq.valueOf(resultSet.getString("scheduler_frequency").toUpperCase()))
                .scheduledTime(resultSet.getString("scheduled_time"))
                .successfulRunTime(resultSet.getString("successful_run_time"))
                .dataStartTime(resultSet.getString("data_start_time"))
                .dataEndTime(resultSet.getString("data_end_time"))
                .additionalData(additionalData)
                .status(JobStatus.valueOf(resultSet.getString("status").toUpperCase()))
                .jobRunStatus(JobRunStatus.valueOf(resultSet.getString("job_run_status").toUpperCase()))
                .createdBy(resultSet.getInt("created_by"))
                .createdByUser(createdByUser)
                .modifiedBy(resultSet.getInt("modified_by"))
                .modifiedByUser(modifiedByUser)
                .createdTime(resultSet.getString("created_time"))
                .modifiedTime(resultSet.getString("modified_time"))
                .managementGroup(managementGroup)
                .managementGroupId(managementGroupId)
                .sourceId(sourceId)
                .sourceName(sourceName)
                .jobType(JobType.valueOf(resultSet.getString("job_type").toUpperCase()))
                .testData(JsonUtil.getJsonNodeFromString(resultSet.getString("test_data")))
                .pixelId(pixelId)
                .build();
    }

    private String _checkAndReturnString(ResultSet resultSet, String key) {
        try {
            return resultSet.getString(key);
        } catch (Exception e) {
            log.warn("Exception to fetch String key:{} error:{}", key, e.getMessage());
            return null;
        }
    }

    private int _checkAndReturnInt(ResultSet resultSet, String key) {
        try {
            return resultSet.getInt(key);
        } catch (Exception e) {
            log.warn("Exception to fetch Int key:{} error:{}", key, e.getMessage());
            return 0;
        }
    }
}
