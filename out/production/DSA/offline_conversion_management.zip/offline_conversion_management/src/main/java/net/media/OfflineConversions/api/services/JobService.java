package net.media.OfflineConversions.api.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.api.models.requests.*;
import net.media.OfflineConversions.api.models.response.CreateJobResponse;
import net.media.OfflineConversions.api.models.response.JobInterfaceResponse;
import net.media.OfflineConversions.api.models.response.UpdateJobResponse;
import net.media.OfflineConversions.conf.JobConstraintsConf;
import net.media.OfflineConversions.conversions.ConversionRepositoryFactory;
import net.media.OfflineConversions.conversions.ConversionUploadApi;
import net.media.OfflineConversions.conversions.services.ConversionModifier;
import net.media.OfflineConversions.dao.RedisDao;
import net.media.OfflineConversions.enums.ConversionType;
import net.media.OfflineConversions.enums.JobRunStatus;
import net.media.OfflineConversions.enums.JobStatus;
import net.media.OfflineConversions.enums.JobType;
import net.media.OfflineConversions.exceptions.SPFailedException;
import net.media.OfflineConversions.jobs.models.AccountDetails;
import net.media.OfflineConversions.jobs.models.GetJobSPRequest;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.jobs.models.JobRunDetails;
import net.media.OfflineConversions.jobs.repository.JobRepository;
import net.media.OfflineConversions.jobs.repository.SemMasterRepository;
import net.media.OfflineConversions.schedulers.TimeLogic;
import net.media.OfflineConversions.utils.DateFormats;
import net.media.OfflineConversions.utils.JsonUtil;
import net.media.OfflineConversions.utils.ZonedDateUtil;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

@Service
@Slf4j
public class JobService {
    JobRepository jobRepository;
    SemMasterRepository semMasterRepository;

    ConversionRepositoryFactory factory;

    ConversionUploadApi conversionUploadApi;
    ConversionModifier conversionModifier;

    RedisDao redisDao;

    public static final int MAX_SCHEDULED_JOBS_IN_PROCESS = 6;

    public JobService(JobRepository jobRepository, SemMasterRepository semMasterRepository,
                      ConversionRepositoryFactory factory, ConversionUploadApi conversionUploadApi,
                      ConversionModifier conversionModifier, RedisDao redisDao) {
        this.jobRepository = jobRepository;
        this.semMasterRepository = semMasterRepository;
        this.factory = factory;
        this.conversionUploadApi = conversionUploadApi;
        this.conversionModifier = conversionModifier;
        this.redisDao = redisDao;
    }

    @Transactional(rollbackFor = {SPFailedException.class})
    public Job setJobAsProcessingInDbAndRedis(Integer jobId, int userId) throws SPFailedException {
        Job job = jobRepository.getJobOnPriority(jobId);
        if (job == null) {
            log.warn("Job Id : {} User Id : {} Job is suspended or already running.", jobId, userId);
            return null;
        }
        redisDao.putJobInPriorityProcessingQueue(jobId);
        return job;
    }

    public CreateJobResponse create(List<CreateJobRequest> requestList, int userId) throws JsonProcessingException, SPFailedException {
        List<String> validAccountIds = semMasterRepository.getAccountIds(requestList.stream().map(CreateJobRequest::getAccountId).collect(Collectors.toList()));
        List<String> inValidAccountIds = _extractInvalidAccountIds(validAccountIds, requestList);
        if (!inValidAccountIds.isEmpty()) {
            return CreateJobResponse.builder()
                    .inValidAccountIds(inValidAccountIds)
                    .message("Some Account Ids are invalid")
                    .build();
        }

        List<Job> jobs = jobRepository.getJobs(requestList.stream().map(r -> GetJobSPRequest.builder()
                .accountId(r.getAccountId())
                .conversionTypeId(r.getConversionTypeId())
                .conversionName(r.getConversionName())
                .pixelId(r.getPixelId())
                .build()).collect(Collectors.toList()));
        if (!jobs.isEmpty()) {
            return CreateJobResponse.builder()
                    .alreadyExistingJobs(jobs)
                    .message("Some jobs already exist")
                    .build();
        }

        List<Job> jobList = requestList.stream().map(request -> {
            String dataDateFormatted = ZonedDateUtil.getFormattedCurrentTime(DateFormats.getFormat(request.getSchedulerFrequency()));
            return Job.builder()
                    .accountId(request.getAccountId())
                    .testData(request.getTestData())
                    .createdBy(userId)
                    .modifiedBy(userId)
                    .schedulerFrequency(request.getSchedulerFrequency())
                    .conversionTypeId(request.getConversionTypeId())
                    .conversionName(request.getConversionName())
                    .jobRunStatus(JobRunStatus.PENDING)
                    .status(JobStatus.ACTIVE)
                    .scheduledTime(ZonedDateUtil.getFormattedCurrentTime(DateFormats.HOURLY_FORMAT))
                    .dataEndTime(dataDateFormatted)
                    .dataStartTime(dataDateFormatted)
                    .jobType(request.getJobType())
                    .pixelId(request.getPixelId())
                    .build();
        }).collect(Collectors.toList());
        jobRepository.createJobs(jobList);
        return CreateJobResponse.builder().message("Jobs created successfully").build();
    }

    private List<String> _extractInvalidAccountIds(List<String> validAccountIds, List<CreateJobRequest> requestList) {
        List<String> invalidAccountIds = new ArrayList<>();
        requestList.forEach(request -> {
            boolean contains = false;
            for (String validAccountId : validAccountIds) {
                if (validAccountId.equals(request.getAccountId())) {
                    contains = true;
                    break;
                }
            }
            if (!contains)
                invalidAccountIds.add(request.getAccountId());
        });
        return invalidAccountIds;
    }

    public UpdateJobResponse updateJobStatus(UpdateJobStatusRequest request, int userId) throws JsonProcessingException, SPFailedException, ParseException {
        List<Integer> jobIds = request.getJobId();
        Map<Integer, Job> existingJobs = getJobsByIds(jobIds);
        List<Integer> missingJobs = getMissingJobs(jobIds, existingJobs);
        if (!missingJobs.isEmpty())
            return UpdateJobResponse.builder().missingJobs(missingJobs).message("All Jobs don't exist").build();

        if (request.getStatus().equals(JobStatus.SUSPENDED))
            jobRepository.suspendJob(request, userId);
        else {
            List<Job> updatedJobs = new ArrayList<>();
            for (Map.Entry<Integer, Job> entry : existingJobs.entrySet()) {
                Job job = entry.getValue();
                job.setDataEndTime(TimeLogic.getResumeJobDataEndTime(job.getDataEndTime(), job.getSchedulerFrequency()));
                job.setModifiedBy(userId);
                job.setStatus(JobStatus.ACTIVE);
                updatedJobs.add(job);
            }
            jobRepository.resumeJob(updatedJobs);
        }
        return UpdateJobResponse.builder().message("Jobs status updated successfully").build();
    }

    public UpdateJobResponse update(List<UpdateJobRequest> requestList, int userId) throws SPFailedException, JsonProcessingException, ParseException {
        List<Integer> jobIdsInRequest = requestList.stream().map(UpdateJobRequest::getJobId).collect(Collectors.toList());   // 10 jobs
        Map<Integer, Job> dbMatchedJobIdDetails = getJobsByIds(jobIdsInRequest);  // 8 jobs
        List<Integer> missingJobsIdsInDB = getMissingJobs(jobIdsInRequest, dbMatchedJobIdDetails);   // 2 jobs are missing

        // Missing Jobs cannot be updated
        if (!missingJobsIdsInDB.isEmpty())
            return UpdateJobResponse.builder().missingJobs(missingJobsIdsInDB).message("All Jobs don't exist").build();

        // Edits should not lead to duplicate messages
        List<Job> duplicateJobDetailsInDB = jobRepository.getJobs(
                requestList.stream()
                        .map(r -> {
                            Job jobIdDetailsFromDB = dbMatchedJobIdDetails.get(r.getJobId());
                            return GetJobSPRequest.builder()
                                    .accountId(jobIdDetailsFromDB.getAccountId())
                                    .conversionTypeId(jobIdDetailsFromDB.getConversionTypeId())
                                    .conversionName(r.getConversionName())
                                    .pixelId(r.getPixelId())
                                    .build();
                        })
                        .collect(Collectors.toList())).stream()
                .filter(job -> !jobIdsInRequest.contains(job.getId()))
                .collect(Collectors.toList());

        if (!duplicateJobDetailsInDB.isEmpty()) {
            return UpdateJobResponse.builder()
                    .newDuplicateJobs(duplicateJobDetailsInDB)
                    .message("Some jobs already exist")
                    .build();
        }

        // TODO : change frequency from daily to hourly leads to different time format in data_start_time and data_end_time
        List<Job> updatedJobs = new ArrayList<>();
        for (UpdateJobRequest updateJobRequest : requestList) {
            Job job = dbMatchedJobIdDetails.get(updateJobRequest.getJobId());

            job.setConversionName(updateJobRequest.getConversionName());
            job.setScheduledTime(job.getScheduledTime());
            job.setModifiedBy(userId);
            job.setSchedulerFrequency(job.getSchedulerFrequency());
            job.setPixelId(updateJobRequest.getPixelId());
            job.setTestData(updateJobRequest.getTestData());
            updatedJobs.add(job);
        }
        jobRepository.updateJobs(updatedJobs);
        return UpdateJobResponse.builder().message("Jobs updated successfully").build();
    }

    public JobInterfaceResponse getJobForInterface(GetJobRequest request, int userId) throws SPFailedException {
        int useLimitFlag = request.getEnd() < 0 ? 0 : 1;
        return jobRepository.getJobForInterface(request, userId, useLimitFlag);
    }

    public List<JobRunDetails> getJobHistory(int jobId, int start, int end) throws SPFailedException, JsonProcessingException {
        return jobRepository.getHistory(jobId, start, end);
    }

    private List<Integer> getMissingJobs(List<Integer> jobIds, Map<Integer, Job> existingJobs) {
        List<Integer> missingJobs = new ArrayList<>();
        for (Integer jobId : jobIds) {
            if (!existingJobs.containsKey(jobId))
                missingJobs.add(jobId);
        }
        return missingJobs;
    }

    private Map<Integer, Job> getJobsByIds(List<Integer> jobIds) throws SPFailedException {
        List<Job> jobs = jobRepository.getJobs(jobIds.stream().map(jobId -> GetJobSPRequest.builder()
                .jobId(jobId)
                .build())
                .collect(Collectors.toList()));
        Map<Integer, Job> jobMap = new HashMap<>();
        for (Job job : jobs) {
            jobMap.put(job.getId(), job);
        }
        return jobMap;
    }

    private Job getJobById(Integer jobId) throws SPFailedException {
        GetJobSPRequest jobSPRequest = GetJobSPRequest.builder()
                .jobId(jobId)
                .build();
        List<Job> jobs = jobRepository.getJobs(Collections.singletonList(jobSPRequest));

        for (Job job : jobs) {
            return job;
        }

        return null;
    }

    //TODO: temp code for pixel id population from additional data; PS: hence reused code
    public void populatePixelId(CreateJobRequest request) {
        if ((request.getPixelId() == null || request.getPixelId().isEmpty()) &&
                !JsonUtil.isNullOrEmpty(request.getAdditionalData(), "pixel_id") &&
                request.getAdditionalData().get("pixel_id").isTextual()) {
            request.setPixelId(request.getAdditionalData().get("pixel_id").asText());
        }
    }

    public void populatePixelId(UpdateJobRequest request) {
        if ((request.getPixelId() == null || request.getPixelId().isEmpty()) &&
                !JsonUtil.isNullOrEmpty(request.getAdditionalData(), "pixel_id") &&
                request.getAdditionalData().get("pixel_id").isTextual()) {
            request.setPixelId(request.getAdditionalData().get("pixel_id").asText());
        }
    }

    public String validateSourceSpecificAdditionalData(List<CreateJobRequest> requestList) {
        StringBuilder msg = new StringBuilder();

        Map<String, AccountDetails> accountDetailsMap = semMasterRepository.getAccountsWithAccountDetails(
                requestList.stream().map(CreateJobRequest::getAccountId).collect(Collectors.toList()));

        for (CreateJobRequest createJobRequest : requestList) {
            if (!accountDetailsMap.containsKey(createJobRequest.getAccountId())) {
                msg.append("Account Id : ").append(createJobRequest.getAccountId()).append(" Does Not Exist.");
                continue;
            }

            if (accountDetailsMap.get(createJobRequest.getAccountId()).getSourceId() == ConversionUploadApi.FACEBOOK_SOURCE_ID ||
                    accountDetailsMap.get(createJobRequest.getAccountId()).getSourceId() == ConversionUploadApi.TIKTOK_SOURCE_ID) {
                if (createJobRequest.getPixelId() == null ||
                        createJobRequest.getPixelId().isBlank()) {
                    msg.append("Account Id : ").append(createJobRequest.getAccountId()).append(" Pixel Id is required for Facebook and Tiktok accounts.");
                    continue;
                }
            }
        }

        return msg.toString();
    }

    public String validateJobsConstraints(List<CreateJobRequest> requestList) {
        List<String> requestAccountIds = requestList.stream()
                .map(CreateJobRequest::getAccountId)
                .collect(Collectors.toList());

        Map<String, AccountDetails> accountsWithAccountDetails = semMasterRepository.getAccountsWithAccountDetails(requestAccountIds);

        StringBuilder finalMsg = new StringBuilder();

        for (CreateJobRequest createJobRequest : requestList) {
            boolean isValid = false;
            ConversionType requestedConversionType = ConversionType.get(createJobRequest.getConversionTypeId());

            String accountId = createJobRequest.getAccountId();

            Map<JobType, List<JobConstraintsConf.ConversionTypeConstraint.Constraint>> jobTypeToConstraintList = JobConstraintsConf.JOB_CONSTRAINTS_MAP.get(requestedConversionType);
            if (!jobTypeToConstraintList.containsKey(createJobRequest.getJobType())) {
                finalMsg.append("Account Id : ").append(accountId)
                        .append(" Job Type : ").append(createJobRequest.getJobType())
                        .append(" not supported for Conversion Type : ").append(Objects.requireNonNull(requestedConversionType).toString());
                break;
            }

            StringBuilder constraintMsg = new StringBuilder();
            for (JobConstraintsConf.ConversionTypeConstraint.Constraint constraint : jobTypeToConstraintList.get(createJobRequest.getJobType())) {
                //permitted if management group mapped on accountId present in management group list in yaml
                String managementGroup = accountsWithAccountDetails.get(accountId).getManagementGroupName();
                List<String> allowedManagementGroups = constraint.getAllowed_management_groups();
                List<String> excludedManagementGroups = constraint.getExcluded_management_groups();
                boolean managementGroupCompliance = (allowedManagementGroups.isEmpty() || allowedManagementGroups.contains(managementGroup))
                        && !excludedManagementGroups.contains(managementGroup);   // todo : change as per new resp
                if (!managementGroupCompliance) {
                    constraintMsg.append(" Management Group : ").append(managementGroup).append(" not allowed for ").append(createJobRequest.getJobType()).append(" - ").append(requestedConversionType);
                }

                //permitted if source mapped on accountId present in yml source
                List<Integer> allowedBuySources = constraint.getAllowed_buy_sources();
                List<Integer> excludedBuySources = constraint.getExcluded_buy_sources();
                Integer buySource = accountsWithAccountDetails.get(accountId).getSourceId();
                boolean buySourceCompliance = (allowedBuySources.isEmpty() || allowedBuySources.contains(buySource)) &&
                        !excludedBuySources.contains(buySource);
                if (!buySourceCompliance) {
                    constraintMsg.append(" Buy Source : ").append(buySource).append(" not allowed for ").append(createJobRequest.getJobType()).append(" - ").append(requestedConversionType);
                }

                isValid |= (managementGroupCompliance && buySourceCompliance);
            }

            if (!isValid) { //if any of request fails
                finalMsg.append("Account Id : ").append(accountId).append(constraintMsg);
                break;
            }
        }

        return finalMsg.toString(); //if all request are correct
    }

    public boolean enqueueForPriorityProcessing(Integer jobId, int userId) throws SPFailedException, JsonProcessingException {
        try {
            Job job = getJobById(jobId);
            if (job == null) {
                log.info("Job Id : {} doesn't exist", jobId);
                return false;
            }

            if (job.getJobRunStatus() == JobRunStatus.RUNNING || job.getStatus() == JobStatus.SUSPENDED) {
                log.info("Job Id : {} is suspended or already running, userId:{}", jobId, userId);
                return true;
            } else {
                PriorityJobRequest priorityJobRequest = PriorityJobRequest.builder()
                        .jobId(jobId)
                        .userId(userId)
                        .build();
                String jsonString = JsonUtil.getValueAsString(priorityJobRequest);
                Long enqueueResult = redisDao.enqueuePriorityJob(jsonString);
                if (enqueueResult != null && enqueueResult >= 1) {
                    return true;
                }
            }
        } catch (Exception e) {
            log.warn("Job Id : {} Exception occurred {}", jobId, e.getMessage());
            e.printStackTrace();
            throw e;
        }
        return false;
    }
}
