package net.media.OfflineConversions.conversions.services;


import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.Conversion;
import net.media.OfflineConversions.conversions.ConversionApiResponse;
import net.media.OfflineConversions.conversions.ConversionUploadApi;
import net.media.OfflineConversions.dao.RedisDao;
import net.media.OfflineConversions.enums.ConversionType;
import net.media.OfflineConversions.enums.JobStatus;
import net.media.OfflineConversions.enums.JobType;
import net.media.OfflineConversions.jobs.models.ConversionResponse;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.schedulers.RealtimeJobRunService;
import net.media.OfflineConversions.schedulers.ScheduledJobListRefresher;
import net.media.OfflineConversions.utils.DateFormats;
import net.media.OfflineConversions.utils.DateUtil;
import net.media.OfflineConversions.utils.JsonUtil;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class RealtimeConversionProcessingService {
    private final ScheduledJobListRefresher scheduledJobListRefresher;
    private final ConversionUploadApi conversionUploadApi;
    private final ConversionModifier conversionModifier;
    private final RedisDao redisDao;
    private final RealtimeJobRunService realtimeJobRunService;

    public RealtimeConversionProcessingService(ScheduledJobListRefresher scheduledJobListRefresher,
                                               ConversionUploadApi conversionUploadApi,
                                               ConversionModifier conversionModifier,
                                               RedisDao redisDao,
                                               RealtimeJobRunService realtimeJobRunService) {
        this.scheduledJobListRefresher = scheduledJobListRefresher;
        this.conversionUploadApi = conversionUploadApi;
        this.conversionModifier = conversionModifier;
        this.redisDao = redisDao;
        this.realtimeJobRunService = realtimeJobRunService;
    }

    public boolean process(List<JsonNode> conversionMessageList) {
        boolean successStatus = true;
        for (JsonNode conversionMessage : conversionMessageList) {
            List<Job> jobs = this.getRealtimeConversionTypeJobs(conversionMessage);
            for (Job job : jobs) {
                try {
                    Conversion conversion = buildConversion(conversionMessage, job);
                    ArrayList<Conversion> conversionList = new ArrayList<>() {{
                        add(conversion);
                    }};
                    ConversionResponse conversionResponse = conversionModifier.modifyConversionNumbersAndValue(
                            conversionList, job, JobType.REALTIME);

                    if (conversionResponse.getConversionsToBeUploaded() > 0) {
                        ConversionApiResponse conversionApiResponse = conversionUploadApi.send(conversion, job, JobType.REALTIME);
                        if (conversionApiResponse.equals(ConversionApiResponse.FILTERED)) {
                            log.info("Job Id : {} Realtime conversion filtered for {}", job.getId(), conversion);
                        }
                        conversionResponse.increment(conversionApiResponse, 1);
                    }

                    this.upsertConversionDetailInRedis(job.getId(), conversionResponse, conversion.getConversionTime());

                } catch (ParseException e) {
                    log.warn("Job Id : {} Realtime Consumer Parse Exception on {} {}", job.getId(), conversionMessage, e.getMessage());
                    successStatus = false;
                } catch (Exception ex) {
                    log.warn("Job Id : {} Realtime Consumer Exception on {} {}", job.getId(), conversionMessage, ex.getMessage());
                    successStatus = false;
                }
            }
        }
        return successStatus;
    }

    //(either jobId_StartTime is present in sorted set or it was popped for processing but not yet processed) and (jobId_StartTime is present in hash map), then increment
    //else create new map and insert key in hash map & sorted set
    private void upsertConversionDetailInRedis(Integer jobId, ConversionResponse conversionResponse, Date conversionTime) {
        try {
            Integer dataStartTime = Integer.parseInt(DateUtil.getStringFromDate(conversionTime, DateFormats.HOURLY_FORMAT));
            String jobId_startTime = jobId + "_" + dataStartTime;
            if (
                    (redisDao.isJobPresentInRealtimeSortedSet(jobId_startTime) ||
                            (
                                    realtimeJobRunService.getJobIdStartTime() != null &&
                                            realtimeJobRunService.getJobIdStartTime().equals(jobId_startTime)
                            )
                    ) &&
                            redisDao.isJobPresentInRealtimeHashMap(jobId_startTime)
            ) {
                redisDao.incrementJobsResponseInRealtimeHashMap(jobId_startTime, conversionResponse);
            } else {
                redisDao.insertJobInRealtimeHashMap(jobId_startTime, conversionResponse);
                redisDao.insertJobInRealtimeSortedSet(jobId_startTime, dataStartTime);
            }
        } catch (Exception e) {
            log.warn("Job Id : {} Exception occurred while upserting in redis conversionResponse {} conversionTime {}.",
                    jobId, conversionResponse, conversionTime);
            throw e;
        }
    }

    private List<Job> getRealtimeConversionTypeJobs(JsonNode conversionMessage) {
        String accountId = JsonUtil.getJsonFieldAsString(conversionMessage, "account_id");
        Integer conversionTypeId = JsonUtil.getJsonFieldAsInt(conversionMessage, "conversion_type_id");
        if (accountId == null || conversionTypeId == null || ConversionType.get(conversionTypeId) == null) {
            return new ArrayList<>();
        }

        Map<String, List<Job>> accountToJobsMap = scheduledJobListRefresher.getAccountToJobsMap();
        if (!accountToJobsMap.containsKey(accountId)) {
            return new ArrayList<>();
        }

        return accountToJobsMap.get(accountId).stream()
                .filter(Objects::nonNull)
                .filter(job -> job.getStatus().equals(JobStatus.ACTIVE))                                                            // TODO : Moynak : later : can we fetch only active jobs ?
                .filter(job -> job.getConversionType().equals(ConversionType.get(conversionTypeId)))
                .filter(job -> job.getJobType().equals(JobType.REALTIME) || ScheduledJobListRefresher.JOBS_SCHEDULED_TO_REALTIME.values()         // Todo : Moynak : temp code
                        .stream()
                        .flatMap(Set::stream)
                        .collect(Collectors.toSet())
                        .contains(job.getId()))
                .collect(Collectors.toList());
    }

    private Conversion buildConversion(JsonNode conversionMessage, Job job) throws ParseException {
        return Conversion.builder()
                .accountId(job.getAccountId())
                .conversionName(job.getConversionName())
                .conversionTime(DateUtil.getDateFromString(JsonUtil.getJsonFieldAsString(conversionMessage, "conversion_time"),
                        DateFormats.CONVERSION_FORMAT))
                .logHash(JsonUtil.getJsonFieldAsString(conversionMessage, "log_hash"))
                .gclid(JsonUtil.getJsonFieldAsString(conversionMessage, "gclid"))
                .ip(JsonUtil.getJsonFieldAsLong(conversionMessage, "ip") == null ? "0" :
                        Objects.requireNonNull(JsonUtil.getJsonFieldAsLong(conversionMessage, "ip")).toString())
                .ua(JsonUtil.getJsonFieldAsString(conversionMessage, "ua"))
                .device(JsonUtil.getJsonFieldAsString(conversionMessage, "device"))
                .url(JsonUtil.getJsonFieldAsString(conversionMessage, "url"))
                .testDataDevice(JsonUtil.getJsonFieldAsString(conversionMessage, "test_data_device"))
                .param_1(JsonUtil.getJsonFieldAsString(conversionMessage, "param_1"))
                .param_2(JsonUtil.getJsonFieldAsString(conversionMessage, "param_2"))
                .network(JsonUtil.getJsonFieldAsString(conversionMessage, "network"))
                .realtime_kafka_offset(JsonUtil.getJsonFieldAsString(conversionMessage, "realtime_kafka_offset"))
                .realtime_kafka_partition(JsonUtil.getJsonFieldAsString(conversionMessage, "realtime_kafka_partition"))
                .build();
    }
}
