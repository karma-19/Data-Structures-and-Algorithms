package net.media.OfflineConversions.api.models.requests;

import lombok.Data;
import net.media.OfflineConversions.enums.JobStatus;
import net.media.OfflineConversions.enums.JobType;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class GetJobRequest {
    @NotNull
    Integer start;
    @NotNull
    Integer end;
    List<Integer> jobIds;
    List<String> accountIds;
    Integer conversionTypeId;
    Integer sourceId;
    Integer managementGroupId;
    JobType jobType;
    JobStatus jobStatus;
}
