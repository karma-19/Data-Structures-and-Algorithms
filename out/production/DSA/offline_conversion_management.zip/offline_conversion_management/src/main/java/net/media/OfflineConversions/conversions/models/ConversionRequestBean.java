package net.media.OfflineConversions.conversions.models;

import lombok.Data;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Data
public class ConversionRequestBean {
    @NotBlank
    private String accountId;
    @NotBlank
    private String conversionName;
    @Pattern(regexp = "^[0-9]{8} [0-9]{6}$")
    private String conversionTime; //yyyyMMdd HHmmss timezone
    @NotBlank
    private String logHash;
    @NotBlank
    private String buyClickId;
}
