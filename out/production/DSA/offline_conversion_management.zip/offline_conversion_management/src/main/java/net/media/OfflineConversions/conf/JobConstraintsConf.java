package net.media.OfflineConversions.conf;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.yaml.YAMLFactory;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.enums.ConversionType;
import net.media.OfflineConversions.enums.JobType;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Configuration
@Slf4j
public class JobConstraintsConf {

    public static final Map<ConversionType, Map<JobType, List<ConversionTypeConstraint.Constraint>>> JOB_CONSTRAINTS_MAP = new HashMap<>();

    public JobConstraintsConf() throws IOException {
        ConversionTypeConstraint constraint = this.getJobConstraintConfigs();
        this.configureConstraintsMap(constraint);
    }

    private ConversionTypeConstraint getJobConstraintConfigs() throws IOException {
        ObjectMapper objectMapper = new ObjectMapper(new YAMLFactory());
        ClassPathResource resource = new ClassPathResource("constraints.yml");
        return objectMapper.readValue(resource.getInputStream(), ConversionTypeConstraint.class);
    }

    private void configureConstraintsMap(ConversionTypeConstraint constraint) {
        try {
            for (Map.Entry<Integer, Map<String, Map<String, ConversionTypeConstraint.Constraint>>> conversionTypeEntry :
                    constraint.getConstraints().entrySet()) {
                ConversionType conversionType = ConversionType.get(conversionTypeEntry.getKey());
                Map<JobType, List<ConversionTypeConstraint.Constraint>> jobTypeMap = new HashMap<>();
                for (Map.Entry<String, Map<String, ConversionTypeConstraint.Constraint>> jobTypeEntry :
                        conversionTypeEntry.getValue().entrySet()) {
                    JobType jobType = Enum.valueOf(JobType.class, jobTypeEntry.getKey());
                    List<ConversionTypeConstraint.Constraint> constraintList = new ArrayList<>(jobTypeEntry.getValue().values());
                    jobTypeMap.put(jobType, constraintList);
                }
                JOB_CONSTRAINTS_MAP.put(conversionType, jobTypeMap);
            }
        } catch (Exception e) {
            log.error("Error in Config parsing: {}", e.getMessage());
            e.printStackTrace();
            throw e;
        }
        log.info("Constraints Map: {}", JOB_CONSTRAINTS_MAP);
    }

    @Data
    public static class ConversionTypeConstraint {
        @JsonProperty("upsert-job-constraints")
        private Map<Integer, Map<String, Map<String, Constraint>>> constraints = new HashMap<>();

        @Data
        public static class Constraint {
            private List<String> allowed_management_groups;
            private List<Integer> allowed_buy_sources;
            private List<String> excluded_management_groups;
            private List<Integer> excluded_buy_sources;
        }
    }
}
