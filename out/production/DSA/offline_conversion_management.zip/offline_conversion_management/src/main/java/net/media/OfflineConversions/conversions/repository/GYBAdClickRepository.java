package net.media.OfflineConversions.conversions.repository;

import net.media.OfflineConversions.conversions.Conversion;
import net.media.OfflineConversions.conversions.models.BuyClickSPResponse;
import net.media.OfflineConversions.jobs.models.Job;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class GYBAdClickRepository extends BuyClickRepository {

    public GYBAdClickRepository(@Qualifier("semArbJdbcTemplate") JdbcTemplate dataSource, LastDateProcessedByIdRepository lastDateProcessedByIdRepository) {
        super(dataSource, lastDateProcessedByIdRepository);
        this.lastProcessedDateColumn = "lastStatsProcessDateTime";
    }

    @Override
    protected List<Conversion> transformSPResponseToConversion(List<BuyClickSPResponse> spResponseList, Job job) {
        return spResponseList.stream()
                .flatMap(it -> this.getConversionsAsPerSentClicks(it, job).stream())
                .collect(Collectors.toList());
    }

}
