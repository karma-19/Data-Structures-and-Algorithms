package net.media.OfflineConversions.enums;

import lombok.Getter;

@Getter
public enum FeatureName {
    SEM_OVERRIDE_DEVICE(43);

    private final Integer featureId;

    FeatureName(Integer featureId) {
        this.featureId = featureId;
    }
}
