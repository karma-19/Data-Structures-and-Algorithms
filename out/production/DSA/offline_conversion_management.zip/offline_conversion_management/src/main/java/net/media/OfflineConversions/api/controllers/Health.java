package net.media.OfflineConversions.api.controllers;

import net.media.OfflineConversions.api.models.response.BaseResponse;
import net.media.OfflineConversions.api.services.HealthCheckService;
import net.media.OfflineConversions.conversions.consumer.RealtimeKafkaConsumer;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class Health {
    private final HealthCheckService healthCheckService;

    public Health(HealthCheckService healthCheckService) {
        this.healthCheckService = healthCheckService;
    }

    @GetMapping("/health")
    public ResponseEntity<BaseResponse> health() {
        try {
            if (healthCheckService.pingJobsDb() && healthCheckService.pingSemArbDb() &&
                    healthCheckService.pingRedis() && RealtimeKafkaConsumer.CONSUMER_RUNNING) {
                return ResponseEntity.ok(BaseResponse.builder().message("Healthy").build());
            } else {
                return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).build();
            }
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).body(BaseResponse.builder().message("Un-healthy").build());
        }
    }
}
