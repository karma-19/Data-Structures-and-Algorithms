package net.media.OfflineConversions.utils;

import net.media.OfflineConversions.enums.SchedulerFreq;

import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

public class DateFormats {
    public final static String HOURLY_FORMAT = "yyyyMMddHH";
    public final static String DAILY_FORMAT = "yyyyMMdd00";
    public final static String CONVERSION_FORMAT = "yyyyMMdd HHmmss";
    public static final String DAY_ID_FORMAT = "yyyy-MM-dd";
    public static final String CONVERSION_SP_DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

    public static String getFormat(SchedulerFreq freq) {
        if (freq.equals(SchedulerFreq.DAILY))
            return DAILY_FORMAT;
        if (freq.equals(SchedulerFreq.HOURLY))
            return HOURLY_FORMAT;
        throw new IllegalArgumentException("No such format");
    }

    public static DateTimeFormatter getFormatter() {
        return new DateTimeFormatterBuilder()
                .appendValue(ChronoField.YEAR, 4)//https://stackoverflow.com/questions/51176936/java-8-datetimeformatter-parsing-optional-sections
                .appendPattern("MMdd[[HH]]")
                .parseDefaulting(ChronoField.HOUR_OF_DAY, 0)
                .parseDefaulting(ChronoField.MINUTE_OF_HOUR, 0)
                .parseDefaulting(ChronoField.SECOND_OF_MINUTE, 0)
                .toFormatter();
    }

}
