package net.media.OfflineConversions.dao;

import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.jobs.models.JobRunContext;
import net.media.OfflineConversions.jobs.repository.JobRunContextRepository;
import net.media.OfflineConversions.utils.JsonUtil;
import org.jetbrains.annotations.NotNull;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.ZSetOperations;
import org.springframework.stereotype.Repository;

import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

@SuppressWarnings("ALL")
@Slf4j
@Repository
public class RedisDao {
    private final RedisTemplate<String, String> redisTemplate;

    private final JobRunContextRepository repository;

    private final ListOperations<String, String> opsForList;
    private final HashOperations hashOperations;
    private final ZSetOperations zSetOperations;

    private static final String PRIORITY_JOB_REQUEST_QUEUE = "priority-job-request-queue";
    private static final String PRIORITY_JOB_IN_PROCESS_QUEUE = "priority-job-in-process-queue";
    private static final String REALTIME_JOBS_SORTED_SET = "realtime-job-sorted-set";
    private static final String REALTIME_JOB_HASH_MAP_PREFIX = "realtime-job-hm-";

    private static final String KEY_PREFIX = "ocm-";

    public RedisDao(JobRunContextRepository repository, RedisTemplate<String, String> redisTemplate) {
        this.opsForList = redisTemplate.opsForList();
        this.hashOperations = redisTemplate.opsForHash();
        this.zSetOperations = redisTemplate.opsForZSet();
        this.repository = repository;
        this.redisTemplate = redisTemplate;
    }

    // Priority Job Operations Start

    public Long getPriorityProcessingJobCount() {
        return opsForList.size(getKeyFor_PRIORITY_JOB_IN_PROCESS_QUEUE());
    }

    public void putJobInPriorityProcessingQueue(Integer jobId) {
        opsForList.rightPush(getKeyFor_PRIORITY_JOB_IN_PROCESS_QUEUE(), Objects.requireNonNull(String.valueOf(jobId)));
    }

    public boolean removeJobFromPriorityProcessingQueue(Integer jobId) {
        try {
            Long removalCount = opsForList.remove(getKeyFor_PRIORITY_JOB_IN_PROCESS_QUEUE(), 1, Objects.requireNonNull(String.valueOf(jobId)));
            return (removalCount != null && removalCount == 1L);
        } catch (Exception e) {
            log.warn("Job Id : {} Exception {}", jobId, e.getMessage());
            return false;
        }
    }

    @NotNull
    private String getKeyFor_PRIORITY_JOB_IN_PROCESS_QUEUE() {
        return KEY_PREFIX + PRIORITY_JOB_IN_PROCESS_QUEUE;
    }

    public Long getPriorityJobCount() {
        return opsForList.size(getKeyFor_PRIORITY_JOB_REQUEST_QUEUE());
    }

    public Long enqueuePriorityJob(String value) {
        return opsForList.rightPush(getKeyFor_PRIORITY_JOB_REQUEST_QUEUE(), value);
    }

    public Optional<Object> dequeuePriorityJob() {
        return Optional.ofNullable(opsForList.leftPop(getKeyFor_PRIORITY_JOB_REQUEST_QUEUE()));
    }

    @NotNull
    private String getKeyFor_PRIORITY_JOB_REQUEST_QUEUE() {
        return KEY_PREFIX + PRIORITY_JOB_REQUEST_QUEUE;
    }

    // Priority Job Operations End

    //Context Bean Operations Start

    public JobRunContext fetchContextBean(Integer jobId) {
        Optional<JobRunContext> optionalCurrentStatusBean = repository.findById(jobId.toString());
        if (optionalCurrentStatusBean.isPresent()) {
            log.info("Job Id : {} fetchContextBean", jobId);
            return optionalCurrentStatusBean.get();
        } else {
            log.warn("Unable to fetch Job Context bean for {}", jobId);
            return null;
        }
    }

    public boolean saveContextBean(JobRunContext jobRunContext, Integer jobId) {
        jobRunContext.setId(jobId.toString());
        try {
            log.info("Job Id : {} saveContextBean", jobId);
            repository.save(jobRunContext);
            return true;
        } catch (Exception e) {
            log.error("Error while saving context in redis : {}", e.getMessage());
            e.printStackTrace();

            return false;
        }
    }

    public void deleteContextBean(Integer jobId) {
        try {
            log.info("Job Id : {} deleteContextBean", jobId);
            repository.deleteById(jobId.toString());
        } catch (Exception e) {
            log.error("Error while deleting context from redis : {}", e.getMessage());
            e.printStackTrace();
        }
    }

    //Context Bean Operations End

    // Realtime Hash Map Operations Start

    // 23_2023082703
    // Hash Key for job id 23 and 3rd hr of 27 Aug
    // Value is ConversionResponse
    public void insertJobInRealtimeHashMap(String jobId_startTime, Object conversionResponse) {
        if (jobId_startTime == null || conversionResponse == null) {
            throw new IllegalArgumentException("hashName and dataObject must not be null");
        }

        try {
            Map<String, String> dataMap = JsonUtil.convertObjectToMap(conversionResponse);
            hashOperations.putAll(getKeyFor_REALTIME_JOB_HASH_MAP(jobId_startTime), dataMap);
        } catch (Exception e) {
            log.warn("Exception occurred while inserting data {} in hash {} in redis.", conversionResponse, getKeyFor_REALTIME_JOB_HASH_MAP(jobId_startTime));
            throw e;
        }
    }

    public void incrementJobsResponseInRealtimeHashMap(String jobId_startTime, Object conversionResponse) {
        if (jobId_startTime == null || conversionResponse == null) {
            throw new IllegalArgumentException("hashName and dataObject must not be null");
        }
        String realtimeJobSortedSetKey = getKeyFor_REALTIME_JOB_HASH_MAP(jobId_startTime);
        try {
            Map<String, Long> dataMap = JsonUtil.convertObjectToLongMap(conversionResponse);
            dataMap.forEach((key, value) -> hashOperations.increment(realtimeJobSortedSetKey, key, value));
        } catch (Exception e) {
            log.warn("Exception occurred while incrementing in hash {}", realtimeJobSortedSetKey);
            throw e;
        }
    }

    public boolean isJobPresentInRealtimeHashMap(String jobId_startTime) {
        try {
            return redisTemplate.hasKey(this.getKeyFor_REALTIME_JOB_HASH_MAP(jobId_startTime));
        } catch (Exception e) {
            log.warn("Exception occurred while checking for redis key {}", getKeyFor_REALTIME_JOB_HASH_MAP(jobId_startTime));
            throw e;
        }
    }

    public Map<String, Integer> getConversionResponseFromRealtimeHashMap(String jobId_startTime) {
        try {
            return hashOperations.entries(this.getKeyFor_REALTIME_JOB_HASH_MAP(jobId_startTime));
        } catch (Exception e) {
            log.warn("Exception occurred while fetching conversion requests from redis for {}", getKeyFor_REALTIME_JOB_HASH_MAP(jobId_startTime));
            throw e;
        }
    }

    public void deleteJobFromRealtimeHashMap(String jobId_startTime) {
        try {
            redisTemplate.delete(getKeyFor_REALTIME_JOB_HASH_MAP(jobId_startTime));
        } catch (Exception e) {
            log.warn("Failed to remove conversion response map form redis for key {}.", jobId_startTime);
            throw e;
        }
    }

    @NotNull
    private String getKeyFor_REALTIME_JOB_HASH_MAP(String jobId_startTime) {
        return KEY_PREFIX + REALTIME_JOB_HASH_MAP_PREFIX + jobId_startTime;
    }

    // Realtime Hash Map Operations End

    // Realtime Sorted Set Operations Start

    // Element is same as Hash Key - 23_2023082703
    // Score is data start time
    public void insertJobInRealtimeSortedSet(String jobId_startTime, double score) {
        String realtimeJobSortedSetKey = getKeyFor_REALTIME_JOBS_SORTED_SET();
        try {
            zSetOperations.addIfAbsent(realtimeJobSortedSetKey, jobId_startTime, score);
        } catch (Exception e) {
            log.warn("Exception occurred while inserting data {} in sorted set {}", jobId_startTime, realtimeJobSortedSetKey);
            throw e;
        }
    }

    public boolean isJobPresentInRealtimeSortedSet(String jobId_startTime) {
        try {
            return zSetOperations.rank(getKeyFor_REALTIME_JOBS_SORTED_SET(), jobId_startTime) != null;
        } catch (Exception e) {
            log.warn("Exception occurred while checking job in sorted set. Element {}", jobId_startTime);
            throw e;
        }
    }

    public String[] getOldestJobFromRealtimeSortedSet() {
        String realtimeJobSortedSetKey = getKeyFor_REALTIME_JOBS_SORTED_SET();
        try {
            ZSetOperations.TypedTuple<String> typedTuple = zSetOperations.popMin(realtimeJobSortedSetKey);
            if (typedTuple == null) {
                log.warn("getOldestJobFromRealtimeSortedSet returned null.");
                return null;
            }
            return new String[]{typedTuple.getValue(), String.valueOf(typedTuple.getScore())};
        } catch (Exception e) {
            log.warn("Exception occurred while sorted set pop. Sorted set {}", realtimeJobSortedSetKey);
            throw e;
        }
    }

    public Long getRealtimeSortedSetSize() {
        String realtimeJobSortedSetKey = getKeyFor_REALTIME_JOBS_SORTED_SET();
        try {
            return zSetOperations.size(realtimeJobSortedSetKey);
        } catch (Exception e) {
            log.warn("Exception occurred while checking size of sorted set {}", realtimeJobSortedSetKey);
            throw e;
        }
    }

    public String getMaxStartTimeFromRealtimeSortedSet() {
        try {
            Set<String> set = zSetOperations.reverseRangeByScore(getKeyFor_REALTIME_JOBS_SORTED_SET(), 0, Long.MAX_VALUE);
            if (set != null && set.stream().findFirst().isPresent()) {
                String[] firstValueDetails = set.stream().findFirst().get().split("_");
                if (firstValueDetails.length >= 2 && firstValueDetails[1] != null) {
                    return firstValueDetails[1];
                }
            }
        } catch (Exception e) {
            log.warn("Exception occurred while getting maximum score.");
            throw e;
        }
        return null;
    }

    @NotNull
    private String getKeyFor_REALTIME_JOBS_SORTED_SET() {
        return KEY_PREFIX + REALTIME_JOBS_SORTED_SET;
    }

    // Realtime Sorted Set Operations End
}
