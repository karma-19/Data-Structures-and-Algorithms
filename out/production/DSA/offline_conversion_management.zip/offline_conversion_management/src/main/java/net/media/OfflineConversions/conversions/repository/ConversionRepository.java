package net.media.OfflineConversions.conversions.repository;

import lombok.SneakyThrows;
import net.media.OfflineConversions.conversions.Conversion;
import net.media.OfflineConversions.enums.RevenueSource;
import net.media.OfflineConversions.enums.SchedulerFreq;
import net.media.OfflineConversions.exceptions.SPFailedException;
import net.media.OfflineConversions.jobs.models.Job;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

public abstract class ConversionRepository<T> {

    public abstract Date getMaxDateProcessed(String managementGroup) throws ParseException, SPFailedException;

    protected abstract List<T> getSPResponse(Date start, Date end, Job job, SPRowMapper spRowMapper, String revenueSource);

    protected abstract List<Conversion> transformSPResponseToConversion(List<T> spResponseList, Job job);

    protected abstract T rowMapperFunction(ResultSet resultSet) throws SQLException, ParseException;

    public int getNumberOfHours(SchedulerFreq freq) {
        switch (freq) {
            case DAILY:
                return 24;
            case HOURLY:
                return 1;
        }
        throw new IllegalArgumentException("SlotSize for given freq is not available");
    }

    protected String getEquivalentRevenueSource(String managementGroup) {
        switch (managementGroup) {
            case "O&O Social":
                return RevenueSource.AD_CLICK.toString();
        }
        return managementGroup;
    }

    public List<Conversion> getConversions(Date start, Date end, Job job) {
        List<T> listOfSPResponse = getSPResponse(start, end, job, new SPRowMapper(), getEquivalentRevenueSource(job.getManagementGroup()));
        return transformSPResponseToConversion(listOfSPResponse, job);
    }

    protected class SPRowMapper implements RowMapper<T> {
        @SneakyThrows
        @Override
        public T mapRow(ResultSet resultSet, int i) {
            return rowMapperFunction(resultSet);
        }
    }
}
