package net.media.OfflineConversions.jobs.models;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ErrorResponse {
    int errorCode; // 0 for success
    String errorMessage;
}
