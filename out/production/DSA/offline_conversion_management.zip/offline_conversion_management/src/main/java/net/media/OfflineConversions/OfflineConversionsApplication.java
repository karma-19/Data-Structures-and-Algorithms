package net.media.OfflineConversions;

import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.consumer.RealtimeKafkaConsumer;
//import net.media.sem.JwtToken.JwtTokenApplication;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Import;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;

@EnableRetry
//@SpringBootApplication
@EnableScheduling
@Slf4j
@EnableAsync
//@Import({JwtTokenApplication.class})
public class OfflineConversionsApplication implements ApplicationRunner {

    private final RealtimeKafkaConsumer realtimeKafkaConsumer;

    public OfflineConversionsApplication(RealtimeKafkaConsumer realtimeKafkaConsumer) {
        this.realtimeKafkaConsumer = realtimeKafkaConsumer;
    }

    public static void main(String[] args) {
        SpringApplication.run(OfflineConversionsApplication.class, args);
    }

    @Override
    public void run(ApplicationArguments args) {
        realtimeKafkaConsumer.startConsumer();
    }
}
