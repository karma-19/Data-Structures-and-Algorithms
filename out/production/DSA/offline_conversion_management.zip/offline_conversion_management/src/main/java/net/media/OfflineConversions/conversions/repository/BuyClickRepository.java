package net.media.OfflineConversions.conversions.repository;

import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.Conversion;
import net.media.OfflineConversions.conversions.ConversionUploadApi;
import net.media.OfflineConversions.conversions.models.BuyClickSPResponse;
import net.media.OfflineConversions.enums.ManagementGroup;
import net.media.OfflineConversions.enums.RevenueSource;
import net.media.OfflineConversions.exceptions.SPFailedException;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.utils.DateUtil;
import org.springframework.jdbc.core.JdbcTemplate;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
public abstract class BuyClickRepository extends ConversionRepository<BuyClickSPResponse> {
    protected final JdbcTemplate semArbDataSource;
    protected final LastDateProcessedByIdRepository lastDateProcessedByIdRepository;
    protected String lastProcessedDateColumn;

    protected String clickSp = "EXEC SEM_Get_Buy_Source_Click_Id_Rev_Stats " +
            "\n@date = '%s'" +
            ",\n@account_ids='%s'" +
            ",\n@min_hour_id=%s" +
            ",\n@max_hour_id=NULL" +
            "%s" +
            ",\n@paid_click_skipped=%s";

    public BuyClickRepository(JdbcTemplate semArbDataSource, LastDateProcessedByIdRepository lastDateProcessedByIdRepository) {
        this.semArbDataSource = semArbDataSource;
        this.lastDateProcessedByIdRepository = lastDateProcessedByIdRepository;
    }

    protected Double getUpdatedRevenue(Double originalRevenue, Job job) {
        double revenue = originalRevenue;
        if (job.getSourceName().equals(ConversionUploadApi.FACEBOOK_SOURCE_NAME) &&
                job.getManagementGroup().equalsIgnoreCase(String.valueOf(ManagementGroup.GINSU))) {       // Test 3 : 80% of actual
            revenue = originalRevenue * 0.8;
        }
        return revenue;
    }

    protected List<Conversion> getConversionsAsPerSentClicks(BuyClickSPResponse spResponse, Job job) {
        List<Date> conversionTimeList = DateUtil.getNRandomDates(spResponse.getMinLogTime(), spResponse.getMaxLogTime(),
                spResponse.getSentClicks());

        return conversionTimeList.stream()
                .map(date -> this.buildConversion(spResponse, job, date))
                .collect(Collectors.toList());
    }

    protected Conversion buildConversion(BuyClickSPResponse spResponse, Job job, Date conversionTime) {
        return Conversion.builder()
                .accountId(job.getAccountId())
                .campaignId(spResponse.getAdwordCampaignId())
                .conversionName(job.getConversionName())
                .conversionTime(conversionTime)
                .logHash(spResponse.getLogHash())
                .gclid(spResponse.getBuySourceClickId())
                .ip(spResponse.getIpAddress() == null ? "0" : spResponse.getIpAddress())
                .ua(spResponse.getUserAgent())
                .device(spResponse.getDevice())
                .url(spResponse.getSiteRequestUrl())
                .testDataDevice(spResponse.getTestDataDevice())
                .revenue(this.getUpdatedRevenue(spResponse.getRevenue(), job))
                .rpc(spResponse.getRpc())
                .param_1(spResponse.getParam_1())
                .param_2(spResponse.getParam_2())
                .network(spResponse.getNetwork())
                .build();
    }

    @Override
    public Date getMaxDateProcessed(String managementGroup) throws ParseException, SPFailedException {
        if (!managementGroup.equalsIgnoreCase(String.valueOf(ManagementGroup.GINSU.getManagementGroup())) &&
                !managementGroup.equalsIgnoreCase(String.valueOf(ManagementGroup.RS4C.getManagementGroup())) &&
                !managementGroup.equalsIgnoreCase(ManagementGroup.ONO_SOCIAL.getManagementGroup())) {
            throw new SPFailedException(managementGroup + " management group is not allowed for the max processed SP");
        }

        String revenueSourceName = getEquivalentRevenueSource(managementGroup);
        List<Map<String, String>> rows = lastDateProcessedByIdRepository.getLastDateProcessed(revenueSourceName);
        List<String> dates = new ArrayList<>();
        for (Map<String, String> row : rows) {
            if (row.get("stats").equals(Enum.valueOf(RevenueSource.class, revenueSourceName.toUpperCase()).getStatsColumnName()))
                dates.add(row.get(this.lastProcessedDateColumn));
        }

        // Logging to check revenue timings
        if (lastProcessedDateColumn.equals("lastRevenueProcessDateTime")) {
            log.info("Revenue available till : {}", dates.size() > 0 ? dates.get(0) : "");
        }

        return DateUtil.getMinDate(dates, LastDateProcessedByIdRepository.DATE_FORMAT);
    }

    @Override
    protected List<BuyClickSPResponse> getSPResponse(Date start, Date end, Job job, SPRowMapper rowMapper, String revenueSource) {
        String dateFormat = "yyyy-MM-dd";
        String sql = String.format(clickSp,
                DateUtil.getStringFromDate(start, dateFormat),
                job.getAccountId(),
                DateUtil.getHour(start),
                job.getSourceName().equals(ConversionUploadApi.FACEBOOK_SOURCE_NAME) ? ",@get_cs_data=1" : "",
                revenueSource.equals(RevenueSource.AD_CLICK.toString()) ? "1" : "0"
        );
        return semArbDataSource.query(sql, rowMapper);
    }

    @Override
    protected BuyClickSPResponse rowMapperFunction(ResultSet resultSet) throws SQLException, ParseException {
        return BuyClickSPResponse.builder()
                .statsDate(DateUtil.getDateFromString(resultSet.getString("stats_date"), "yyyy-MM-dd"))
                .adwordAccountId(resultSet.getString("account_id"))
                .adwordCampaignId(resultSet.getString("adword_campaign_id"))
                .buySourceClickId(resultSet.getString("buy_source_click_id"))
                .sentClicks(resultSet.getInt("sent_clicks"))
                .sentImpressions(resultSet.getInt("sent_impressions"))
                .revenue(resultSet.getDouble("revenue"))
                .rpc(resultSet.getDouble("rpc"))
                .rps(resultSet.getDouble("rps"))
                .device(resultSet.getString("device"))
                .userAgent(resultSet.getString("user_agent"))
                .ipAddress(resultSet.getString("ip_address"))
                .maxLogTime(DateUtil.getDateFromString(resultSet.getString("max_log_time"), "yyyy-MM-dd HH:mm:ss"))//2021-05-11 20:03:51.000"
                .minLogTime(DateUtil.getDateFromString(resultSet.getString("min_log_time"), "yyyy-MM-dd HH:mm:ss"))//2021-05-11 20:03:51.000"
                .siteRequestUrl(resultSet.getString("site_request_url"))
                .logHash(resultSet.getString("log_hash"))
                .testDataDevice(resultSet.getString("test_data_device"))
                .param_1(resultSet.getString("param_1"))
                .param_2(resultSet.getString("param_2"))
                .network(resultSet.getString("network"))
                .paidClicks(resultSet.getDouble("paid_clicks"))
                .build();
    }
}
