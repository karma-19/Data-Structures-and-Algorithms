package net.media.OfflineConversions.jobs.models;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AccountDetails {
    private String accountId;
    private String managementGroupName;
    private Integer sourceId;
}
