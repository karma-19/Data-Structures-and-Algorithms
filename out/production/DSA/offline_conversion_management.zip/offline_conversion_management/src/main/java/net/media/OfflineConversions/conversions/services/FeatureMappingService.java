package net.media.OfflineConversions.conversions.services;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.enums.FeatureName;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.util.UriComponentsBuilder;

@Service
@Slf4j
public class FeatureMappingService {

    private final String baseUrl;
    private final static String entityType = "account";
    private final ApiService apiService;

    public FeatureMappingService(@Value("${sfm-api.base-url}") String baseUrl, ApiService apiService) {
        this.baseUrl = baseUrl;
        this.apiService = apiService;
    }

    public boolean isTabletSkippingEnabled(String accountId) {
        UriComponentsBuilder uriComponentsBuilder = UriComponentsBuilder.fromHttpUrl(baseUrl);
        uriComponentsBuilder.queryParam("entity_type", entityType);
        uriComponentsBuilder.queryParam("entity_value", accountId);
        uriComponentsBuilder.queryParam("feature_ids", FeatureName.SEM_OVERRIDE_DEVICE.getFeatureId());
        try {
            String url = uriComponentsBuilder.toUriString();
            JsonNode jsonNode = apiService.getResponse(url);
            log.info("Feature Mapping API Call for Account : {} Response:{}", accountId, jsonNode.toString());
            boolean isSourceTablet = jsonNode.findPath(FeatureName.SEM_OVERRIDE_DEVICE.getFeatureId().toString())
                    .findPath("value").findPath("source").asText().equals("tablet");
            if (!isSourceTablet) {
                return false;
            }

            ArrayNode blockLeadPixel = (ArrayNode) jsonNode.findPath(FeatureName.SEM_OVERRIDE_DEVICE.getFeatureId().toString())
                    .findPath("value").get("block_lead_pixel");
            boolean isBlockLeadPixelFacebook = false;
            for (JsonNode node : blockLeadPixel) {
                if (node.asText().equals("facebook")) {
                    isBlockLeadPixelFacebook = true;
                    break;
                }
            }
            return isBlockLeadPixelFacebook;
        } catch (Exception e) {
            e.printStackTrace();
            log.warn("Exception occurred while checking is Tablet Skipping Enabled for account ID: {}", accountId);
            return false;
        }
    }
}
