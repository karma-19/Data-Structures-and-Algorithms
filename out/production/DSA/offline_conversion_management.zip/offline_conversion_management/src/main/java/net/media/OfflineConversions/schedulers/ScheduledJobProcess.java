package net.media.OfflineConversions.schedulers;

import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.enums.JobRunType;
import net.media.OfflineConversions.jobs.JobExecutorService;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.jobs.repository.JobRepository;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class ScheduledJobProcess {

    private final JobRepository jobRepository;
    private final ScheduledJobListRefresher scheduledJobListRefresher;
    private final JobExecutorService jobExecutorService;

    public ScheduledJobProcess(JobRepository jobRepository,
                               ScheduledJobListRefresher scheduledJobListRefresher,
                               JobExecutorService jobExecutorService) {
        this.jobRepository = jobRepository;
        this.scheduledJobListRefresher = scheduledJobListRefresher;
        this.jobExecutorService = jobExecutorService;
    }

    @Async
    @Scheduled(fixedRate = 300000, initialDelay = 10 * 60 * 1000)
    public void run() throws Exception {
        log.info("ScheduledJob Process Started");
        while (true) {
            if (ContextHolder.shutdownInitiated) return;
            List<Job> jobs = jobRepository.getScheduledJob();
            for (Job job : jobs) {
                log.info("Executing Job: " + job.getId());
                this.enrichJob(job);
                try {
                    jobExecutorService.run(job, JobRunType.SCHEDULED);
                } catch (Exception ignored) {
                }
            }
            if (jobs.isEmpty()) {
                log.info("No More Jobs Available");
                return;
            }
        }
    }

    private void enrichJob(Job job) {
        Map<Integer, Job> allJobs = scheduledJobListRefresher.getAllJobsMap();
        if (allJobs != null && allJobs.containsKey(job.getId())) {
            Job staticJob = allJobs.get(job.getId());
            job.setSkipTablet(staticJob.getSkipTablet());
            log.info("Job Id : {} Scheduled : Skip Tablet : {} from Job Map", job.getId(), job.getSkipTablet());
        }
    }

}
