package net.media.OfflineConversions.jobs.models;

public enum JobRunDetailsStatus {
    success, failed, partial_update
}
