package net.media.OfflineConversions.api.models.requests;

import lombok.Data;
import net.media.OfflineConversions.enums.JobStatus;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.List;

@Data
public class UpdateJobStatusRequest {
    @NotEmpty
    List<Integer> jobId;
    @NotNull
    JobStatus status;
}
