package net.media.OfflineConversions.enums;

public enum JobRunStatus {
    RUNNING, PENDING
}
