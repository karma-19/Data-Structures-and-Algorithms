package net.media.OfflineConversions.api.models.response;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.experimental.SuperBuilder;
import net.media.OfflineConversions.jobs.models.Job;

import java.util.List;

@Data
@EqualsAndHashCode(callSuper = true)
@SuperBuilder
public class JobInterfaceResponse extends BaseResponse {
    List<Job> jobs;
    int totalRows;

    public JobInterfaceResponse(String message) {
        super(message);
    }
}
