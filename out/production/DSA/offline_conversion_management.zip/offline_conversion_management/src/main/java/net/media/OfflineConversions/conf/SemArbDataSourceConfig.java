package net.media.OfflineConversions.conf;

import com.zaxxer.hikari.HikariDataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class SemArbDataSourceConfig {

    @Bean
    @RefreshScope
    @ConfigurationProperties("app.datasource.sem-arb")
    public DataSourceProperties semArbMemberDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean
    @RefreshScope
    @ConfigurationProperties("app.datasource.sem-arb.configuration")
    @Qualifier("semArbDataSourceHikari")
    public HikariDataSource semArbDataSourceHikari() {
        return semArbMemberDataSourceProperties().initializeDataSourceBuilder()
                .type(HikariDataSource.class).build();
    }

    @Bean
    @RefreshScope
    @Qualifier("semArbJdbcTemplate")
    public JdbcTemplate semArbJdbcTemplate(@Qualifier("semArbDataSourceHikari") HikariDataSource hikariDataSource) {
        return new JdbcTemplate(hikariDataSource);
    }
}
