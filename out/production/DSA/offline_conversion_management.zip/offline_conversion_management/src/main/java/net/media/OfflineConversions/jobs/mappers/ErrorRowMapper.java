package net.media.OfflineConversions.jobs.mappers;

import net.media.OfflineConversions.jobs.models.ErrorResponse;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;


public class ErrorRowMapper implements RowMapper<ErrorResponse> {

    @Override
    public ErrorResponse mapRow(ResultSet resultSet, int i) throws SQLException {

        return ErrorResponse.builder()
                .errorCode(resultSet.getInt("error_code"))
                .errorMessage(resultSet.getString("error_message"))
                .build();
    }
}
