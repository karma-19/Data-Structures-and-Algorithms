package net.media.OfflineConversions.schedulers;

import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.utils.DateFormats;
import net.media.OfflineConversions.utils.ZonedDateUtil;
import net.media.OfflineConversions.enums.SchedulerFreq;

import java.text.ParseException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

@Slf4j
public class TimeLogic {
    final static int MAX_RESUME_JOB_LAG_HOURS = 10;
    final static int MAX_RESUME_JOB_LAG_DAYS = 2;

    /**
     * Example :
     * Process stopped at 18:00 4th Aug ,2020 , data end time was 15:00 4th Aug ,2020
     * if
     * Process Resumed at 22:00 4th Aug ,2020 , data end time will remain same i.e 15:00 4th Aug ,2020
     * if
     * Process Resumed at 20:00 6th Aug ,2020 , data end time will be i.e 10:00 6th Aug ,2020 if only 10 hour of lag is allowed
     **/
    public static String getResumeJobDataEndTime(String endTimeString, SchedulerFreq schedulerFreq) throws ParseException {
        DateTimeFormatter formatter = DateFormats.getFormatter();
        String format = DateFormats.getFormat(schedulerFreq);
        ZonedDateTime dataEndTime = ZonedDateUtil.getDateFromString(endTimeString, formatter);
        int hours = schedulerFreq.equals(SchedulerFreq.DAILY) ?
                MAX_RESUME_JOB_LAG_DAYS * 24 : MAX_RESUME_JOB_LAG_HOURS;
        ZonedDateTime minDateAllowed = ZonedDateUtil.getCurrentTime().minusHours(hours);
        if (dataEndTime.isBefore(minDateAllowed))
            dataEndTime = minDateAllowed;
        return ZonedDateUtil.getStringFromDate(dataEndTime, format);
    }

    public static String getNewScheduleTime(String scheduledTime, SchedulerFreq schedulerFrequency) {
        try {
            int hoursToAdd = SchedulerFreq.DAILY.equals(schedulerFrequency) ? 24 : 1;
            ZonedDateTime newScheduleTime = ZonedDateUtil.getCurrentTime().plusHours(hoursToAdd);
            return ZonedDateUtil.getStringFromDate(newScheduleTime, DateFormats.HOURLY_FORMAT);
        } catch (Exception e) {
            log.error("Scheduled Time not changed . May lead to infinite loop. Error : " + e.getMessage());
            return scheduledTime;
        }
    }

}
