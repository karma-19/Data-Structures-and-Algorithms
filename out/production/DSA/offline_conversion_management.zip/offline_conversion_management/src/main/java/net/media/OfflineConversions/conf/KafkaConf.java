package net.media.OfflineConversions.conf;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.Arrays;
import java.util.Properties;

@Configuration
public class KafkaConf {

    @Value("${kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Value("${kafka.consumer.group-id}")
    private String groupId;

    @Value("${kafka.consumer.max-records-size}")
    private String maxRecordsSize;

    @Value("${kafka.consumer.max-poll-interval}")
    private String maxPollInterval;

    @Value("${kafka.consumer.topic}")
    private String consumerKafkaTopic;

    @Value("${kafka.security.protocol}")
    private String securityProtocol;

    @Value("${kafka.sasl.mechanism}")
    private String mechanism;

    @Value("${kafka.sasl.kerberos.principal}")
    private String principal;

    @Value("${kafka.sasl.kerberos.realm}")
    private String realm;

    @Value("${kafka.sasl.kerberos.keytab}")
    private String keytab;

    @Value("${kafka.sasl.kerberos.service.name}")
    private String serviceName;


    @Bean(name = "ocmRealtimeConsumerConfig")
    public Properties ocmRealtimeConsumerConfig() {
        final Properties properties = new Properties();
        properties.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        properties.setProperty(ConsumerConfig.GROUP_ID_CONFIG, groupId);
        properties.setProperty(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false");
        properties.setProperty(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, maxRecordsSize);
        properties.setProperty(ConsumerConfig.MAX_POLL_INTERVAL_MS_CONFIG, maxPollInterval);
        properties.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "latest");
        properties.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");
        properties.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, "org.apache.kafka.common.serialization.StringDeserializer");

        // Kafka security configuration
        properties.setProperty("sasl.kerberos.service.name", serviceName);
        properties.setProperty("sasl.kerberos.keytab", keytab);
        properties.setProperty("sasl.mechanism", mechanism);
        properties.setProperty("security.protocol", securityProtocol);
        properties.setProperty("sasl.kerberos.principal", principal);

        properties.setProperty("sasl.jaas.config", "com.sun.security.auth.module.Krb5LoginModule required " +
                "useKeyTab=true " +
                "keyTab=\"" + keytab + "\" " +
                "principal=\"" + principal + "\";");


        return properties;
    }

    @Bean(name = "KafkaConsumer")
    public KafkaConsumer<String, String> getKafkaConsumer() {
        KafkaConsumer<String, String> kafkaConsumer = new KafkaConsumer<>(ocmRealtimeConsumerConfig());
        kafkaConsumer.subscribe(Arrays.asList(consumerKafkaTopic.split(",")));
        return kafkaConsumer;
    }


}
