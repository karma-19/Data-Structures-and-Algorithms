package net.media.OfflineConversions.jobs.models;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ManagementGroupNameId {
    String managementGroupId;
    String managementGroupName;
}
