package net.media.OfflineConversions.utils;

import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;

public class ZonedDateUtil {
    static ZoneId zoneId = ZoneId.of("UTC");

    public static String getFormattedCurrentTime(String format) {
        return getStringFromDate(getCurrentTime(), format);
    }

    public static ZonedDateTime getCurrentTime() {
        return ZonedDateTime.now(zoneId);
    }

    public static ZonedDateTime getDateFromString(String dateInString, DateTimeFormatter format) throws ParseException {
        LocalDateTime localDateTime = LocalDateTime.parse(dateInString, format);
        return ZonedDateTime.of(localDateTime, zoneId);
    }

    public static String getStringFromDate(ZonedDateTime date, String format) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(format);
        return date.format(formatter);
    }
}
