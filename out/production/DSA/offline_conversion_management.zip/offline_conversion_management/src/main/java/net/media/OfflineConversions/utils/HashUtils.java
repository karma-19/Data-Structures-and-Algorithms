package net.media.OfflineConversions.utils;

import java.math.BigInteger;
import java.nio.charset.Charset;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public class HashUtils {

    private static final MessageDigest messageDigest = getMessageDigest();

    private static final String hashing_algo = "MD5";

    private static MessageDigest getMessageDigest() {
        try {
            return MessageDigest.getInstance(hashing_algo);
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
            return null;
        }
    }


    public static String getKeywordHash(String keyword) {
        messageDigest.reset();
        messageDigest.update(keyword.getBytes(Charset.forName("UTF8")));
        return String.format("%032x", new BigInteger(1, messageDigest.digest()));
    }
}