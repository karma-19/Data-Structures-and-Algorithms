package net.media.OfflineConversions.schedulers;

import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.ConversionUploadApi;
import net.media.OfflineConversions.conversions.services.FeatureMappingService;
import net.media.OfflineConversions.exceptions.SPFailedException;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.jobs.repository.JobRepository;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.locks.ReentrantLock;

@Slf4j
@Service
public class ScheduledJobListRefresher {
    private static final int MAX_LOCK_ATTEMPTS = 3;
    private static final long LOCK_ATTEMPT_INTERVAL = 1000;
    public static final Map<String, Set<Integer>> JOBS_SCHEDULED_TO_REALTIME = Map.of(
            "20231110 110000", Set.copyOf(Set.of(768, 769, 770, 771, 772, 773, 1034, 1035, 1036, 34, 109, 1004))
    );
    public static final Map<String, Set<Integer>> JOBS_REALTIME_TO_SCHEDULED = Map.of();

    private final JobRepository jobRepository;
    private final FeatureMappingService featureMappingService;
    private final Map<Integer, Job> allJobsMap;
    private final Map<String, List<Job>> accountToJobsMap;
    private final ReentrantLock lock;

    public ScheduledJobListRefresher(JobRepository jobRepository, FeatureMappingService featureMappingService) {
        this.jobRepository = jobRepository;
        this.allJobsMap = new ConcurrentHashMap<>();
        this.accountToJobsMap = new ConcurrentHashMap<>();
        this.lock = new ReentrantLock();
        this.featureMappingService = featureMappingService;
        this.fetchAndRefreshJobs();
    }

    @Scheduled(fixedDelay = 1 * 60 * 1000, initialDelay = 10 * 60 * 1000)     // 30 mins
    public void fetchAndRefreshJobs() {
        log.info("Refreshing All Jobs Map : Started");
        try {
            long startTime = System.currentTimeMillis();
            Map<Integer, Job> updatedJobsMap = new ConcurrentHashMap<>();
            Map<String, List<Job>> updatedAccountToJobsMap = new ConcurrentHashMap<>();
            List<Job> newJobs = jobRepository.getAllJobs();
            log.info("Fetched {} jobs", newJobs.size());
            for (Job job : newJobs) {
                if (job.getSourceName().equalsIgnoreCase(ConversionUploadApi.FACEBOOK_SOURCE_NAME)) {
                    boolean tabletSkippingEnabled = featureMappingService.isTabletSkippingEnabled(job.getAccountId());
                    log.info("Account Id : {} . Tablet Skip From API : {}", job.getAccountId(), tabletSkippingEnabled);
                    job.setSkipTablet(tabletSkippingEnabled);
                } else {
                    job.setSkipTablet(false);
                }
                updatedJobsMap.put(job.getId(), job);
                String accountId = job.getAccountId();
                updatedAccountToJobsMap.computeIfAbsent(accountId, k -> new ArrayList<>()).add(job);
            }
            if (this.tryAcquireLock()) {
                log.info("Refreshing All Jobs Map : Got Lock");
                allJobsMap.clear();
                allJobsMap.putAll(updatedJobsMap);
                accountToJobsMap.clear();
                accountToJobsMap.putAll(updatedAccountToJobsMap);
                lock.unlock();
            } else {
                log.warn("Refreshing All Jobs Map : Failed to Get Lock");
            }
            long endTime = System.currentTimeMillis();
            long executionTime = endTime - startTime;
            log.info("Refreshing All Jobs Map : took {} ms", executionTime);
        } catch (SPFailedException e) {
            log.warn("Refreshing All Jobs Map : Exception");
            e.printStackTrace();
        }
    }

    public Map<Integer, Job> getAllJobsMap() {
        if (this.tryAcquireLock()) {
            log.info("Get All Jobs Map : Got Lock");
            try {
                return Collections.unmodifiableMap(allJobsMap);
            } finally {
                lock.unlock();
            }
        }
        log.warn("Get All Jobs Map : Failed to Get Lock");
        return Collections.emptyMap();
    }

    public Map<String, List<Job>> getAccountToJobsMap() {
        if (tryAcquireLock()) {
            log.info("Get Account Jobs Map : Got Lock");
            try {
                return Collections.unmodifiableMap(accountToJobsMap);
            } finally {
                lock.unlock();
            }
        }
        log.warn("Get Account Jobs Map : Failed to Get Lock");
        return Collections.emptyMap();
    }

    private boolean tryAcquireLock() {
        int attempts = 0;
        while (attempts < MAX_LOCK_ATTEMPTS) {
            if (lock.tryLock()) {
                return true;
            }
            attempts++;

            try {
                log.info("tryAcquireLock : Sleeping for {}", LOCK_ATTEMPT_INTERVAL);
                Thread.sleep(LOCK_ATTEMPT_INTERVAL);
            } catch (InterruptedException e) {
                log.warn("tryAcquireLock : exception while sleeping");
                Thread.currentThread().interrupt();
            }
        }
        log.info("tryAcquireLock : Max attempts exhausted");
        return false;
    }

}
