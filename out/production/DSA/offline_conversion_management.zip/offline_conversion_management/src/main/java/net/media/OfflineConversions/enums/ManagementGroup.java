package net.media.OfflineConversions.enums;

import lombok.Getter;

@Getter
public enum ManagementGroup {
    ONO_SOCIAL("O&O Social"),
    GINSU("GINSU"),
    RS4C("RS4C");

    private final String managementGroup;

    ManagementGroup(String managementGroup) {
        this.managementGroup = managementGroup;
    }
}
