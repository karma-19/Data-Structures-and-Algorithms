package net.media.OfflineConversions.jobs.models;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.PropertyNamingStrategies;
import com.fasterxml.jackson.databind.annotation.JsonNaming;
import lombok.Builder;
import lombok.Data;

@Builder
@JsonNaming(PropertyNamingStrategies.SnakeCaseStrategy.class)
@Data
public class JobRunDetails {
    Integer id;
    Integer jobId;
    String dataStartTime;
    String dataEndTime;
    String dayId;
    int hrId;
    int conversions;
    int uploadedConversions;
    int skippedConversions;
    String message;
    JobRunDetailsStatus status;
    String createdTime;
    String modifiedTime;
    JsonNode conversion_details;
    JsonNode test_data;
}
