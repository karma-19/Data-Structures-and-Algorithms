package net.media.OfflineConversions.conversions.models;

import lombok.Builder;
import lombok.Data;

import java.util.Date;

@Builder
@Data
public class KeywordClickSPResponse {      // TODO : can be common SP response for adclick and keyword click
    String logHash;
    String accountId;
    String buySourceClickId;
    Date statsDate;
    Date minLogTime;
    Date maxLogTime;
    String param1;
    String param2;
    String userAgent;
    String ipAddress;
    String url;
    String device;
    String testDataDevice;
    Integer clickCount;
//    {
//        "adword_account_id": 888888262,
//            "buy_source_click_id": "v1-13a128f47e4dc3a8df3ba8b8ee8e4e81-005faa4b138b4861047520dca32acc543e-gy4tqmddgfrdillgmqzgeljug44gcllcgm2tqljymqzgkmbumvstemjxmm",
//            "log_hash": "ebefa2486a855db2d41f7fb441a55319",
//            "param_1": null,
//            "param_2": null,
//            "log_datetime": "2021-09-02 10:16:13.000",
//            "user_agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/14.1 Safari/605.1.15",
//            "ip_address": 1812783307,
//            "device": "d",
//            "test_data_device": null,
//            "site_request_url": "https://www.icananswerthat.com/topic/824/J6PD562/?utm_campaign=J6PD562&ekw=lRroukJcNxNmvXSTxOJeREQdSeiBu6SVGkKfSiYExD8=&g_ci=006ae8c5331c9e03cfc3cdf1e871fee2f0&g_ai=0048938c4af9641f2e04565be89ece5954&g_si=00236a94f7a55e7d0115402a58daa52d0a&g_pli=000a9ada70b5ec510008154979daececba&gclid=v1-13a128f47e4dc3a8df3ba8b8ee8e4e81-005faa4b138b4861047520dca32acc543e-gy4tqmddgfrdillgmqzgeljug44gcllcgm2tqljymqzgkmbumvstemjxmm&dicbo=v1-13a128f47e4dc3a8df3ba8b8ee8e4e81-005faa4b138b4861047520dca32acc543e-gy4tqmddgfrdillgmqzgeljug44gcllcgm2tqljymqzgkmbumvstemjxmm"
//    },
}
