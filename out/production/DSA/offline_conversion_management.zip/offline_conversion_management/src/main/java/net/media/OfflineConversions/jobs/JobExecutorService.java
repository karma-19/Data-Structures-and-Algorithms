package net.media.OfflineConversions.jobs;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.ConversionRepositoryFactory;
import net.media.OfflineConversions.conversions.ConversionUploadApi;
import net.media.OfflineConversions.conversions.services.ConversionModifier;
import net.media.OfflineConversions.enums.JobRunType;
import net.media.OfflineConversions.exceptions.SPFailedException;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.jobs.repository.JobRepository;
import net.media.OfflineConversions.schedulers.ContextHolder;
import net.media.OfflineConversions.schedulers.JobExecutor;
import org.springframework.stereotype.Service;

import java.text.ParseException;

@Service
@Slf4j
public class JobExecutorService {

    private final ConversionRepositoryFactory factory;
    private final JobRepository jobRepository;
    private final ConversionUploadApi conversionUploadApi;
    private final ConversionModifier conversionModifier;
    private final ContextHolder contextHolder;

    public JobExecutorService(ConversionRepositoryFactory factory, JobRepository jobRepository,
                              ConversionUploadApi conversionUploadApi, ConversionModifier conversionModifier,
                              ContextHolder contextHolder) {
        this.factory = factory;
        this.jobRepository = jobRepository;
        this.conversionUploadApi = conversionUploadApi;
        this.conversionModifier = conversionModifier;
        this.contextHolder = contextHolder;
    }

    public void run(Job job, JobRunType jobRunType) throws SPFailedException, ParseException, JsonProcessingException {
        try {
            JobExecutor jobExecutor = new JobExecutor(job, factory, jobRepository, conversionUploadApi,
                    conversionModifier, jobRunType, contextHolder);
            jobExecutor.execute();
        } catch (InterruptedException ex) {
            System.out.println("Job Id : " + job.getId() + " Interrupted Exception " + jobRunType + " : " + ex.getMessage());
        } catch (Exception e) {
            log.error("Job Id : " + job.getId() + " Global Exception " + jobRunType + ". So job would get stuck");
            e.printStackTrace();
            contextHolder.saveGlobalContext(job.getId());
            throw e;
        }
    }
}
