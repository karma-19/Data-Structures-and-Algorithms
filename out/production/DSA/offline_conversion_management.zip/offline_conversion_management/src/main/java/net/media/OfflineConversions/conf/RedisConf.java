package net.media.OfflineConversions.conf;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.lettuce.LettuceConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

@Configuration
@RefreshScope
public class RedisConf {
    @Value(value = "${app.datasource.redis.host}")
    private String host;
    @Value(value = "${app.datasource.redis.port}")
    private Integer port;
//    @Value(value = "${app.datasource.redis.database}")
//    private Integer database;
    @Value(value = "${app.datasource.redis.username}")
    private String username;
    @Value(value = "${app.datasource.redis.password}")
    private String password;

    public static final String PROJECT_KEY = "ocm-";
    public static final String JOB_STATUS_KEY = PROJECT_KEY + "job-status";

    @Bean
    @RefreshScope
    public LettuceConnectionFactory redisConnectionFactory() {
        RedisStandaloneConfiguration redisStandaloneConfiguration =
                new RedisStandaloneConfiguration(host, port);
//        redisStandaloneConfiguration.setDatabase(database);
        redisStandaloneConfiguration.setUsername(username);
        redisStandaloneConfiguration.setPassword(password);
        return new LettuceConnectionFactory(redisStandaloneConfiguration);
    }

    @Bean
    @Primary
    @RefreshScope
    public RedisTemplate<String, Object> redisTemplate() {
        RedisTemplate<String, Object> redisTemplate = new RedisTemplate<>();
        redisTemplate.setConnectionFactory(redisConnectionFactory());
        redisTemplate.setHashKeySerializer(new StringRedisSerializer());
        redisTemplate.setKeySerializer(new StringRedisSerializer());
        redisTemplate.setHashValueSerializer(new StringRedisSerializer());
        redisTemplate.setValueSerializer(new StringRedisSerializer());
        redisTemplate.afterPropertiesSet();

        return redisTemplate;
    }
}
