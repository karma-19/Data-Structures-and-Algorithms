package net.media.OfflineConversions.conversions.repository;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class LastDateProcessedRepository {
    JdbcTemplate semArbJdbcTemplate;
    String maxProcessedSp = "EXEC Get_Last_Stats_processed_hour";
    public static String DATE_FORMAT = "yyyy-MM-dd HH:mm:ss";

    public LastDateProcessedRepository(@Qualifier("semArbJdbcTemplate") JdbcTemplate semArbJdbcTemplate) {
        this.semArbJdbcTemplate = semArbJdbcTemplate;
    }

    public List<Map<String, String>> getLastDateProcessed() {
        return semArbJdbcTemplate.query(maxProcessedSp, (resultSet, i) -> {
            Map<String, String> row = new HashMap<>();
            row.put("stats", resultSet.getString("stats"));
            row.put("lastProcessDateTime", resultSet.getString("last_process_dateTime"));
            return row;
        });
    }
}
