package net.media.OfflineConversions.jobs.mappers;

import net.media.OfflineConversions.enums.ConversionType;
import net.media.OfflineConversions.jobs.models.ConversionTypeDetails;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

public class ConversionTypeDetailsRowMapper implements RowMapper<ConversionTypeDetails> {
    @Override
    public ConversionTypeDetails mapRow(ResultSet resultSet, int i) throws SQLException {
        return ConversionTypeDetails.builder()
                .id(resultSet.getInt("id"))
                .name(ConversionType.valueOf(resultSet.getString("conversion_type")))
                .build();
    }
}
