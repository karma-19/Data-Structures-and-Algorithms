package net.media.OfflineConversions.jobs.models;

import lombok.Builder;
import lombok.Data;
import net.media.OfflineConversions.enums.ConversionType;

@Data
@Builder
public class ConversionTypeDetails {
    int id;
    ConversionType name;
}
