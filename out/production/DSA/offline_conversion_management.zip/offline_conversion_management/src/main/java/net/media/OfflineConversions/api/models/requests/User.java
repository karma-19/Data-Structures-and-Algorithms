package net.media.OfflineConversions.api.models.requests;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class User {
    String user;
    int id;
}
