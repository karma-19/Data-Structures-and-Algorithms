package net.media.OfflineConversions.conversions;

import net.media.OfflineConversions.conversions.repository.*;
import net.media.OfflineConversions.enums.ConversionType;
import org.springframework.stereotype.Service;

@Service
public class ConversionRepositoryFactory {
    AdClickRepository adClickRepository;
    GYBAdClickRepository GYBAdClickRepository;
    BuyClickAuditedRepository buyClickAuditedRepository;
    KeywordClickRepository keywordClickRepository;
    MultipleBuyClickAuditedRepository multipleBuyClickAuditedRepository;

    public ConversionRepositoryFactory(AdClickRepository adClickRepository, GYBAdClickRepository GYBAdClickRepository,
                                       BuyClickAuditedRepository BuyClickAuditedRepository, KeywordClickRepository keywordClickRepository,
                                       MultipleBuyClickAuditedRepository multipleBuyClickAuditedRepository) {
        this.adClickRepository = adClickRepository;
        this.GYBAdClickRepository = GYBAdClickRepository;
        this.buyClickAuditedRepository = BuyClickAuditedRepository;
        this.keywordClickRepository = keywordClickRepository;
        this.multipleBuyClickAuditedRepository = multipleBuyClickAuditedRepository;
    }

    @SuppressWarnings("rawtypes")
    public ConversionRepository getConversionRepository(ConversionType conversionType) {
        switch (conversionType) {
            case ad_click:
                return adClickRepository;
            case ginsu_yahoo_beacon:
                return GYBAdClickRepository;
            case buy_click_audited:
                return buyClickAuditedRepository;
            case keyword_click:
                return keywordClickRepository;
            case multiple_buy_click_audited:
                return multipleBuyClickAuditedRepository;
            default:
                throw new IllegalArgumentException("No conversion repository exists with this name : " + conversionType.toString());
        }
    }
}
