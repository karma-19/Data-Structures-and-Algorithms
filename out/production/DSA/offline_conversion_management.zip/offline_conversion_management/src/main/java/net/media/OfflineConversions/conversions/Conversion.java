package net.media.OfflineConversions.conversions;

import lombok.Builder;
import lombok.Data;

import java.util.Date;

@Data
@Builder
public class Conversion {
    String accountId;
    String campaignId;
    String conversionName;
    Date conversionTime;//yyyymmdd h:i:s timezone
    String logHash;
    Double revenue;
    Double rpc;
    String gclid;
    String param_1;
    String param_2;
    String ua;
    String ip;
    String url;
    String device;
    String testDataDevice;
    String network;
    String order_id;
    String realtime_kafka_partition;
    String realtime_kafka_offset;
}
