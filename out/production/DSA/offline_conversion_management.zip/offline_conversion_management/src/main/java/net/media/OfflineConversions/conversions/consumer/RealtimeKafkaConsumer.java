package net.media.OfflineConversions.conversions.consumer;


import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.services.RealtimeConversionProcessingService;
import net.media.OfflineConversions.utils.JsonUtil;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Component
public class RealtimeKafkaConsumer {
    private final KafkaConsumer<String, String> kafkaConsumer;
    private final List<JsonNode> conversions = new ArrayList<>();

    private final RealtimeConversionProcessingService realtimeConversionProcessingService;

    public static volatile boolean CONSUMER_RUNNING = false;

    public RealtimeKafkaConsumer(RealtimeConversionProcessingService realtimeConversionProcessingService,
                                 @Qualifier("KafkaConsumer") KafkaConsumer<String, String> kafkaConsumer) {
        this.realtimeConversionProcessingService = realtimeConversionProcessingService;
        this.kafkaConsumer = kafkaConsumer;
    }

    public void stopConsumer() {
        CONSUMER_RUNNING = false;
    }

    @Async
    public void startConsumer() {
        CONSUMER_RUNNING = true;
        int errorCounter = 0;
        while (errorCounter < 30 && CONSUMER_RUNNING) {
            try {
                ConsumerRecords<String, String> consumerRecords = kafkaConsumer.poll(Duration.ofMillis(5000));

                if (!consumerRecords.isEmpty()) {
                    log.info("Fetched {} conversions for upload", consumerRecords.count());

                    for (ConsumerRecord<String, String> record : consumerRecords) {
                        if (record.value() == null) continue;
                        ObjectNode conversion = (ObjectNode) JsonUtil.getJsonNodeFromString(record.value());
                        conversion.put("realtime_kafka_offset", record.offset());
                        conversion.put("realtime_kafka_partition", record.partition());
                        conversions.add(conversion);
                    }
                }

                boolean uploadStatus = realtimeConversionProcessingService.process(conversions);

                if (uploadStatus || conversions.isEmpty()) {
                    kafkaConsumer.commitSync();
                }

                conversions.clear();
            } catch (Exception e) {
                log.error("Error in uploading conversions error_count:{} {} Sleeping for 5 seconds", errorCounter, e.getMessage());
                e.printStackTrace();
                errorCounter++;
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException exception) {
                    log.warn("Exception occurred while sleeping in kafka consumer. Message : {}", exception.getMessage());
                    exception.printStackTrace();
                }
            }
        }
        log.error("Conversion Upload Pipeline stopped");
        CONSUMER_RUNNING = false;
    }
}
