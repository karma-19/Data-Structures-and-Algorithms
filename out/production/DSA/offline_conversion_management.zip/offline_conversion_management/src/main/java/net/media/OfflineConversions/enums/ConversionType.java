package net.media.OfflineConversions.enums;

import lombok.Getter;

@Getter
public enum ConversionType {
    ad_click(1),
    keyword_click(2),
    ginsu_yahoo_beacon(3),
    buy_click_audited(5),
    ginsu_beacon_impression(6),
    multiple_buy_click_audited(7);

    private final Integer id;

    ConversionType(Integer id) {
        this.id = id;
    }

    public static ConversionType get(Integer id) {
        switch (id) {
            case 1:
                return ad_click;
            case 2:
                return keyword_click;
            case 3:
                return ginsu_yahoo_beacon;
            case 5:
                return buy_click_audited;
            case 6:
                return ginsu_beacon_impression;
            case 7:
                return multiple_buy_click_audited;
        }
        return null;
    }

}
