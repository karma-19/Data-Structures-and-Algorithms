package net.media.OfflineConversions.schedulers;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.ConversionRepositoryFactory;
import net.media.OfflineConversions.dao.RedisDao;
import net.media.OfflineConversions.enums.JobRunType;
import net.media.OfflineConversions.exceptions.SPFailedException;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.jobs.models.JobRunDetailsStatus;
import net.media.OfflineConversions.jobs.models.JobRunDetailsTestData;
import net.media.OfflineConversions.jobs.repository.JobRepository;
import net.media.OfflineConversions.utils.DateFormats;
import net.media.OfflineConversions.utils.DateUtil;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.Date;
import java.util.List;


@Service
@Slf4j
public class ScheduledStuckJobProcess {
    final int BATCH_SIZE = 5;
    final int STUCK_JOB_HOUR_THRESHOLD = 3;
    JobRepository jobRepository;
    ConversionRepositoryFactory factory;
    RedisDao redisDao;

    public ScheduledStuckJobProcess(JobRepository jobRepository,
                                    ConversionRepositoryFactory conversionRepositoryFactory,
                                    RedisDao redisDao) {
        this.jobRepository = jobRepository;
        this.factory = conversionRepositoryFactory;
        this.redisDao = redisDao;
    }

    @Scheduled(fixedDelay = 3600000, initialDelay = 10 * 60 * 1000)
    public void run() throws SPFailedException, JsonProcessingException, ParseException {
        log.info("Scheduled Stuck Job Process Started");
        List<Job> jobs = jobRepository.getStuckJobs(BATCH_SIZE, STUCK_JOB_HOUR_THRESHOLD);
        for (Job job : jobs) {
            log.error("Job Id : " + job.getId() + "Stuck Job found. AccountId :" + job.getAccountId());
            Date dateStartTime = DateUtil.getDateFromString(job.getDataEndTime(), DateFormats.HOURLY_FORMAT);
            int numberOfHourSlots = factory.getConversionRepository(job.getConversionType()).getNumberOfHours(job.getSchedulerFrequency());
            JobRunDetailsTestData jobRunDetailsTestData = JobRunDetailsTestData.builder()
                    .jobRunType(JobRunType.STUCK)
                    .build();
            jobRepository.handleZeroConversionsScenario(job, dateStartTime, numberOfHourSlots, "Stuck Job",
                    JobRunDetailsStatus.failed, jobRunDetailsTestData, job.getSchedulerFrequency());
            if (redisDao.removeJobFromPriorityProcessingQueue(job.getId())) {
                log.info("Job Id : {}. Removed priority stuck job from redis.", job.getId());
            }
        }
        log.info("Scheduled Stuck Job Process Ended");
    }
}
