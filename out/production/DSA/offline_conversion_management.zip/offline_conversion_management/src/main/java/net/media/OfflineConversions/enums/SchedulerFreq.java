package net.media.OfflineConversions.enums;

public enum SchedulerFreq {
    HOURLY, DAILY
}
