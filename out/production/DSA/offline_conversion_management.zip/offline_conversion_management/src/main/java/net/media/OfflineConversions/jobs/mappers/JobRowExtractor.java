package net.media.OfflineConversions.jobs.mappers;

import net.media.OfflineConversions.api.models.response.JobInterfaceResponse;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class JobRowExtractor implements ResultSetExtractor<JobInterfaceResponse> {
    @Override
    public JobInterfaceResponse extractData(ResultSet resultSet) throws SQLException, DataAccessException {
        JobInterfaceResponse interfaceResponse = JobInterfaceResponse.builder().jobs(new ArrayList<>()).build();
        Statement statement;
        while (true) {
            statement = resultSet.getStatement();
            int columnCount = resultSet.getMetaData().getColumnCount();
            if (columnCount == 1 && resultSet.getMetaData().getColumnLabel(1).equals("total_rows") && resultSet.next()) {
                interfaceResponse.setTotalRows(resultSet.getInt("total_rows"));
            } else if (columnCount > 2) {       // 3rd result set has error number
                while (resultSet.next()) {
                    interfaceResponse.getJobs().add(new JobRowMapper().mapRow(resultSet, 0));
                }
            }

            if (statement.getMoreResults()) {
                resultSet = statement.getResultSet();
            } else
                break;
        }

        return interfaceResponse;
    }
}
