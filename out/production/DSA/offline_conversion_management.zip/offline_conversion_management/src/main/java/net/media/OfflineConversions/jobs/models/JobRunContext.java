package net.media.OfflineConversions.jobs.models;

import lombok.Data;
import lombok.NoArgsConstructor;
import net.media.OfflineConversions.conf.RedisConf;
import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;

import java.io.Serializable;
import java.util.Date;

@RedisHash(RedisConf.JOB_STATUS_KEY)
@Data
@NoArgsConstructor
// Stores Context of current Run of assigned Job
public class JobRunContext implements Serializable {
    @Id
    private String id;

    // used to check whether current context is fetched from Redis
    private Boolean isCachedData = false;

    // minimum start time of the current run
    private Date minStartTime;

    // maximum start time of the current run
    private Date maxStartTime;

    // time of current run
    private String formattedCurrentTime;

    // current conversion index being uploaded
    private Integer currentConversionIndex;

    // status of current conversion upload
    private Boolean currentConversionUploadStatus;

    // current date slot index being executed
    private Integer currentSlotIndex;

    // status of current date slot execution
    private Boolean currentSlotCompletionStatus;

    // status of whether job run is saved in DB or not
    private Boolean currentSlotCompletionUpdateStatus;

    // success(numbers from DB post calculated == uploaded numbers) status for for all slots of a job
    private Boolean uploadedAllSlotsStatus;

    // status of conversion upload of all slots of a job
    private Boolean jobConversionUploadStatus = false;

    // status of Jobs Table updates after successful completion of whole job(all slots)
    private Boolean jobCompletionUpdateStatus = false;
}
