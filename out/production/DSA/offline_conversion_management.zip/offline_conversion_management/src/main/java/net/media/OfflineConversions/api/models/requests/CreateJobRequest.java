package net.media.OfflineConversions.api.models.requests;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.Builder;
import lombok.Data;
import net.media.OfflineConversions.enums.JobType;
import net.media.OfflineConversions.enums.SchedulerFreq;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
@Builder
public class CreateJobRequest {
    @NotBlank
    String accountId;
    @NotNull
    Integer conversionTypeId;
    @NotBlank
    String conversionName;
    @NotNull
    SchedulerFreq schedulerFrequency;
    @NotNull
    JobType jobType;

    String pixelId;
    JsonNode additionalData;
    JsonNode testData;
}
