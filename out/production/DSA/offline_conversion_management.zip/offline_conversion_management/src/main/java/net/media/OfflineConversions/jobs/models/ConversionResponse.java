package net.media.OfflineConversions.jobs.models;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import net.media.OfflineConversions.conversions.ConversionApiResponse;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
public class ConversionResponse {
    int uploadCount;
    int expiredCount;
    int invalidCount;
    int unparseableGclid;
    int tooRecentCount;
    int unknownErrorCount;
    int filterCount;
    int duplicateCount;
    int emptyClickIdSkipped;
    int tabletSkipped;

    int conversionsToBeUploaded;
    int conversionsFromDb;

    public int getTotalConversions() {
        return this.uploadCount + this.expiredCount + this.invalidCount + this.unparseableGclid + this.tooRecentCount
                + this.unknownErrorCount + this.filterCount + this.duplicateCount;
    }

    public void increment(ConversionApiResponse conversionType, int count) {
        switch (conversionType) {
            case SUCCESS:
                this.uploadCount += count;
                break;
            case EXPIRED:
                this.expiredCount += count;
                break;
            case INVALID_CLICK:
                this.invalidCount += count;
                break;
            case TOO_RECENT:
                this.tooRecentCount += count;
                break;
            case UNPARSEABLE_CLICK_ID:
                this.unparseableGclid += count;
                break;
            case UNKNOWN_ERROR:
                this.unknownErrorCount += count;
                break;
            case DUPLICATE:
                this.duplicateCount += count;
                break;
            case FILTERED:
                this.filterCount += count;
                break;
        }
    }

    public void merge(ConversionResponse conversionResponse) {
        this.uploadCount += conversionResponse.getUploadCount();
        this.expiredCount += conversionResponse.getExpiredCount();
        this.invalidCount += conversionResponse.getInvalidCount();
        this.unparseableGclid += conversionResponse.getUnparseableGclid();
        this.tooRecentCount += conversionResponse.getTooRecentCount();
        this.unknownErrorCount += conversionResponse.getUnknownErrorCount();
        this.filterCount += conversionResponse.getFilterCount();
        this.emptyClickIdSkipped += conversionResponse.getEmptyClickIdSkipped();
        this.tabletSkipped += conversionResponse.getTabletSkipped();
        this.duplicateCount += conversionResponse.getDuplicateCount();
        this.conversionsToBeUploaded += conversionResponse.getConversionsToBeUploaded();
        this.conversionsFromDb += conversionResponse.getConversionsFromDb();
    }

}


