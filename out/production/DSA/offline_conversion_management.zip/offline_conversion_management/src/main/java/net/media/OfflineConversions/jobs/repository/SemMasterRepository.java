package net.media.OfflineConversions.jobs.repository;

import net.media.OfflineConversions.jobs.models.AccountDetails;
import net.media.OfflineConversions.jobs.models.ManagementGroupNameId;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Repository
public class SemMasterRepository {
    JdbcTemplate semMasterJdbcTemplate;
    String GET_MANAGEMENT_GROUP_IDS_QUERY = "SELECT  * FROM management_group_master ;";

    public SemMasterRepository(@Qualifier("semMasterJdbcTemplate") JdbcTemplate semMasterJdbcTemplate) {
        this.semMasterJdbcTemplate = semMasterJdbcTemplate;
    }

    public List<ManagementGroupNameId> getManagementGroupIds() {
        return semMasterJdbcTemplate.query(GET_MANAGEMENT_GROUP_IDS_QUERY, (resultSet, i) -> ManagementGroupNameId.builder()
                .managementGroupId(resultSet.getString("management_group_id"))
                .managementGroupName(resultSet.getString("management_group_name"))
                .build());
    }

    public List<String> getAccountIds(List<String> accountIds) {
        String sql = "SELECT adword_account_id from accounts where";
        if (accountIds == null || accountIds.size() == 0)
            return new ArrayList<>();
        sql = sql + " adword_account_id = " + "'" + accountIds.get(0) + "'";
        for (int i = 1; i < accountIds.size(); i++) {
            sql = sql + " or adword_account_id = " + "'" + accountIds.get(i) + "'";
        }
        return semMasterJdbcTemplate.query(sql, (resultSet, i) -> resultSet.getString("adword_account_id"));
    }

    // TODO : refresh it every 15 minutes via SP
    public Map<String, AccountDetails> getAccountsWithAccountDetails(List<String> accountIds) {
        int size = accountIds.size();

        if (size == 0) {
            return new HashMap<>();
        }

        StringBuilder sql = new StringBuilder("SELECT adword_account_id, management_group, source_id " +
                "from accounts " +
                "where ");

        for (int i = 0; i < size; i++) {
            sql.append("adword_account_id = " + "'").append(accountIds.get(i)).append("'");
            if (i != size - 1) {
                sql.append(" or ");
            }
        }

        List<AccountDetails> response = semMasterJdbcTemplate.query(sql.toString(), (resultSet, i) ->
                AccountDetails.builder()
                        .accountId(resultSet.getString("adword_account_id"))
                        .managementGroupName(resultSet.getString("management_group"))
                        .sourceId(resultSet.getInt("source_id"))
                        .build()
        );

        Map<String, AccountDetails> ans = new HashMap<>();
        response.forEach(m -> ans.put(m.getAccountId(), m));
        return ans;
    }

}
