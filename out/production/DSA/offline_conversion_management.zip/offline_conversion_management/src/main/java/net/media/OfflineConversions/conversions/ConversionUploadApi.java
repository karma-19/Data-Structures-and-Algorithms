package net.media.OfflineConversions.conversions;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.models.ConversionRequestBean;
import net.media.OfflineConversions.conversions.services.ConversionModifier;
import net.media.OfflineConversions.enums.ConversionType;
import net.media.OfflineConversions.enums.JobType;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.schedulers.ScheduledJobListRefresher;
import net.media.OfflineConversions.utils.DateFormats;
import net.media.OfflineConversions.utils.DateUtil;
import net.media.OfflineConversions.utils.JsonUtil;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import java.net.URI;
import java.net.URISyntaxException;
import java.text.ParseException;
import java.util.Date;
import java.util.Map;
import java.util.Set;

@Service
@Slf4j
public class ConversionUploadApi {
    final int MAX_RETRY = 4;

    public static final String FACEBOOK_SOURCE_NAME = "facebook";
    public static final int FACEBOOK_SOURCE_ID = 2;
    public static final String TIKTOK_SOURCE_NAME = "Tiktok";
    public static final int TIKTOK_SOURCE_ID = 30;
    public static final String TABOOLA_SOURCE_NAME = "taboola";
    public static final String GOOGLE_SOURCE_NAME = "google";

    private static final String FB_CONVERSION_CALL_TYPE = "fb_conversion";
    private static final String FB_CONVERSION_ACTION_SOURCE = "website";

    RestTemplate restTemplate;
    String baseUrl;
    String profile;

    public ConversionUploadApi(RestTemplate restTemplate,
                               @Value("${spring.profiles.active}") String profile,
                               @Value("${upload-api.base-url}") String baseUrl
    ) {
        this.restTemplate = restTemplate;
        this.profile = profile;
        this.baseUrl = baseUrl;
    }

    @Async
    public void sendAsync(ConversionRequestBean conversionRequestBean) {
        int tryCount = 0;
        String urlWithParam = getUrlWithParameters(conversionRequestBean);
        if (true) {
            log.info(urlWithParam);
            return;
        }
        getConversionApiResponse("realtime", tryCount, urlWithParam, -1);
    }

    public ConversionApiResponse send(Conversion conversion, Job job, JobType sourceType) {
        int tryCount = 0;
        String urlWithParam = _getUrlWithParameters(conversion, job, sourceType);
        if (this.filterConversion(conversion, job) ||
                this.filterConversionByJobType(conversion, job, sourceType,
                        ScheduledJobListRefresher.JOBS_SCHEDULED_TO_REALTIME, JobType.SCHEDULED, JobType.REALTIME) ||
                this.filterConversionByJobType(conversion, job, sourceType,
                        ScheduledJobListRefresher.JOBS_REALTIME_TO_SCHEDULED, JobType.REALTIME, JobType.SCHEDULED)) {
            return ConversionApiResponse.FILTERED;
        }
        if (true) {
            log.info(urlWithParam);
            return ConversionApiResponse.SUCCESS;
        }
        return getConversionApiResponse(job.getId().toString(), tryCount, urlWithParam, job.getSourceId());
    }

    private boolean filterConversionByJobType(Conversion conversion, Job job, JobType sourceType,
                                              Map<String, Set<Integer>> specialJobMap,
                                              JobType previousType, JobType targetType) {
        //TODO: Moynak : temp code
        for (Map.Entry<String, Set<Integer>> entry : specialJobMap.entrySet()) {
            if (entry.getValue().contains(job.getId())) {
                try {
                    Date inflectionPointDate = DateUtil.getDateFromString(entry.getKey(), DateFormats.CONVERSION_FORMAT);
                    if (sourceType.equals(previousType) && conversion.getConversionTime().after(inflectionPointDate)) {
                        return true;
                    }
                    if (
                            sourceType.equals(targetType) && (conversion.getConversionTime().before(inflectionPointDate) ||
                                    conversion.getConversionTime().equals(inflectionPointDate))
                    ) {
                        return true;
                    }
                } catch (ParseException e) {
                    log.warn("Exception while checking dates : {}", e.getMessage());
                }
            }
        }
        return false;
    }

    private ConversionApiResponse getConversionApiResponse(String id, int tryCount, String urlWithParam, int sourceId) {
        while (tryCount < MAX_RETRY) {
            ResponseEntity<String> response;
            try {
                long startTime = System.currentTimeMillis();
                response = restTemplate.exchange(new URI(urlWithParam), HttpMethod.GET, null, String.class);
                long endTime = System.currentTimeMillis();
                log.info("Job Id : {} conversion_api_response_time = {} response_code = {}", id, endTime - startTime, response.getStatusCodeValue());
                if (response.getStatusCodeValue() == 200) {
                    try {
                        JsonNode res = JsonUtil.getJsonNodeFromString(response.getBody());
                        if (res.get("status").asText().equals("success"))
                            return ConversionApiResponse.SUCCESS;
                        if (res.get("status").asText().equals("error")) {
                            log.info("JobId: " + id + " :Url - " + urlWithParam);
                            log.warn("JobId: " + id + " :Response - : " + response.toString());
                            return ConversionApiResponse.getError(sourceId, res);
                        }
                    } catch (NullPointerException | JsonProcessingException e) {
                        log.warn("JobId: " + id + "Exception in response parsing . url : " + urlWithParam + "Error : " + response.toString());
                        log.error("JobId: " + id + "Exception in response parsing . error : " + e.getMessage());
                        return ConversionApiResponse.UNKNOWN_ERROR;
                    }
                    log.error("JobId: " + id + "Unknown 200 response . url : " + urlWithParam + "Error : " + response.toString());
                    return ConversionApiResponse.UNKNOWN_ERROR;
                }

                tryCount++;
                log.warn("JobId: " + id + " Trial count: {} failed. Sleeping for sometime ...", tryCount);
            } catch (URISyntaxException e) {        // url creation can throw
                log.error("JobId: " + id + "Error creating URl : " + urlWithParam + " error message : " + e.getMessage());
                return ConversionApiResponse.UNKNOWN_ERROR;
            } catch (Exception e) {
                log.warn("JobId: " + id + " Unknown exception : url : " + urlWithParam + " error message : " + e.getMessage());
                tryCount++;
                if (tryCount == MAX_RETRY) {
                    log.error("JobId: " + id + " Unknown exception : url : " + urlWithParam);
                }
            }
        }
        log.error("Upload Conversion API request failed : " + urlWithParam);
        return ConversionApiResponse.UNKNOWN_ERROR;
    }

    private String getUrlWithParameters(ConversionRequestBean conversionBean) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl);
        builder.queryParam("account_id", conversionBean.getAccountId());
        builder.queryParam("conversion_name", conversionBean.getConversionName());
        builder.queryParam("conversion_time", conversionBean.getConversionTime() + " UTC");
        builder.queryParam("log_hash", conversionBean.getLogHash());
        builder.queryParam("gclid", conversionBean.getBuyClickId());
        builder.queryParam("sm_call_type", "realtime");
        return builder.toUriString();
    }

    // FB : ?account_id=1976904199167281&conversion_name=Lead&conversion_time=20231011%20130241%20UTC&log_hash=a108bbd4bfbc2220d0265b6e44aca674&sm_call_type=realtime-kafka&param_1=fb.1.1697029316877.1015338252&param_2=fb.1.1697029316860.IwAR2A10FKde4EFpjjNC7h2IMtjUi6VskWu3J9CW47IESjb05OkUKpECW0rqM_aem_Aa418S2JrMXLyYUIuWgKe1xxNKvtZpgL-hdNEWCjV_w_XFg_na8w9VFzg0vSJlW3yDdco3tkfVS1V6smBcNum7lP&call_type=fb_conversion&action_source=website&event_id=a108bbd4bfbc2220d0265b6e44aca674&pixel_id=726197411776903&ua=Mozilla/5.0%20(Linux;%20Android%2010;%20U318AA%20Build/QP1A.190711.020;%20wv)%20AppleWebKit/537.36%20(KHTML,%20like%20Gecko)%20Version/4.0%20Chrome/116.0.0.0%20Mobile%20Safari/537.36%5BFBAN/EMA;FBLC/en_US;FBAV/372.0.0.15.104;%5D&ip=107.77.198.204&url&external_id=a108bbd4bfbc2220d0265b6e44aca674&gclid=fb.1.1697029361000.IwAR2A10FKde4EFpjjNC7h2IMtjUi6VskWu3J9CW47IESjb05OkUKpECW0rqM_aem_Aa418S2JrMXLyYUIuWgKe1xxNKvtZpgL-hdNEWCjV_w_XFg_na8w9VFzg0vSJlW3yDdco3tkfVS1V6smBcNum7lP
// Tiktok :
    private String _getUrlWithParameters(Conversion conversion, Job job, JobType sourceType) {
        UriComponentsBuilder builder = UriComponentsBuilder.fromHttpUrl(baseUrl);
        builder.queryParam("job_id", job.getId().toString());
        builder.queryParam("account_id", conversion.getAccountId());
        builder.queryParam("conversion_name", conversion.getConversionName());
        builder.queryParam("conversion_time", DateUtil.getStringFromDate(conversion.getConversionTime(), DateFormats.CONVERSION_FORMAT) + " UTC");
        builder.queryParam("log_hash", conversion.getLogHash());
        builder.queryParam("sm_call_type", sourceType.equals(JobType.SCHEDULED) ? "job" : "realtime-kafka");

        if (conversion.getRealtime_kafka_offset() != null &&
                conversion.getRealtime_kafka_partition() != null) {
            builder.queryParam("rko", conversion.getRealtime_kafka_offset());
            builder.queryParam("rkp", conversion.getRealtime_kafka_partition());
        }

        if (conversion.getCampaignId() != null) {
            builder.queryParam("g_ci", conversion.getCampaignId());
        }

        if (job.getConversionType().equals(ConversionType.buy_click_audited) && conversion.getRevenue() != null) {
            builder.queryParam("conversion_value", (double) Math.round(conversion.getRevenue() * 100) / 100);
        } else if (job.getConversionType().equals(ConversionType.multiple_buy_click_audited) && conversion.getRpc() != null) {
            builder.queryParam("conversion_value", (double) Math.round(conversion.getRpc() * 100) / 100);
        }

        if (job.getSourceName().equals(FACEBOOK_SOURCE_NAME)) {
            builder.queryParam("param_1", conversion.getParam_1());
            builder.queryParam("param_2", conversion.getParam_2());
            builder.queryParam("call_type", FB_CONVERSION_CALL_TYPE);
            builder.queryParam("action_source", FB_CONVERSION_ACTION_SOURCE);
            builder.queryParam("event_id", conversion.getLogHash());
            builder.queryParam("external_id", conversion.getLogHash());
            this.addCommonProperties(conversion, job, builder);
            builder.queryParam("gclid", "fb.1." + formatTimeForFb(conversion.getConversionTime()) + "." + conversion.getGclid());
        } else if (job.getSourceName().equals(TIKTOK_SOURCE_NAME)) {
            this.addCommonProperties(conversion, job, builder);
            builder.queryParam("gclid", conversion.getGclid());
        } else if (ConversionModifier.isJobGinsuTaboola(job) || ConversionModifier.isJobMultipleAuditedGoogle(job)) {
            builder.queryParam("external_id", conversion.getOrder_id());
            builder.queryParam("gclid", conversion.getGclid());
        } else
            builder.queryParam("gclid", conversion.getGclid());
        return builder.toUriString();
    }

    private void addCommonProperties(Conversion conversion, Job job, UriComponentsBuilder builder) {
        builder.queryParam("pixel_id", _getPixelId(job));
        builder.queryParam("ip", longToIp(Long.parseLong(conversion.getIp() == null ? "0" : conversion.getIp())));
        builder.queryParam("ua", conversion.getUa());
        builder.queryParam("url", conversion.getUrl());
    }

    private Long formatTimeForFb(Date conversionTime) {
        return conversionTime.getTime();
    }

    public String longToIp(long ip) {
        //https://mkyong.com/java/java-convert-ip-address-to-decimal-number/
        StringBuilder result = new StringBuilder(15);

        for (int i = 0; i < 4; i++) {

            result.insert(0, Long.toString(ip & 0xff));

            if (i < 3) {
                result.insert(0, '.');
            }

            ip = ip >> 8;
        }
        return result.toString();
    }

    private String _getPixelId(Job job) {
        if (job.getPixelId() != null && !job.getPixelId().isEmpty()) {
            return job.getPixelId();
        } else {
            log.error("No pixel Id for JobId : " + job.getId() + " ; accountId: " + job.getAccountId());
            return "";
        }
    }

    private boolean filterConversion(Conversion conversion, Job job) {
        return false;
    }

}