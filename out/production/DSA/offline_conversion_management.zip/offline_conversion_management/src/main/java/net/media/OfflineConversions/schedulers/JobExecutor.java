package net.media.OfflineConversions.schedulers;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.Conversion;
import net.media.OfflineConversions.conversions.ConversionApiResponse;
import net.media.OfflineConversions.conversions.ConversionRepositoryFactory;
import net.media.OfflineConversions.conversions.ConversionUploadApi;
import net.media.OfflineConversions.conversions.repository.ConversionRepository;
import net.media.OfflineConversions.conversions.services.ConversionModifier;
import net.media.OfflineConversions.enums.ConversionType;
import net.media.OfflineConversions.enums.JobRunStatus;
import net.media.OfflineConversions.enums.JobRunType;
import net.media.OfflineConversions.enums.JobType;
import net.media.OfflineConversions.exceptions.SPFailedException;
import net.media.OfflineConversions.jobs.models.*;
import net.media.OfflineConversions.jobs.repository.JobRepository;
import net.media.OfflineConversions.utils.DateFormats;
import net.media.OfflineConversions.utils.DateUtil;
import net.media.OfflineConversions.utils.JsonUtil;
import net.media.OfflineConversions.utils.ZonedDateUtil;

import java.text.ParseException;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Slf4j
public class JobExecutor {
    private final Job job;
    private final JobRunType jobRunType;

    private final String dateFormat;

    private final JobRepository jobRepository;
    private final ConversionModifier conversionModifier;

    private final ContextHolder contextHolder;
    private final GlobalJobContext globalJobContext;
    private JobRunContext jobRunContext;

    @SuppressWarnings("rawtypes")
    private final ConversionRepository conversionRepository;
    private final ConversionUploadApi conversionUploadApi;

    private static final String NO_CONVERSIONS_AVAILABLE_MESSAGE = "No conversions available yet";
    private static final String UNABLE_TO_GET_MAX_PROCESSED_DATE_MESSAGE = "Error while getting max processed date of dependent tables/processes.";

    public JobExecutor(Job job, ConversionRepositoryFactory conversionRepositoryFactory,
                       JobRepository jobRepository, ConversionUploadApi conversionUploadApi,
                       ConversionModifier conversionModifier, JobRunType jobRunType, ContextHolder contextHolder) {
        this.dateFormat = DateFormats.getFormat(job.getSchedulerFrequency());
        this.job = job;
        this.conversionRepository = conversionRepositoryFactory.getConversionRepository(job.getConversionType());

        this.jobRepository = jobRepository;
        this.jobRunType = jobRunType;

        this.conversionUploadApi = conversionUploadApi;
        this.conversionModifier = conversionModifier;

        this.contextHolder = contextHolder;

        this.globalJobContext = new GlobalJobContext(this.job);
        contextHolder.createGlobalJobContext(this.globalJobContext);

        this.jobRunContext = globalJobContext.getJobRunContext();

        if (this.jobRunContext.getIsCachedData()) {
            try {
                this.preExecute();
            } catch (Exception e) {
                log.warn("Exception while pre execution of job: {} {}", this.job.getId(), e.getMessage());
            }
        }
    }

    private void preExecute() throws SPFailedException, JsonProcessingException {
        if (this.jobRunContext.getMinStartTime() == null ||             // this means earlier job got killed before any uploads or setting of redis context
                this.jobRunContext.getMaxStartTime() == null ||
                this.jobRunContext.getJobCompletionUpdateStatus()) {    // DB is updated (everything is proper)
            log.info("Job Id : " + job.getId() + " preExecute not needed");
            return;
        }

        if (!this.jobRunContext.getJobCompletionUpdateStatus() && this.jobRunContext.getJobConversionUploadStatus()) {
            // Job is completed but DB update remaining
            this.updateJobAsComplete(this.jobRunContext.getFormattedCurrentTime(), this.jobRunContext.getUploadedAllSlotsStatus(), true);
            contextHolder.refreshRunDetailsContext(this.globalJobContext);
            this.jobRunContext = globalJobContext.getJobRunContext();       // this is needed to have refreshed copy in this class
        }
    }

    public void execute() throws SPFailedException, JsonProcessingException, ParseException, InterruptedException {
        JobRunDetailsTestData jobRunDetailsTestData = JobRunDetailsTestData.builder().jobRunType(jobRunType).build();
        this.globalJobContext.setJobRunDetailsTestData(jobRunDetailsTestData);

        Integer jobId = job.getId();
        String formattedCurrentTime = ZonedDateUtil.getFormattedCurrentTime(DateFormats.HOURLY_FORMAT);
        int numberOfHours = conversionRepository.getNumberOfHours(job.getSchedulerFrequency());

        Date newMinStartTime = this.setMinStartTime(jobRunDetailsTestData, jobId);
        Date newMaxStartTime;
        try {
            newMaxStartTime = this.setMaxStartTime(jobRunDetailsTestData, jobId, formattedCurrentTime);
        } catch (ParseException | SPFailedException e) {
            log.error("Job Id : " + jobId + " " + UNABLE_TO_GET_MAX_PROCESSED_DATE_MESSAGE + e.getMessage());
            jobRepository.handleZeroConversionsScenario(job, newMinStartTime, numberOfHours, UNABLE_TO_GET_MAX_PROCESSED_DATE_MESSAGE,
                    JobRunDetailsStatus.failed, jobRunDetailsTestData, job.getSchedulerFrequency());
            this.jobRunContext.setJobCompletionUpdateStatus(true);  // setting this is necc bcz if code breaks post this then this will be saved in redis
            contextHolder.removeGlobalContext(this.job.getId());
            return;
        }

        this.processTimeSlots(newMinStartTime, newMaxStartTime, jobRunDetailsTestData, numberOfHours, formattedCurrentTime);
        contextHolder.removeGlobalContext(this.job.getId());
    }

    private Date setMinStartTime(JobRunDetailsTestData jobRunDetailsTestData, Integer jobId) throws ParseException {
        Date newMinStartTime;           // old end time
        if (this.jobRunContext.getMinStartTime() != null) {
            newMinStartTime = this.jobRunContext.getMinStartTime();
        } else {
            newMinStartTime = DateUtil.getDateFromString(job.getDataEndTime(), DateFormats.HOURLY_FORMAT);
        }
        jobRunDetailsTestData.setNewMinStartTime(DateUtil.getStringFromDate(newMinStartTime, DateFormats.CONVERSION_SP_DATE_FORMAT));
        this.jobRunContext.setMinStartTime(newMinStartTime);
        log.info("Job Id : {} Min Start Time:{}", jobId, newMinStartTime);
        return newMinStartTime;
    }

    private Date setMaxStartTime(JobRunDetailsTestData jobRunDetailsTestData, Integer jobId, String formattedCurrentTime) throws ParseException, SPFailedException {
        Date newMaxStartTime;
        newMaxStartTime = conversionRepository.getMaxDateProcessed(job.getManagementGroup());
        log.info("Job Id : {} max date processed: {}", jobId, newMaxStartTime);
        newMaxStartTime = this.getBufferedMaxStartTime(newMaxStartTime);     // to ensure that data till 2 hours is populated well
        jobRunDetailsTestData.setBufferedMaxStartTime(DateUtil.getStringFromDate(newMaxStartTime, DateFormats.CONVERSION_SP_DATE_FORMAT));

        Date runTimeAsPerDefiniteGap = DateUtil.subtractHours(
                DateUtil.getDateFromString(formattedCurrentTime, DateFormats.HOURLY_FORMAT),
                (job.getConversionType().equals(ConversionType.buy_click_audited) ||
                        job.getConversionType().equals(ConversionType.multiple_buy_click_audited)) ? 4 : 0);
        log.info("Job Id : {}  buffered max data start time: {} gap run time : {}", jobId, newMaxStartTime, runTimeAsPerDefiniteGap);

        List<Date> dates = Arrays.asList(newMaxStartTime, runTimeAsPerDefiniteGap);
        newMaxStartTime = DateUtil.getMinDate(dates);
        newMaxStartTime = DateUtil.changeDateFormat(newMaxStartTime, DateFormats.HOURLY_FORMAT, dateFormat);

        jobRunDetailsTestData.setRunTimeAsPerDefiniteGap(DateUtil.getStringFromDate(runTimeAsPerDefiniteGap, DateFormats.CONVERSION_SP_DATE_FORMAT));
        jobRunDetailsTestData.setNewMaxStartTime(DateUtil.getStringFromDate(newMaxStartTime, DateFormats.CONVERSION_SP_DATE_FORMAT));

        this.jobRunContext.setMaxStartTime(newMaxStartTime);
        this.jobRunContext.setFormattedCurrentTime(formattedCurrentTime);
        log.info("Job Id : {} Max Start Time:{}", jobId, newMaxStartTime);
        return newMaxStartTime;
    }

    private Date getBufferedMaxStartTime(Date newMaxStartTime) {
        int buffer = 2;
        if (this.job.getConversionType().equals(ConversionType.buy_click_audited) ||
                this.job.getConversionType().equals(ConversionType.multiple_buy_click_audited) ||
                DateUtil.getMinute(newMaxStartTime) >= 30) {
            buffer = 1;
        }
        return DateUtil.subtractHours(newMaxStartTime, buffer);
    }

    private void processTimeSlots(Date newMinStartTime, Date newMaxStartTime, JobRunDetailsTestData jobRunDetailsTestData,
                                  int numberOfHours, String formattedCurrentTime) throws SPFailedException, JsonProcessingException, ParseException, InterruptedException {
        List<Date> dataTimeSlots = DateUtil.getDataTimeSlots(newMinStartTime, newMaxStartTime, numberOfHours);
        jobRunDetailsTestData.setSlotCount(dataTimeSlots.size());
        if (dataTimeSlots.isEmpty()) {
            log.info("Job Id : " + job.getId() + " Old : " + newMinStartTime + " New : " + newMaxStartTime + " . No time slots");
            jobRepository.handleZeroConversionsScenario(job, newMinStartTime, numberOfHours, NO_CONVERSIONS_AVAILABLE_MESSAGE,
                    JobRunDetailsStatus.success, jobRunDetailsTestData, job.getSchedulerFrequency());
            this.jobRunContext.setJobCompletionUpdateStatus(true);  // setting this is necc bcz if code breaks post this then this will be saved in redis
            return;
        }

        boolean allSuccessful = executeAllSlots(dataTimeSlots, numberOfHours, jobRunDetailsTestData);
        this.updateJobAsComplete(formattedCurrentTime, allSuccessful, false);
    }

    private void updateJobAsComplete(String formattedCurrentTime, boolean allSuccessful, boolean isPreExecuted)
            throws SPFailedException, JsonProcessingException {
        if (allSuccessful) {
            job.setSuccessfulRunTime(formattedCurrentTime);
        }
        job.setScheduledTime(TimeLogic.getNewScheduleTime(job.getScheduledTime(), job.getSchedulerFrequency()));

        // update the schedule time,successful run time,status in job
        if (!isPreExecuted) {
            job.setJobRunStatus(JobRunStatus.PENDING);
        }
        jobRepository.updateJobCompletion(job);
        this.jobRunContext.setJobCompletionUpdateStatus(true);

        log.info("Job Id : " + job.getId() + " updateJobAsComplete done");
    }

    private boolean executeAllSlots(List<Date> dataTimeSlots, int hoursInSlot, JobRunDetailsTestData jobRunDetailsTestData)
            throws JsonProcessingException, SPFailedException, InterruptedException {
        log.info("Job Id : " + job.getId() + " Started executeAllSlots");

        boolean allSlotsSuccessful = true; //TODO: remove if not used
        int currentDateSlotIndex = 0;
        if (this.jobRunContext.getCurrentSlotIndex() != null) {
            log.info("Job Id : " + job.getId() + " Setting Slot index from Redis");
            currentDateSlotIndex = this.jobRunContext.getCurrentSlotIndex();
        }
        for (; currentDateSlotIndex < dataTimeSlots.size(); currentDateSlotIndex++) {
            allSlotsSuccessful = this.executeSlot(dataTimeSlots, currentDateSlotIndex, hoursInSlot, allSlotsSuccessful, jobRunDetailsTestData);
        }

        log.info("Job Id : " + job.getId() + " Completed executeAllSlots with status:" + allSlotsSuccessful);

        this.jobRunContext.setUploadedAllSlotsStatus(allSlotsSuccessful);
        this.jobRunContext.setJobConversionUploadStatus(true);

        return allSlotsSuccessful;
    }

    private boolean executeSlot(List<Date> dataTimeSlots, int currentSlotIndex, int hoursInSlot, boolean allSlotsSuccessful,
                                JobRunDetailsTestData jobRunDetailsTestData)
            throws SPFailedException, JsonProcessingException, InterruptedException {
        if (ContextHolder.shutdownInitiated) {
            throw new InterruptedException("Exit Interruption");
        }
        log.info("Job Id : " + job.getId() + " Slot index :" + currentSlotIndex);
//      Upload and DB update of Current Slot was completed in the previous run
        if (this.jobRunContext.getCurrentSlotIndex() != null &&
                this.jobRunContext.getCurrentSlotIndex() == currentSlotIndex &&
                this.jobRunContext.getCurrentSlotCompletionUpdateStatus() != null &&
                this.jobRunContext.getCurrentSlotCompletionUpdateStatus()) {
            log.info("Job Id : " + job.getId() + " Slot index :" + currentSlotIndex + " skipped");
            return allSlotsSuccessful;
        }

        // Resetting Slot related variables
        this.jobRunContext.setCurrentSlotIndex(currentSlotIndex);
        this.jobRunContext.setCurrentSlotCompletionStatus(false);
        this.jobRunContext.setCurrentSlotCompletionUpdateStatus(false);

        Date dataStartDate = dataTimeSlots.get(currentSlotIndex);
        Date dataEndDate = DateUtil.addHours(dataStartDate, hoursInSlot);
        JobRunDetails jobRunDetails = JobRunDetails.builder()
                .jobId(job.getId())
                .hrId(DateUtil.getHour(dataStartDate))
                .dayId(DateUtil.getDayId(dataStartDate, DateFormats.DAY_ID_FORMAT))
                .dataStartTime(DateUtil.getStringFromDate(dataStartDate, dateFormat))
                .dataEndTime(DateUtil.getStringFromDate(dataEndDate, dateFormat))
                .test_data(JsonUtil.getJsonNodeFromObject(jobRunDetailsTestData))
                .build();
        this.globalJobContext.setJobRunDetails(jobRunDetails);

        // Get conversions from DB
        List<Conversion> conversionList = conversionRepository.getConversions(dataStartDate,
                DateUtil.subtractSec(dataEndDate, 1), job);

        log.info("Job Id : " + job.getId() + " Start Date : {} End Date:{} Total Conversions from DB:{} ", dataStartDate, dataEndDate, conversionList.size());
        ConversionResponse conversionResponse = conversionModifier.modifyConversionNumbersAndValue(conversionList, this.job, JobType.SCHEDULED);
        this.globalJobContext.setSlotConversionResponse(conversionResponse);

        int currentConversionIndex = 0;
        if (this.jobRunContext.getCurrentConversionIndex() != null) {
            currentConversionIndex = this.jobRunContext.getCurrentConversionIndex();
            this.globalJobContext.setPreviousRunSlotConversionProcessedCount(currentConversionIndex);
        }
        for (; currentConversionIndex < conversionList.size(); currentConversionIndex++) {
            this.executeOneConversion(conversionList, currentConversionIndex, conversionResponse);
        }
        this.jobRunContext.setCurrentSlotCompletionStatus(true);

        // update the data start and data end time in job and job run details for every time slot
        job.setDataStartTime(DateUtil.getStringFromDate(dataStartDate, dateFormat));
        job.setDataEndTime(DateUtil.getStringFromDate(dataEndDate, dateFormat));

        log.info("Job Id : " + job.getId() + " Slot index :" + currentSlotIndex + " Upload complete");
        return updateSlotCompletion(allSlotsSuccessful, jobRunDetails, conversionResponse);
    }

    private void executeOneConversion(List<Conversion> conversionList, int currentConversionIndex, ConversionResponse conversionResponse) {
        // this means the current conversion is previously uploaded
        if (this.jobRunContext.getCurrentConversionIndex() != null &&
                this.jobRunContext.getCurrentConversionIndex() == currentConversionIndex &&
                this.jobRunContext.getCurrentConversionUploadStatus() != null &&
                this.jobRunContext.getCurrentConversionUploadStatus()) {
            log.info("Job Id : " + job.getId() + " Conversion index :" + currentConversionIndex + " skipped");
            this.globalJobContext.setPreviousRunSlotConversionProcessedCount(currentConversionIndex + 1);
            return;
        }

        // Resetting One Conversion related variables for next CONVERSION
        this.jobRunContext.setCurrentConversionIndex(currentConversionIndex);
        this.jobRunContext.setCurrentConversionUploadStatus(false);

        ConversionApiResponse res = conversionUploadApi.send(conversionList.get(currentConversionIndex), job, JobType.SCHEDULED);
        conversionResponse.increment(res, 1);
        this.jobRunContext.setCurrentConversionUploadStatus(true);
    }

    // Note : ideally, allSlotsSuccessful should always be true
    private boolean updateSlotCompletion(boolean allSlotsSuccessful, JobRunDetails jobRunDetails, ConversionResponse conversionResponse)
            throws SPFailedException, JsonProcessingException {
        boolean updateSlotCompletionInDb = jobRepository.updateSlotCompletion(jobRunDetails, conversionResponse, job, JobRunStatus.RUNNING,
                this.globalJobContext.getPreviousRunSlotConversionProcessedCount());
        this.jobRunContext.setCurrentSlotCompletionUpdateStatus(updateSlotCompletionInDb);  // will be set to true else exception is thrown

        // Resetting One Conversion related variables for next SLOT
        this.jobRunContext.setCurrentConversionIndex(null);
        this.jobRunContext.setCurrentConversionUploadStatus(null);
        this.globalJobContext.setPreviousRunSlotConversionProcessedCount(null);

        return allSlotsSuccessful;
    }

}
