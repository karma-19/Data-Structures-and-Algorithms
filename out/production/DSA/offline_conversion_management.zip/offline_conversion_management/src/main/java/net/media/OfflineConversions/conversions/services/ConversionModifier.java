package net.media.OfflineConversions.conversions.services;

import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.Conversion;
import net.media.OfflineConversions.conversions.ConversionUploadApi;
import net.media.OfflineConversions.enums.JobType;
import net.media.OfflineConversions.enums.ConversionType;
import net.media.OfflineConversions.enums.ManagementGroup;
import net.media.OfflineConversions.jobs.models.ConversionResponse;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.utils.HashUtils;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;

@Service
@Slf4j
public class ConversionModifier {

    private void modify(Job job, List<Conversion> conversionList) {
        if (isJobGinsuTaboola(job) || isJobMultipleAuditedGoogle(job)) {
            HashMap<String, Integer> buyClickToCount = new HashMap<>();
            for (Conversion conversion : conversionList) {
                String clickId = conversion.getGclid();
                if (!buyClickToCount.containsKey(clickId)) {
                    buyClickToCount.put(clickId, 0);
                }
                buyClickToCount.put(clickId, buyClickToCount.get(clickId) + 1);
                String prefix = isJobMultipleAuditedGoogle(job) ? HashUtils.getKeywordHash(clickId + conversion.getConversionTime().toString()) : clickId;
                conversion.setOrder_id(prefix + '-' + buyClickToCount.get(clickId));
            }
        }
    }

    public static boolean isJobMultipleAuditedGoogle(Job job) {
        return job.getConversionType().equals(ConversionType.multiple_buy_click_audited) &&
                job.getSourceName().equals(ConversionUploadApi.GOOGLE_SOURCE_NAME);
    }

    public static boolean isJobGinsuTaboola(Job job) {
        return job.getSourceName().equals(ConversionUploadApi.TABOOLA_SOURCE_NAME) &&
                job.getManagementGroup().equalsIgnoreCase(String.valueOf(ManagementGroup.GINSU));
    }

    public ConversionResponse modifyConversionNumbersAndValue(List<Conversion> conversionList, Job job, JobType jobType) {
        this.modify(job, conversionList);

        int totalConversionFromDb, conversionCountToBeUploaded;
        conversionCountToBeUploaded = totalConversionFromDb = conversionList.size();

        // Skip empty click ids
        conversionList.removeIf(conversion -> conversion.getGclid() == null || conversion.getGclid().length() == 0);
        int emptyClickIdSkippedConversions = conversionCountToBeUploaded - conversionList.size();
        conversionCountToBeUploaded -= emptyClickIdSkippedConversions;

        // skip facebook tablet clicks
        conversionList.removeIf(conversion -> {
            if (job.getSkipTablet() != null && job.getSkipTablet()) {
                return (conversion.getDevice() != null
                        && conversion.getDevice().equals("t")) ||
                        (conversion.getTestDataDevice() != null
                                && conversion.getTestDataDevice().equals("tablet"));
            }
            return false;
        });
        int tabletSkippedConversions = conversionCountToBeUploaded - conversionList.size();
        conversionCountToBeUploaded -= tabletSkippedConversions;
        // Redundant
        log.info("Job Id : {} Job Type : {} DB : {} Tablet Skipped :{} Empty Click Id : {} Upload:{}",
                job.getId(), jobType, totalConversionFromDb, tabletSkippedConversions, emptyClickIdSkippedConversions, conversionCountToBeUploaded);

        return ConversionResponse.builder()
                .emptyClickIdSkipped(emptyClickIdSkippedConversions)
                .tabletSkipped(tabletSkippedConversions)
                .conversionsToBeUploaded(conversionCountToBeUploaded)
                .conversionsFromDb(totalConversionFromDb)
                .build();
    }
}
