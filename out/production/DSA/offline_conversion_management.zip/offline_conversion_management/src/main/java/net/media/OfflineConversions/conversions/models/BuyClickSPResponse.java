package net.media.OfflineConversions.conversions.models;

import lombok.Builder;
import lombok.Data;

import java.util.Date;

@Data
@Builder
public class BuyClickSPResponse {
    Date statsDate;
    String adwordAccountId;
    String adwordCampaignId;
    int sentImpressions;
    int sentClicks;
    Double revenue;
    Double rpc;
    Double rps;
    Double paidClicks;
    String siteRequestUrl;
    String logHash;
    String buySourceClickId;
    String testDataDevice;
    String userAgent;
    String ipAddress;
    String device;
    String param_1;
    String param_2;
    Date minLogTime;
    Date maxLogTime;
    String network;
}
