package net.media.OfflineConversions.api.controllers;

import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.consumer.RealtimeKafkaConsumer;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@Slf4j
@Validated
@RestController
@CrossOrigin(origins = "*")
public class KafkaConsumerController {
    private final RealtimeKafkaConsumer kafkaConsumer;

    public KafkaConsumerController(RealtimeKafkaConsumer kafkaConsumer) {
        this.kafkaConsumer = kafkaConsumer;
    }

    @PostMapping("/consumer/start")
    public void startConsumer() {
        if (!RealtimeKafkaConsumer.CONSUMER_RUNNING) {
            log.error("Starting Consumer by API");
            kafkaConsumer.startConsumer();
        }
    }

    @PostMapping("/consumer/stop")
    public void stopConsumer() {
        if (RealtimeKafkaConsumer.CONSUMER_RUNNING) {
            log.error("Stopping Consumer by API");
            kafkaConsumer.stopConsumer();
        }
    }

    @GetMapping("/consumer/status")
    public boolean getConsumerStatus() {
        return RealtimeKafkaConsumer.CONSUMER_RUNNING;
    }
}
