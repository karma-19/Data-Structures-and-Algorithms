package net.media.OfflineConversions.utils;

import lombok.extern.slf4j.Slf4j;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.LongStream;

@Slf4j
public class NumberUtil {
    public static final double BASE_BOUNDARY = 0.25;
    public static final double MIN_BUCKET = 0.10;
    public static final double MAX_BUCKET = 5.0;
    public static final List<Double> allowedRevenueList = Arrays.asList(0.5, 0.75, 1.0);

    public static int getInteger(double doubleNumber) {
        BigDecimal bigDecimal = new BigDecimal(String.valueOf(doubleNumber));
        return bigDecimal.intValue();
    }

    public static int getRandomInteger(int min, int max) {
        return (int) ((Math.random() * (max - min)) + min);
    }

    public static long getRandomLong(long min, long max) {
        return (long) ((Math.random() * (max - min)) + min);
    }

    public static List<Long> getNRandomLong(long min, long max, int count) {
        long difference = max - min;
        if (count <= difference) {
            return getNUniqueRandomLong(min, max, count);
        }

        log.warn("Since count>(max-min), clashes possible for : {} among total count : {}", count - difference, count);
        return getNClashingRandomLong(min, max, count);
    }

    private static List<Long> getNUniqueRandomLong(long min, long max, int count) {
        List<Long> uniqueRandomNumbers = new ArrayList<>();
        uniqueRandomNumbers.add(min); // always including min value

        List<Long> numberRange = LongStream.range(min + 1, max).boxed().collect(Collectors.toList());
        Collections.shuffle(numberRange); // getting the number range shuffled

        uniqueRandomNumbers.addAll(numberRange.subList(0, count - 1));
        return uniqueRandomNumbers;
    }

    private static List<Long> getNClashingRandomLong(long min, long max, int count) {
        List<Long> randomNumbers = new ArrayList<>();
        long value = min;

        while (value < max) {
            randomNumbers.add(value);       // adding unique values
            value += 1;
        }

        while (randomNumbers.size() < count) {
            randomNumbers.add(getRandomLong(min, max));     // adding clashing values
        }
        return randomNumbers;
    }

    public static double roundOff(double doubleNumber) {
        if (doubleNumber <= 0.17) {
            return MIN_BUCKET;
        }
        double newDoubleNumber = doubleNumber / BASE_BOUNDARY;
        int quotient = getInteger(newDoubleNumber);
        double remainder = doubleNumber - ((double) quotient * BASE_BOUNDARY);
        double adjustment;
        double midBoundary = (0 + BASE_BOUNDARY) / 2.0;
        if (remainder < midBoundary) {
            adjustment = 0;
        } else {
            adjustment = BASE_BOUNDARY;
        }
        return Math.min((((double) quotient * BASE_BOUNDARY) + adjustment), MAX_BUCKET);
    }

    public static double getRandomizedRevenue() {
        int randomIndex = getRandomInteger(0, allowedRevenueList.size());
        return allowedRevenueList.get(randomIndex);
    }


}
