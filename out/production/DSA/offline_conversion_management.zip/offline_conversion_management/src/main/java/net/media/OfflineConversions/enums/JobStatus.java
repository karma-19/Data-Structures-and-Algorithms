package net.media.OfflineConversions.enums;

public enum JobStatus {
    ACTIVE, SUSPENDED
}
