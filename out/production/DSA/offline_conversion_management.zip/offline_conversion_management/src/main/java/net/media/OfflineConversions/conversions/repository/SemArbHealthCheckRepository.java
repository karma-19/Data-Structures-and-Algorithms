package net.media.OfflineConversions.conversions.repository;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class SemArbHealthCheckRepository {
    private final JdbcTemplate semArbJdbcTemplate;
    private final String PING_MAKER = "SELECT 1 AS HealthCheck";

    public SemArbHealthCheckRepository(@Qualifier("semArbJdbcTemplate") JdbcTemplate dataSource) {
        this.semArbJdbcTemplate = dataSource;
    }

    public boolean pingSemArbDb() {
        return Objects.requireNonNull(semArbJdbcTemplate.queryForObject(PING_MAKER, Integer.class)) == 1;
    }
}
