package net.media.OfflineConversions.conversions.models;

import lombok.Builder;
import lombok.Data;

import java.util.Date;

@Data
@Builder
public class AdClickSPResponse {
    String logHash;
    String accountId;
    String buySourceClickId;
    Date statsDate;
    String param1;
    String param2;
    String userAgent;
    String ipAddress;
    String url;
    String device;
    String testDataDevice;

//    {
//        "log_hash": "7f076c4c76547a766a40abff887bf19e",
//            "adword_account_id": 5322504911108331,
//            "buy_source_click_id": "IwAR0nRXINtAiesOZejKAFFy1SCFMDmWkT5efOwmhsLPOn8Hm0FGYeXMnP-Ng",
//            "stats_date": "2021-08-29 20:00:00.000",
//            "param_1": null,
//            "param_2": null,
//            "user_agent": "Mozilla/5.0 (Linux; Android 11; SM-G973U Build/RP1A.200720.012; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/92.0.4515.159 Mobile Safari/537.36 [FB_IAB/FB4A;FBAV/330.0.0.31.120;]",
//            "ip_address": 1236135179,
//            "device": "m",
//            "test_data_device": "mobile phone",
//            "site_request_url": "https://www.wellnessfueled.com/topic/22/?utm_campaign=J83D28R&g_ci=23848187997340507&g_ai=23848187997400507&g_adi=23848187998200507&uc_id=6b%2BniCTRcw%3D%3D&ekw=hkN9yEJhHUzUqtau1lcYkKHFuZFPMEFJF8lCGxJGr54umYumux7LJUCGby2BUCz3&fbclid=IwAR0nRXINtAiesOZejKAFFy1SCFMDmWkT5efOwmhsLPOn8Hm0FGYeXMnP-Ng"
//    }
}
