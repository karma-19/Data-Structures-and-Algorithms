package net.media.OfflineConversions.conf;


import io.sentry.Sentry;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SentryConf {
    public SentryConf(@Value("${sentry.dsn}") String dsn,
                      @Value("${spring.profiles.active}") String env) {
//        Sentry.init(dsn);
        if(!env.equalsIgnoreCase("staging")){
            Sentry.init(sentryOptions -> {
                sentryOptions.setDsn(dsn);
                sentryOptions.setEnvironment(env);
            });
        }
    }
}
