package net.media.OfflineConversions.jobs.mappers;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.SneakyThrows;
import net.media.OfflineConversions.jobs.models.JobRunDetails;
import net.media.OfflineConversions.jobs.models.JobRunDetailsStatus;
import net.media.OfflineConversions.utils.JsonUtil;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;

public class JobRunDetailsRowMapper implements RowMapper<JobRunDetails> {
    @SneakyThrows
    @Override
    public JobRunDetails mapRow(ResultSet resultSet, int i) {
        return JobRunDetails.builder()
                .id(resultSet.getInt("id"))
                .jobId(resultSet.getInt("job_id"))
                .dataStartTime(resultSet.getString("data_start_time"))
                .dataEndTime(resultSet.getString("data_end_time"))
                .conversions(resultSet.getInt("conversions"))
                .dayId(resultSet.getString("day_id"))
                .hrId(resultSet.getInt("hr_id"))
                .message(resultSet.getString("message"))
                .status(JobRunDetailsStatus.valueOf(resultSet.getString("status")))
                .createdTime(resultSet.getString("created_time"))
                .modifiedTime(resultSet.getString("modified_time"))
                .conversion_details(_getFieldDetails(resultSet.getString("conversion_details")))
                .test_data(_getFieldDetails(resultSet.getString("test_data")))
                .build();
    }

    private JsonNode _getFieldDetails(String field_details) throws JsonProcessingException {
        if (field_details != null) {
            return JsonUtil.getJsonNodeFromString(field_details);
        }
        return null;
    }
}
