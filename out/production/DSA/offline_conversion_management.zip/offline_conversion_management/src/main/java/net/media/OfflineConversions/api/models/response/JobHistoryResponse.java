package net.media.OfflineConversions.api.models.response;

import lombok.Data;
import lombok.experimental.SuperBuilder;
import net.media.OfflineConversions.jobs.models.JobRunDetails;

import java.util.List;

@Data
@SuperBuilder
public class JobHistoryResponse extends BaseResponse {
    List<JobRunDetails> jobHistoryList;
}
