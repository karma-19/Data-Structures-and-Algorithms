package net.media.OfflineConversions.jobs.models;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class GetJobSPRequest {
    Integer jobId;
    String accountId;
    int conversionTypeId;
    String conversionName;
    String pixelId;
}
