package net.media.OfflineConversions.schedulers;

import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;
import net.media.OfflineConversions.conversions.consumer.RealtimeKafkaConsumer;
import net.media.OfflineConversions.dao.RedisDao;
import net.media.OfflineConversions.enums.JobType;
import net.media.OfflineConversions.exceptions.SPFailedException;
import net.media.OfflineConversions.jobs.models.ConversionResponse;
import net.media.OfflineConversions.jobs.models.Job;
import net.media.OfflineConversions.jobs.models.JobRunDetails;
import net.media.OfflineConversions.jobs.models.JobRunDetailsStatus;
import net.media.OfflineConversions.jobs.repository.JobRepository;
import net.media.OfflineConversions.utils.DateFormats;
import net.media.OfflineConversions.utils.DateUtil;
import net.media.OfflineConversions.utils.JsonUtil;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.text.ParseException;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class RealtimeJobRunService {
    private final RedisDao redisDao;
    private final JobRepository jobRepository;
    private final ScheduledJobListRefresher scheduledJobListRefresher;

    //stores popped conversion map's keys and its score(date)
    private String[] poppedJobIdStartTimePair = null;
    @Getter
    //stores popped conversion map from redis
    private Map<String, Integer> poppedSlotConversionMap;

    @Setter
    @Getter
    private int jobId;
    @Setter
    @Getter
    private Date dataStartTime;
    @Setter
    @Getter
    private String jobIdStartTime;

    public RealtimeJobRunService(RedisDao redisDao,
                                 JobRepository jobRepository,
                                 ScheduledJobListRefresher scheduledJobListRefresher) {
        this.redisDao = redisDao;
        this.jobRepository = jobRepository;
        this.scheduledJobListRefresher = scheduledJobListRefresher;
        this.poppedSlotConversionMap = new HashMap<>();
    }

    @Scheduled(fixedRate = 60 * 60 * 1000, initialDelay = 10 * 60 * 1000) //1 hour
    public void uploadJobRunDetailsInDb() {
        while (redisDao.getRealtimeSortedSetSize() > 0) {
            Date maxDataStartTimeInSortedSet = null;
            try {
                maxDataStartTimeInSortedSet = this.getMaxBufferedDataStartTime(); // max data start tie - 2 hrs
                if (maxDataStartTimeInSortedSet == null) {
                    return;
                }
            } catch (Exception e) {
                log.warn("Exception occurred while extracting max buffered data start time. Exception {}", e.getMessage());
            }

            try {
                while (true) {
                    if (this.poppedJobIdStartTimePair == null || this.isPoppedSlotReadyForDB(maxDataStartTimeInSortedSet)) {

                        if (this.poppedJobIdStartTimePair == null) {
                            this.resetDetailsOfPoppedPair();        // since popping fresh slot, make conversion map null first to make sure data is of same slot as popped
                            this.poppedJobIdStartTimePair = redisDao.getOldestJobFromRealtimeSortedSet();
                            if (this.poppedJobIdStartTimePair == null) {
                                break;
                            } else {
                                this.setJobId(getPoppedJobId());
                                this.setDataStartTime(DateUtil.getDateFromString(
                                        String.valueOf((long) Double.parseDouble(poppedJobIdStartTimePair[1])),
                                        DateFormats.HOURLY_FORMAT));
                                this.setJobIdStartTime(poppedJobIdStartTimePair[0]);
                            }
                        }

                        if (this.isPoppedSlotReadyForDB(maxDataStartTimeInSortedSet)) { // when for the first time no slot is popped, the isPoppedSlotReadyForDB() would have returned false. Hence calculating again
                            this.processAndSavePoppedSlot();
                        } else {
                            log.warn("Job Id : {} DataStartTime : {} No more slots available for realtime.", getJobId(), this.getDataStartTime());
                            return;
                        }

                    } else {
                        log.info("No more slots : redis -> DB");
                        return;
                    }
                }
            } catch (Exception e) {
                log.warn("Job Id : {} Popped Slot Score : {} Exception occurred {}", getJobId(), this.getJobIdStartTime(), e.getMessage());
                return;
            }
        }
    }

    public Integer getPoppedJobId() {
        String poppedSlotValue = poppedJobIdStartTimePair[0];
        if (poppedSlotValue != null) {
            List<String> splitSlotValues = Arrays.asList(poppedSlotValue.split("_"));
            if (!splitSlotValues.isEmpty()) {
                try {
                    return Integer.parseInt(splitSlotValues.get(0));
                } catch (NumberFormatException e) {
                    log.warn("Invalid Job Id in popped slot: {} {}", poppedSlotValue, e.getMessage());
                }
            }
        }
        return null;
    }

    public boolean isPoppedSlotReadyForDB(Date maxDataStartTimeInSortedSet) {
        try {
            Double startTimeOfPoppedPair = this.getStartTimeOfPoppedPair();
            if (startTimeOfPoppedPair != null) {
                double maxDataStartTime = Double.parseDouble(DateUtil.getStringFromDate(maxDataStartTimeInSortedSet, DateFormats.HOURLY_FORMAT));
                return startTimeOfPoppedPair <= maxDataStartTime;
            }
        } catch (Exception e) {
            log.warn("Job Id : {} Exception occurred while verifying popped slot. {}", jobId, e.getMessage());
        }
        return false;
    }

    public Double getStartTimeOfPoppedPair() {
        return Double.parseDouble(DateUtil.getStringFromDate(getDataStartTime(), DateFormats.HOURLY_FORMAT));
    }

    public void processAndSavePoppedSlot() throws Exception {
        log.info("Job Id : {} processAndSavePoppedSlot ", this.getJobId());
        String dataStartTime = DateUtil.getStringFromDate(getDataStartTime(), DateFormats.HOURLY_FORMAT);
        String dataEndTime = DateUtil.getStringFromDate(DateUtil.addHours(getDataStartTime(), 1), DateFormats.HOURLY_FORMAT);

        this.popSlotConversionMap();

        if (this.poppedSlotConversionMap == null || this.poppedSlotConversionMap.size() == 0) {
            log.warn("Job Id : {} DataStartTime : {} No Conversion Map found in Redis", this.getJobId(), this.getDataStartTime());
            resetDetailsOfPoppedPair();
            return;
        }

        ConversionResponse totalConversionResponse = this.getTotalConversionResponse();
        JobRunDetails jobRunDetails = this.buildJobRunDetails(dataStartTime, dataEndTime, totalConversionResponse);
        this.saveInDB(jobRunDetails);

        this.resetDetailsOfPoppedPair();
    }

    private void saveInDB(JobRunDetails jobRunDetails) throws SPFailedException, JsonProcessingException {
        Job job = scheduledJobListRefresher.getAllJobsMap().get(jobRunDetails.getJobId());

        if (job != null && (job.getJobType() == JobType.REALTIME || ScheduledJobListRefresher.JOBS_SCHEDULED_TO_REALTIME.values()         //Extra realtime check is for special scheduled jobs TODO : Moynak : remove when temp code is removed
                .stream()
                .flatMap(Set::stream)
                .collect(Collectors.toSet())
                .contains(job.getId()))) {
            jobRepository.upsertJobRunDetailsAndJob(jobRunDetails);
        }
    }

    private void resetDetailsOfPoppedPair() {
        this.poppedSlotConversionMap = null;
        this.poppedJobIdStartTimePair = null;
    }

    private void popSlotConversionMap() {
        if (this.poppedSlotConversionMap == null) {
            log.info("Job Id : {} popSlotConversionMap ", this.getJobId());

            String poppedJobIdStartTime = this.getJobIdStartTime();
            try {
                this.poppedSlotConversionMap = redisDao.getConversionResponseFromRealtimeHashMap(poppedJobIdStartTime);
                redisDao.deleteJobFromRealtimeHashMap(poppedJobIdStartTime);
            } catch (Exception e) {
                log.warn("JobIdDataStartTime : {} Exception occurred while popping map from redis.", poppedJobIdStartTime);
                throw e;
            }
        }
    }

    private JobRunDetails buildJobRunDetails(String dataStartTime, String dataEndTime, ConversionResponse conversionResponse) throws Exception {
        try {
            JobRunDetails jobRunDetails = JobRunDetails.builder()
                    .jobId(jobId)
                    .dataStartTime(dataStartTime)
                    .dataEndTime(dataEndTime)
                    .dayId(DateUtil.getDayId(DateUtil.getDateFromString(dataStartTime, DateFormats.HOURLY_FORMAT), DateFormats.DAY_ID_FORMAT))
                    .hrId(DateUtil.getHour(DateUtil.getDateFromString(dataStartTime, DateFormats.HOURLY_FORMAT)))
                    .conversions(conversionResponse.getTotalConversions())
                    .uploadedConversions(conversionResponse.getUploadCount())
                    .conversion_details(JsonUtil.getJsonNodeFromObject(conversionResponse))
                    .status(JobRunDetailsStatus.success)
                    .build();

            if (!RealtimeKafkaConsumer.CONSUMER_RUNNING) {
                jobRunDetails.setMessage("partial update");
            } else {
                jobRunDetails.setMessage("success");
            }

            return jobRunDetails;
        } catch (Exception e) {
            log.warn("Exception occurred while creating jobRunDetails for conversionResponse {}", this.poppedSlotConversionMap);
            throw e;
        }
    }

    private ConversionResponse getTotalConversionResponse() throws JsonProcessingException, SPFailedException {
        try {
            ConversionResponse currentConversionResponse = (ConversionResponse) JsonUtil.getObjectFromJsonNode(
                    JsonUtil.getJsonNodeFromString(JsonUtil.getValueAsString(this.poppedSlotConversionMap)),
                    ConversionResponse.class);

            JobRunDetails jobRunDetailsFromSp = null;
            List<JobRunDetails> jobRunDetailsListFromSp = jobRepository.getJobRunDetails(jobId, DateUtil.getStringFromDate(dataStartTime, DateFormats.HOURLY_FORMAT));
            if (jobRunDetailsListFromSp.size() > 0) {
                jobRunDetailsFromSp = jobRunDetailsListFromSp.get(0);
            }

            ConversionResponse previousConversionResponse = null;
            if (jobRunDetailsFromSp != null) {
                previousConversionResponse = (ConversionResponse) JsonUtil.getObjectFromJsonNode(
                        JsonUtil.getJsonNodeFromString(jobRunDetailsFromSp.getConversion_details().toString()),
                        ConversionResponse.class);
            }

            if (previousConversionResponse != null) {
                currentConversionResponse.merge(previousConversionResponse);
            }

            return currentConversionResponse;
        } catch (Exception e) {
            log.warn("Job Id : {} Exception occurred while getting total conversions.", jobId);
            throw e;
        }
    }

    public Date getMaxBufferedDataStartTime() throws ParseException {
        String maxDataStartTime = redisDao.getMaxStartTimeFromRealtimeSortedSet();
        if (maxDataStartTime != null) {
            return DateUtil.subtractHours(DateUtil.getDateFromString(maxDataStartTime, DateFormats.HOURLY_FORMAT), 2);
        }
        log.warn("Realtime Job Run Service : maxBufferedDataStartTime is null.");
        return null;
    }

}
