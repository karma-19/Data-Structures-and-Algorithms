package net.media.OfflineConversions.api.services;

import net.media.OfflineConversions.api.models.requests.CreateJobRequest;
import net.media.OfflineConversions.api.models.response.ConfigResponse;
import net.media.OfflineConversions.enums.JobStatus;
import net.media.OfflineConversions.enums.JobType;
import net.media.OfflineConversions.enums.SchedulerFreq;
import net.media.OfflineConversions.exceptions.SPFailedException;
import net.media.OfflineConversions.jobs.models.ConversionTypeDetails;
import net.media.OfflineConversions.jobs.repository.JobRepository;
import net.media.OfflineConversions.jobs.repository.SemMasterRepository;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

@Service
public class ConfigService {

    JobRepository jobRepository;
    SemMasterRepository semMasterRepository;

    public ConfigService(JobRepository jobRepository, SemMasterRepository semMasterRepository) {
        this.jobRepository = jobRepository;
        this.semMasterRepository = semMasterRepository;
    }

    public ConfigResponse read() throws SPFailedException {
        return ConfigResponse.builder()
                .message("success")
                .conversionTypes(jobRepository.getConversionTypeDetails())
                .jobTypes(Arrays.asList(JobType.values()))
                .jobStatuses(Arrays.asList(JobStatus.values()))
                .managementGroupNameIds(semMasterRepository.getManagementGroupIds())
                .build();
    }

    public boolean isConfigValid(List<Integer> conversionTypeIds) throws SPFailedException {
        List<ConversionTypeDetails> conversionTypeDetailsList =
                jobRepository.getConversionTypeDetails();
        for (Integer conversionTypeId : conversionTypeIds) {
            boolean isValid = false;
            for (ConversionTypeDetails conversionTypeDetails : conversionTypeDetailsList) {
                if (conversionTypeDetails.getId() == conversionTypeId) {
                    isValid = true;
                    break;
                }
            }
            if (!isValid)
                return false;
        }
        return true;
    }

    public void addSchedulerFreq(List<CreateJobRequest> requestList) throws SPFailedException {
        List<ConversionTypeDetails> conversionTypeDetailsList = jobRepository.getConversionTypeDetails();
        for (CreateJobRequest createJobRequest : requestList) {
            createJobRequest.setSchedulerFrequency(_getFreq(createJobRequest.getConversionTypeId(), conversionTypeDetailsList));
        }
    }

    private SchedulerFreq _getFreq(Integer conversionTypeId, List<ConversionTypeDetails> conversionTypeDetailsList) {
        for (ConversionTypeDetails conversionTypeDetails : conversionTypeDetailsList) {
            if (conversionTypeId == conversionTypeDetails.getId()) {
                switch (conversionTypeDetails.getName()) {
                    case ad_click:
                    case keyword_click:
                    case ginsu_yahoo_beacon:
                    case buy_click_audited:
                    case ginsu_beacon_impression:
                    case multiple_buy_click_audited:
                        return SchedulerFreq.HOURLY;
                }
            }
        }
        return null;
    }

}
