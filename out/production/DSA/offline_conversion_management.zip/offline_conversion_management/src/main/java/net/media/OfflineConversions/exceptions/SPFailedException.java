package net.media.OfflineConversions.exceptions;

public class SPFailedException extends Exception {
    public SPFailedException(String msg) {
        super(msg);
    }
}
