package net.media.OfflineConversions.enums;

public enum JobRunType {
    SCHEDULED, STUCK, PRIORITY
}
