package net.media.OfflineConversions.api.services;

import net.media.OfflineConversions.conversions.repository.SemArbHealthCheckRepository;
import net.media.OfflineConversions.jobs.repository.JobRepository;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Service;

import java.util.Objects;

@Service
public class HealthCheckService {
    private final JobRepository jobRepository;
    private final RedisTemplate redisTemplate;
    private final SemArbHealthCheckRepository semArbHealthCheckRepository;
    private final String EXPECTED_REDIS_RESPONSE = "PONG";

    public HealthCheckService(JobRepository jobRepository, RedisTemplate redisTemplate, SemArbHealthCheckRepository semArbHealthCheckRepository) {
        this.jobRepository = jobRepository;
        this.redisTemplate = redisTemplate;
        this.semArbHealthCheckRepository = semArbHealthCheckRepository;
    }

    public boolean pingJobsDb() {
        return jobRepository.pingdb();
    }

    public boolean pingRedis() {
        return Objects.requireNonNull(Objects.requireNonNull(redisTemplate.getConnectionFactory()).getConnection().ping()).equalsIgnoreCase(EXPECTED_REDIS_RESPONSE);
    }

    public boolean pingSemArbDb() {
        return semArbHealthCheckRepository.pingSemArbDb();
    }
}
