package net.media.OfflineConversions.enums;

public enum JobType {
    SCHEDULED, REALTIME
}
