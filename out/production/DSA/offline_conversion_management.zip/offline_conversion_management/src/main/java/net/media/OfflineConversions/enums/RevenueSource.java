package net.media.OfflineConversions.enums;

import lombok.Getter;

@Getter
public enum RevenueSource {
    GINSU(2, "GINSU Buy Click Id Rev Stats"),
    RS4C(6, "GOOGLE CSA Buy Click Id Rev Stats"),
    AD_CLICK(8, "AD CLICK Buy Click Id Rev Stats");

    private final Integer revenueSourceId;
    private final String statsColumnName;

    RevenueSource(Integer revenueSourceId, String statsColumnName) {
        this.revenueSourceId = revenueSourceId;
        this.statsColumnName = statsColumnName;
    }
}
