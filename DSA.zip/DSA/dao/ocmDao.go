package dao

import (
	"data-sanity-alerting/config"
	"data-sanity-alerting/utils"
	"database/sql"
	"fmt"
	"strconv"

	log "github.com/sirupsen/logrus"

	_ "github.com/go-sql-driver/mysql"
)

const (
	ocmConversionSpName = `CALL ocm_get_conversion_count(%s,%s,%s,%s,%d)`
	ocmJobSpName        = `call ocm_get_jobs_interface_follower(null,null,null,null,null,null,1,0,null,null,null)`
)

func MySQLDsn() string {
	return fmt.Sprintf("%s:%s@tcp(%s)/%s", config.ConfigStruct.ConnectionConfigs.SqlConnection["ocm-stage"].Username, config.ConfigStruct.ConnectionConfigs.SqlConnection["ocm-stage"].Password, config.ConfigStruct.ConnectionConfigs.SqlConnection["ocm-stage"].Url, config.ConfigStruct.ConnectionConfigs.SqlConnection["ocm-stage"].Database)
}

type UploadedConversion struct {
	Day_id               string
	Hr_id                int64
	Account_id           int64
	Uploaded_conversions sql.NullInt64
}

type Job struct {
	Id           int64
	Account_id   string
	Account_name string
	Source_id    string
}

var ocmDbCon *sql.DB

func init() {
	var err error
	ocmDbCon, err = sql.Open(config.ConfigStruct.ConnectionConfigs.SqlConnection["ocm-stage"].DriverClassName, MySQLDsn())
	if err != nil {
		log.Printf("Error %s when opening DB\n", err)
		return
	}
}

func createOCMSp(startDate string, endDate string, isGroupByHour bool, accountId string, sourceId string) string {
	return fmt.Sprintf(ocmConversionSpName, startDate, endDate, accountId, sourceId, utils.B2i[isGroupByHour])
}

func GetUploadedConversions(startDate string, endDate string, isGroupByHour bool, accountId string, sourceId string) []UploadedConversion {
	var sp string = createOCMSp(startDate, endDate, isGroupByHour, accountId, sourceId)
	rows, err := ocmDbCon.Query(sp)
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()
	conversions := []UploadedConversion{}
	// var columns []string
	// columns, _ = rows.Columns()
	// log.Println(columns)
	for rows.Next() {
		conversion := UploadedConversion{}
		var err error
		if isGroupByHour {
			err = rows.Scan(&conversion.Day_id, &conversion.Hr_id, &conversion.Account_id, &conversion.Uploaded_conversions)
		} else {
			err = rows.Scan(&conversion.Day_id, &conversion.Account_id, &conversion.Uploaded_conversions)
		}
		utils.PanicOnErr(err)
		conversions = append(conversions, conversion)
	}
	return conversions
}

func GetActiveJobs() []Job {
	rows, err := ocmDbCon.Query(ocmJobSpName)
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()
	columns, _ := rows.Columns()
	count := len(columns)
	values := make([]interface{}, count)
	valuePtr := make([]interface{}, count)

	activeJobs := []Job{}
	for rows.Next() {
		for i, _ := range columns {
			valuePtr[i] = &values[i]
		}
		rows.Scan(valuePtr...)
		columnToValue := map[string]string{}
		for i, col := range columns {
			var v interface{}
			val := values[i]
			b, ok := val.([]byte)
			if ok {
				v = string(b)
				columnToValue[col] = v.(string)
			}
		}
		if columnToValue["status"] == "active" {
			id, _ := strconv.ParseInt(columnToValue["id"], 10, 64)
			job := Job{Id: id, Account_id: columnToValue["account_id"], Account_name: columnToValue["account_name"], Source_id: columnToValue["source_id"]}
			activeJobs = append(activeJobs, job)
		}
	}
	return activeJobs
}
