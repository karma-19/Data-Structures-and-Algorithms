package dao

import (
	"data-sanity-alerting/config"
	"data-sanity-alerting/utils"
	"database/sql"
	"fmt"
	"time"

	log "github.com/sirupsen/logrus"

	_ "github.com/denisenkom/go-mssqldb"
)

const (
	semArbConversionSpName = `EXEC Get_Hourly_Account_Conversions
	@from_date_hour = '%s',
	@to_date_hour = '%s',
	@is_group_by_hour = %d, --optional
	@adword_account_id = %s, --optional
	@source_id = %s --optional`
)

func MsSQLDsn() string {
	return fmt.Sprintf("server=%s;database=%s;user id=%s;password=%s;", config.ConfigStruct.ConnectionConfigs.SqlConnection["sem-arb"].Url, config.ConfigStruct.ConnectionConfigs.SqlConnection["sem-arb"].Database, config.ConfigStruct.ConnectionConfigs.SqlConnection["sem-arb"].Username, config.ConfigStruct.ConnectionConfigs.SqlConnection["sem-arb"].Password)
}

type InterfaceConversion struct {
	Stats_date  time.Time
	Hour        sql.NullInt64
	Account_id  int64
	Conversions int64
}

var semArbDbCon *sql.DB

func createSp(startDate string, endDate string, isGroupByHour bool, accountId string, sourceId string) string {
	return fmt.Sprintf(semArbConversionSpName, startDate, endDate, utils.B2i[isGroupByHour], accountId, sourceId)
}

func GetInterfaceConversions(startDate string, endDate string, isGroupByHour bool, accountId string, sourceId string) []InterfaceConversion {
	var sp string = createSp(startDate, endDate, isGroupByHour, accountId, sourceId)
	rows, err := semArbDbCon.Query(sp)
	if err != nil {
		log.Fatal(err)
	}
	defer rows.Close()
	conversions := []InterfaceConversion{}
	// var columns []string
	// columns, _ = rows.Columns()
	// log.Println(columns)
	for rows.Next() {
		conversion := InterfaceConversion{}
		err := rows.Scan(&conversion.Stats_date, &conversion.Account_id, &conversion.Conversions, &conversion.Hour)
		utils.PanicOnErr(err)
		conversions = append(conversions, conversion)
	}
	return conversions
}

func init() {
	var err error
	semArbDbCon, err = sql.Open(config.ConfigStruct.ConnectionConfigs.SqlConnection["sem-arb"].DriverClassName, MsSQLDsn())
	if err != nil {
		log.Printf("Error %s when opening DB\n", err)
		return
	}
}
