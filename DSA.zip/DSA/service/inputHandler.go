package service

import (
	"data-sanity-alerting/config"
	"data-sanity-alerting/utils"
	"errors"
	"fmt"
	"reflect"
	"regexp"
	"time"

	log "github.com/sirupsen/logrus"
)

func IsPipelineActive(pipelineName string) bool {
	return config.ConfigStruct.PipelineConfigs[pipelineName].IsActive
}

func ValidateInput(pipelineName string, inputParams interface{}) bool {
	var pipelineConfig config.PipelineConfig = config.ConfigStruct.PipelineConfigs[pipelineName]
	switch data := inputParams.(type) {
	case map[string]interface{}:
		if pipelineConfig.PipilineInputConfig.IsArray {
			log.Error("Required Array input")
			return false
		}
		return validateParams(pipelineConfig.PipilineInputConfig, data)
	case []interface{}:
		if !pipelineConfig.PipilineInputConfig.IsArray {
			log.Error("Required Json input")
			return false
		} else if len(data) == 0 {
			log.Error("Empty input array")
			return false
		}
		isValid := true
		for _, singleData := range data {
			mapData, isMap := singleData.(map[string]interface{})
			if isMap {
				isValid = isValid && validateParams(pipelineConfig.PipilineInputConfig, mapData)
			} else {
				isValid = false
			}
		}
		return isValid
	default:
		log.Error("Invalid data format")
		return false
	}
}

func FormatInput(inputConfig config.PipelineInputConfig, inputParams map[string]interface{}) (map[string]interface{}, error) {
	var formatErr error = nil
	for _, argConfig := range inputConfig.ArgumentConfigs {
		if argConfig.Source == "api" {
			value, _ := inputParams[argConfig.Name]
			if utils.GetTypeName(value) != utils.TimeTypeEnum && argConfig.Type == utils.TimeTypeEnum {
				parsedTime, err := time.Parse(argConfig.Format, utils.ConvertType(utils.StringTypeEnum, value).(string))
				if err != nil {
					log.Error(fmt.Sprintf("%s field not converted to type %s, value = %v", argConfig.Name, argConfig.Type, value))
					formatErr = errors.New("Incompatible input type")
				} else {
					inputParams[argConfig.Name] = parsedTime
				}
				continue
			}

			convertedValue := utils.ConvertType(argConfig.Type, value)
			if convertedValue == nil {
				log.Error(fmt.Sprintf("%s field not converted to type %s, value = %v", argConfig.Name, argConfig.Type, value))
				formatErr = errors.New("Incompatible input type")
			} else {
				inputParams[argConfig.Name] = convertedValue
			}
		} else if argConfig.Source != "api_post" {
			methodCallerInstace := utils.MethodCallerStruct{}
			instanceValue := reflect.ValueOf(methodCallerInstace) // Get the reflect.Value of the struct
			// Get the reflect.Value of the method by its name
			methodValue := instanceValue.MethodByName(argConfig.Source)

			// Check if the method exists
			if !methodValue.IsValid() {
				log.Error(fmt.Sprintf("Method %s does not exist", argConfig.Source))
				formatErr = errors.New("unknown input method")
			}

			// Call the method
			result := methodValue.Call(nil)

			// Handle the result
			if len(result) > 0 {
				returnValue := result[0].Interface()
				inputParams[argConfig.Name] = returnValue
			} else {
				formatErr = errors.New("input method gave no results")
			}
		}
	}
	for _, argConfig := range inputConfig.ArgumentConfigs {
		if argConfig.Source == "api_post" && argConfig.Param != "" {
			if val, isPresent := inputParams[argConfig.Param]; isPresent {
				var convertedVal interface{}
				switch data := val.(type) {
				case time.Time:
					convertedVal = data.Format(argConfig.Format)
				case string:
					re := regexp.MustCompile(argConfig.Format)
					match := re.FindStringSubmatch(data)
					if len(match) < 2 {
						continue
					}
					convertedVal = match[1]
				default:
					continue
				}
				inputParams[argConfig.Name] = convertedVal
			}
		}
	}
	if len(inputParams) != inputConfig.ArgumentCount {
		formatErr = errors.New("input param count does not match")
	}
	if inputConfig.InputGroupingConfig.IsEnabled {
		//TODO:
	}
	return inputParams, formatErr
}

func validateParams(inputConfig config.PipelineInputConfig, inputParams map[string]interface{}) bool {
	for _, argConfig := range inputConfig.ArgumentConfigs {
		if argConfig.Source == "api" {
			_, contains := inputParams[argConfig.Name]
			if !contains {
				log.Error(fmt.Sprintf("%s field missing in input", argConfig.Name))
				return false
			}
		}
	}
	return true
}
