package service

import (
	"context"
	"data-sanity-alerting/config"
	"data-sanity-alerting/utils"
	"fmt"
	"log"

	"cloud.google.com/go/bigquery"
	"google.golang.org/api/iterator"
)

func getDataFromBQ(query string, bqClient *bigquery.Client, ctx context.Context) ([]map[string]interface{}, error) {
	queryJob := bqClient.Query(query)
	q, err := queryJob.Read(ctx)
	if err != nil {
		log.Fatal("Error reading query results:", err)
	}

	// Iterate through query results
	var result []map[string]interface{}
	for {
		var res map[string]interface{}
		var row map[string]bigquery.Value
		res = make(map[string]interface{}, 0)
		row = make(map[string]bigquery.Value, 0)
		err := q.Next(&row)
		if err == iterator.Done {
			break
		}
		if err != nil {
			fmt.Println("Error reading next row:", err)
			return nil, err
		}
		for key, value := range row {
			res[key] = value
		}
		result = append(result, res)
	}
	return result, nil
}

func GetBQSourceResponse(dataSourceConfig config.PipelineDatasourceConfig, inputConfig config.PipelineInputConfig, inputParams map[string]interface{}, sourceIdentifier string) ([]map[string]interface{}, error) {
	sourceName := dataSourceConfig.Name
	bqClient, ctx, err := utils.GetBQConnection(sourceName)
	// defer bqClient.Close()
	if err != nil {
		log.Fatal(err)
	}
	sourceNameMap := map[string]string{
		sourceIdentifier: dataSourceConfig.PrintName,
	}
	spString := utils.GetModifiedSpString(dataSourceConfig, inputConfig, inputParams)
	result, err := getDataFromBQ(spString, bqClient, ctx)
	result = FilterArray(result, dataSourceConfig.FilterConfig, sourceNameMap)
	return result, err
}
