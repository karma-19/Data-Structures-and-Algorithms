package service

import (
	"bytes"
	"fmt"
	"io/ioutil"
	"net/http"
	"net/url"

	log "github.com/sirupsen/logrus"
)

func getApiCall(rawQueryURL string, params url.Values) []byte {
	queryURL, err := url.Parse(rawQueryURL)
	if err != nil {
		log.Warn(fmt.Sprintf("query url is not proper: %s", err))
		return []byte("")
	}
	if params != nil {
		queryURL.RawQuery = params.Encode()
	}
	resp, err := http.Get(queryURL.RequestURI())
	if err != nil {
		log.Warn(fmt.Sprintf("Get Request Failed: %s", err))
		return []byte("")
	}
	defer resp.Body.Close()
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Warn(fmt.Sprintf("Reading body failed: %s", err))
		return []byte("")
	}
	return body
}

func postApiCall(rawQueryURL string, requestBody []byte) []byte {
	resp, err := http.Post(rawQueryURL, "application/json", bytes.NewBuffer(requestBody))
	if err != nil {
		log.Warn(fmt.Sprintf("Post Request failed: %s", err))
		return []byte("")
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		log.Warn(fmt.Sprintf("Non 200 response: %v requestUrl: %s", resp, rawQueryURL))
		return []byte("")
	}
	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Warn(fmt.Sprintf("Reading body failed: %s", err))
		return []byte("")
	}
	return body
}

func postApiCallWithHeaders(rawQueryURL string, requestBody []byte, headers map[string]string) []byte {
	// Create a new HTTP client
	client := http.Client{}

	// Create a new request
	req, err := http.NewRequest("POST", rawQueryURL, bytes.NewBuffer(requestBody))
	if err != nil {
		log.Warn(fmt.Sprintf("Error creating request: %s to %s\n", err, rawQueryURL))
		return []byte{}
	}

	// Set the request headers
	for key, value := range headers {
		req.Header.Set(key, value)
	}

	// Send the request
	resp, err := client.Do(req)
	if err != nil {
		log.Warn(fmt.Sprintf("Error sending request: %s to %s\n", err, rawQueryURL))
		return []byte{}
	}
	defer resp.Body.Close()

	// Read the response body
	responseBody, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Warn(fmt.Sprintf("Error reading response body: %s to %s\n", err, rawQueryURL))
		return []byte{}
	}

	// Check the response status code
	// if resp.StatusCode >= 400 {
	// 	log.Warn(fmt.Sprintf("Error response: %s to %s\n", resp.Status, rawQueryURL))
	// 	return []byte{}
	// }

	return responseBody
}
