package service

import (
	"data-sanity-alerting/config"
	"encoding/json"
	"fmt"

	log "github.com/sirupsen/logrus"
)

func SendFlockMessage(messageList []map[string]interface{}, notifierName string) {
	//TODO: add order of params
	if len(messageList) == 0 {
		log.Info("Empty message for flock")
		return
	}
	
	jsonString, err := json.Marshal(messageList)
	if err != nil {
		log.Error(fmt.Sprintf("Flock message Error: %s", err))
		return
	}
	flockMessage := FlockMessage{Text: string(jsonString)}
	body, _ := json.Marshal(flockMessage)
	postApiCall(config.ConfigStruct.NotifierConfigs[notifierName].TriggerUrl, body)
}
