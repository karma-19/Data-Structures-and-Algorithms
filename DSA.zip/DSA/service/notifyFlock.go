package service

import (
	"data-sanity-alerting/config"
	"encoding/json"
)

type FlockMessage struct {
	Text string `json:"text"`
}

func SendFlockMessages(message string) {
	flockMessage := FlockMessage{Text: message}
	body, _ := json.Marshal(flockMessage)
	postApiCall(config.ConfigStruct.NotifierConfigs["greg-notifier"].TriggerUrl, body)
}
