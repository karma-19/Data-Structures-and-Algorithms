package service

import (
	"data-sanity-alerting/config"
	"data-sanity-alerting/utils"

	log "github.com/sirupsen/logrus"
)

func PushAlerts(alertMessage []map[string]interface{}, alertDestinationConf map[string]config.AlertDestinationCriteriaConfig, jobIdentifier JobIdentifier) {
	for _, alertDest := range alertDestinationConf {
		filteredMessages := make([]map[string]interface{}, 0)
		for _, msg := range alertMessage {
			if matchCriteria(msg, alertDest.Criteria) {
				filteredMessages = append(filteredMessages, msg)
			}
		}
		if alertDest.Consolidated {
			for _, notifier := range alertDest.Notifiers {
				var notifierConf config.NotifierConfig = config.ConfigStruct.NotifierConfigs[notifier]
				switch notifierConf.Type {
				case "flock":
					SendFlockMessage(filteredMessages, notifier)
				case "email":
					SendEmailWithAttachment(filteredMessages, notifier, jobIdentifier, alertDest.Message)
				case "email-message":
					SendEmailMessage(filteredMessages, notifier, jobIdentifier, alertDest.Message)
				}
			}
		} else {
			for _, msg := range filteredMessages {
				for _, notifier := range alertDest.Notifiers {
					var notifierConf config.NotifierConfig = config.ConfigStruct.NotifierConfigs[notifier]
					slice := make([]map[string]interface{}, 0)
					slice = append(slice, msg)
					switch notifierConf.Type {
					case "flock":
						SendFlockMessage(slice, notifier)
					case "email":
						SendEmailWithAttachment(filteredMessages, notifier, jobIdentifier, alertDest.Message)
					case "email-message":
						SendEmailMessage(filteredMessages, notifier, jobIdentifier, alertDest.Message)
					}
				}
			}
		}
	}
}

func matchCriteria(alertMessage map[string]interface{}, criteria map[string]interface{}) bool {
	expressionValue := true
	for paramName, val := range criteria {
		if _, contains := alertMessage[paramName]; contains {
			isEqual, err := utils.Compare(alertMessage[paramName], val, "eq")
			if err != nil {
				log.Error(err)
				return false
			}
			expressionValue = expressionValue && isEqual
		} else {
			return false
		}
	}
	return expressionValue
}
