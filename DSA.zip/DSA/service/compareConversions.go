package service

import (
	"data-sanity-alerting/dao"
	"data-sanity-alerting/utils"
	"encoding/json"
	"time"

	log "github.com/sirupsen/logrus"
)

const (
	diffPercentage = 0
	delay          = 24
	rangeDuration  = 1
)

type ConversionKey struct {
	DayId     string `json:"day"`
	HourId    int64  `json:"hour,omitempty"`
	AccountId int64  `json:"account_id"`
}

type countPair struct {
	sent      int64
	reflected int64
}

type flockMessage struct {
	UploadedCount  int64         `json:"uploadedCount"`
	ReflectedCount int64         `json:"reflectedCount"`
	CountDiff      float64       `json:"countDiff"`
	AccountName    string        `json:"accountName"`
	JobId          int64         `json:"jobId"`
	Identifer      ConversionKey `json:"identifer"`
}

func CompareConversions(accountId string, sourceId string, accountName string, jobId int64) bool {
	currentTime := time.Now()
	startDate := utils.TruncateMinutes(currentTime.Add(-time.Hour * delay))
	endDate := utils.TruncateMinutes(startDate.Add(time.Hour * rangeDuration))
	conversions := dao.GetInterfaceConversions(startDate.Format("20060102 15:04:05"), endDate.Format("20060102 15:04:05"), true, accountId, sourceId)
	var allMatching = true
	var conversionMap = make(map[ConversionKey]countPair)
	for _, conv := range conversions {
		var convKey = ConversionKey{DayId: conv.Stats_date.Format("2006-01-02"), HourId: conv.Hour.Int64, AccountId: conv.Account_id}
		conversionMap[convKey] = countPair{reflected: conv.Conversions}
	}
	ocmConversions := dao.GetUploadedConversions(startDate.Format("2006010215"), endDate.Format("2006010215"), true, accountId, sourceId)
	for _, conv := range ocmConversions {
		var convKey = ConversionKey{DayId: conv.Day_id, HourId: conv.Hr_id, AccountId: conv.Account_id}
		if val, found := conversionMap[convKey]; found {
			val.sent = conv.Uploaded_conversions.Int64
			conversionMap[convKey] = val
		} else {
			conversionMap[convKey] = countPair{sent: conv.Uploaded_conversions.Int64}
		}
	}
	for key, value := range conversionMap {
		uploadedCount := value.sent
		reflectedCount := value.reflected
		if !areCountsInOrder(uploadedCount, reflectedCount) {
			flockMsg := flockMessage{UploadedCount: uploadedCount, ReflectedCount: reflectedCount, CountDiff: utils.GetDiffPercentage(uploadedCount, reflectedCount), Identifer: key, AccountName: accountName, JobId: jobId}
			msg, _ := json.Marshal(flockMsg)
			log.Printf(string(msg))
			// SendFlockMessage(string(msg))
			allMatching = false
		}
	}
	return allMatching
}

func areCountsInOrder(uploadedCount int64, reflectedCount int64) bool {
	if (uploadedCount >= reflectedCount) && (reflectedCount >= ((100-diffPercentage)*uploadedCount)/100) {
		return true
	}
	return false
}
