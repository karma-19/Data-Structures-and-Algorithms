package service

import (
	"data-sanity-alerting/config"
	"encoding/json"
	"fmt"

	log "github.com/sirupsen/logrus"
)

type StatusBean struct {
	Summary  string `json:"summary"`
	JobId    int    `json:"jobId"`
	JobRunId int    `json:"jobRunId"`
}

func SendProcessStatus(messageList []map[string]interface{}, notifierName string, jobIdentifier JobIdentifier) {
	jsonString, err := json.Marshal(messageList)
	if err != nil {
		log.Error(fmt.Sprintf("Status message Error: %s", err))
		return
	}
	statusMessage := StatusBean{Summary: string(jsonString), JobId: jobIdentifier.JobId, JobRunId: jobIdentifier.JobRunId}
	body, _ := json.Marshal(statusMessage)
	response := postApiCall(config.ConfigStruct.NotifierConfigs[notifierName].TriggerUrl, body)
	log.Info(fmt.Sprintf("Status message: %s called for pipeline: %s with response: %s", notifierName, jobIdentifier.PipelineName, string(response)))
}
