package service

import (
	"data-sanity-alerting/config"
	"errors"
	"fmt"
	"sync"
	"time"

	log "github.com/sirupsen/logrus"
)

var RwMutex sync.RWMutex

type JobIdentifier struct {
	PipelineName string            `json:"JobName"`
	JobId        int               `json:"JobId"`
	JobRunId     int               `json:"JobRunId"`
	TimeSlot     map[string]string `json:"TimeSlot"`
	StartTime    time.Time
	EndTime      time.Time
}

func (ji *JobIdentifier) populateTime() error {
	startTimeStr, ok := ji.TimeSlot["min"]
	if !ok {
		return fmt.Errorf("missing 'min' key in TimeSlot map")
	}

	endTimeStr, ok := ji.TimeSlot["max"]
	if !ok {
		return fmt.Errorf("missing 'max' key in TimeSlot map")
	}

	startTime, err := time.Parse(time.RFC3339, startTimeStr)
	if err != nil {
		return fmt.Errorf("failed to parse StartTime: %v", err)
	}

	endTime, err := time.Parse(time.RFC3339, endTimeStr)
	if err != nil {
		return fmt.Errorf("failed to parse EndTime: %v", err)
	}

	ji.StartTime = startTime
	ji.EndTime = endTime

	return nil
}

func StartPipeline(jobIdentifier JobIdentifier, inputParams interface{}) {
	err := jobIdentifier.populateTime()
	if err != nil {
		log.Error(fmt.Sprintf("Error while populating time for job Identifier : %s", err.Error()))
	}
	var pipelineConfig config.PipelineConfig = config.ConfigStruct.PipelineConfigs[jobIdentifier.PipelineName]
	result := make([]map[string]interface{}, 0)
	responseList := make([]map[string]interface{}, 0)
	SendProcessStatus(result, "start-status", jobIdentifier)
	switch data := inputParams.(type) {
	case map[string]interface{}:
		data, err := FormatInput(pipelineConfig.PipilineInputConfig, data)
		if err != nil {
			log.Error(fmt.Sprintf("Error %s when Formatting inputs\n", err))
			data["status"] = false
			responseList = append(responseList, data)
		} else {
			partialResult, err := getAlertResponse(pipelineConfig, data)
			if err != nil {
				data["status"] = false
				responseList = append(responseList, data)
			} else {
				data["status"] = true
				responseList = append(responseList, data)
				result = append(result, partialResult...)
			}
		}
	case []interface{}:
		ipList := make([]map[string]interface{}, 0)
		groupedIpList := make([]map[string]interface{}, 0)
		ipIndexList := make([][]int, 0)
		for _, ip := range data {
			mapIp, _ := ip.(map[string]interface{})
			mapIp, err := FormatInput(pipelineConfig.PipilineInputConfig, mapIp)
			if err != nil {
				log.Error(fmt.Sprintf("Error %s when Formatting inputs\n", err))
				mapIp["status"] = false
				responseList = append(responseList, mapIp)
			} else {
				ipList = append(ipList, mapIp)
			}
		}
		if pipelineConfig.PipilineInputConfig.InputGroupingConfig.IsEnabled {
			groupedIpList, ipIndexList = GetGroupedInput(ipList, pipelineConfig.PipilineInputConfig.InputGroupingConfig)
		} else {
			groupedIpList = ipList
			for i := 0; i < len(groupedIpList); i++ {
				ipIndexList = append(ipIndexList, []int{i})
			}
		}

		for idx, ip := range groupedIpList {
			partialResult, err := getAlertResponse(pipelineConfig, ip)
			if err == nil {
				result = append(result, partialResult...)
				for _, ipIdx := range ipIndexList[idx] {
					ipList[ipIdx]["status"] = true
					responseList = append(responseList, ipList[ipIdx])
				}
			} else {
				for _, ipIdx := range ipIndexList[idx] {
					ipList[ipIdx]["status"] = false
					responseList = append(responseList, ipList[ipIdx])
				}
			}
		}
	}
	result = SortAlerts(result, pipelineConfig.SortConfigs)
	PushAlerts(result, pipelineConfig.AlertDestinations, jobIdentifier)
	SendProcessStatus(responseList, "end-status", jobIdentifier)
}

func getAlertResponse(pipelineConfig config.PipelineConfig, inputParams map[string]interface{}) ([]map[string]interface{}, error) {
	result := make([]map[string]interface{}, 0)
	sourceResultsMap := make(map[string][]map[string]interface{})
	var dataSourceWaitGroup sync.WaitGroup

	sourceResultChan := make(chan struct {
		sourceName string
		results    []map[string]interface{}
		err        error
	})
	var sourceNameMap map[string]string = make(map[string]string)

	// Launch goroutine for each string
	for name, dbConfig := range pipelineConfig.DataSourceConfigs {
		sourceNameMap[name] = dbConfig.PrintName
		dataSourceWaitGroup.Add(1)
		go func(sourceName string, dbConfig config.PipelineDatasourceConfig, pipelineConfig config.PipelineConfig, inputParams map[string]interface{}) {
			defer dataSourceWaitGroup.Done()
			RwMutex.RLock()
			defer RwMutex.RUnlock()
			results, err := getDbResponse(dbConfig, pipelineConfig.PipilineInputConfig, inputParams, sourceName)
			sourceResultChan <- struct {
				sourceName string
				results    []map[string]interface{}
				err        error
			}{sourceName: sourceName, results: results, err: err}
		}(name, dbConfig, pipelineConfig, inputParams)
	}

	// Wait for all goroutines to finish
	go func() {
		dataSourceWaitGroup.Wait()
		close(sourceResultChan)
	}()

	// Process results from channels
	for result := range sourceResultChan {
		if result.err == nil {
			sourceResultsMap[result.sourceName] = result.results
			if len(result.results) == 0 {
				log.Warn(fmt.Sprintf("Data Source %s returned 0 rows after filtering", pipelineConfig.DataSourceConfigs[result.sourceName].Name))
			}
		} else {
			log.Error(fmt.Sprintf("Error for %s: %s\n", result.sourceName, result.err.Error()))
		}
	}
	if len(sourceResultsMap) != pipelineConfig.DatasourceCount {
		log.Error("No. of source results do not match")
		err := errors.New("No. of source results do not match")
		return result, err
	}
	// perform grouping for comparisons
	metricsMap, hashResultMap := GetDimensionMap(sourceResultsMap, pipelineConfig.ComparisonConfig)
	// enrich message
	result = EnrichResults(metricsMap, sourceResultsMap, hashResultMap, pipelineConfig.AdditionalLoggingParams, pipelineConfig.ComparisonConfig.Dimensions, sourceNameMap)
	// check alert criteia
	result = GetAlertingList(result, pipelineConfig.AlertCriteria, sourceNameMap)
	return result, nil
}

func getDbResponse(dataSourceConfig config.PipelineDatasourceConfig, inputConfig config.PipelineInputConfig, inputParams map[string]interface{}, sourceName string) ([]map[string]interface{}, error) {
	//TODO: handle panic
	switch dataSourceConfig.Type {
	case "sql":
		return GetSQLSourceResponse(dataSourceConfig, inputConfig, inputParams, sourceName)
	case "analytics":
		return GetAnalyticsSourceResponse(dataSourceConfig, inputConfig, inputParams, sourceName)
	case "bq":
		return GetBQSourceResponse(dataSourceConfig, inputConfig, inputParams, sourceName)
	default:
		result := make([]map[string]interface{}, 0)
		log.Error(fmt.Sprintf("Unknown datasource type %s", dataSourceConfig.Type))
		err := errors.New("unknown data-source type")
		return result, err
	}
}
