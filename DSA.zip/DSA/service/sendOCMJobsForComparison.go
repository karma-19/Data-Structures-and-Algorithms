package service

import "data-sanity-alerting/dao"

func StartOCMComparison() {
	jobs := dao.GetActiveJobs()
	for _, job := range jobs {
		if job.Source_id == "" {
			CompareConversions(job.Account_id, "NULL", job.Account_name, job.Id)
		} else {
			CompareConversions(job.Account_id, job.Source_id, job.Account_name, job.Id)
		}
	}
}
