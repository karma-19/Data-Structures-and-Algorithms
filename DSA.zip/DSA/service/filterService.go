package service

import (
	"data-sanity-alerting/config"
	"data-sanity-alerting/utils"
	"fmt"
	"strconv"

	log "github.com/sirupsen/logrus"
)

func FilterArray(array []map[string]interface{}, filterConfig config.FilterConfig, sourceNameMap map[string]string) []map[string]interface{} {
	var filtered []map[string]interface{}
	for _, item := range array {
		if filter(item, filterConfig, sourceNameMap) {
			filtered = append(filtered, item)
		}
	}
	return filtered
}

func GetAlertingList(array []map[string]interface{}, filterConfig config.FilterConfig, sourceNameMap map[string]string) []map[string]interface{} {
	var filtered []map[string]interface{}
	for _, item := range array {
		if filter(item, filterConfig, sourceNameMap) {
			filtered = append(filtered, item)
		}
	}
	return filtered
}

func filter(inputData map[string]interface{}, filterConfig config.FilterConfig, sourceNameMap map[string]string) bool {
	expressionValue := true
	for sumTermIndex := 0; sumTermIndex < filterConfig.AndTermCount && expressionValue; sumTermIndex++ {
		expressionValue = evaluateOrTerms(inputData, filterConfig.Expression["and-term-"+strconv.Itoa(sumTermIndex+1)], sourceNameMap)
	}
	return expressionValue
}

func evaluateOrTerms(inputData map[string]interface{}, orTermConfigMap map[string]config.OrTermConfig, sourceNameMap map[string]string) bool {
	expressionValue := false
	for _, value := range orTermConfigMap {
		expressionValue = expressionValue || evaluateTerm(inputData, value, sourceNameMap)
	}
	return expressionValue
}

func evaluateTerm(inputData map[string]interface{}, orTermConfig config.OrTermConfig, sourceNameMap map[string]string) bool {
	operand1, err := getOperand(inputData, orTermConfig.Term1, sourceNameMap)
	if err != nil {
		log.Error(err)
		return false
	}
	operand2, err := getOperand(inputData, orTermConfig.Term2, sourceNameMap)
	if err != nil {
		log.Error(err)
		return false
	}
	expressionValue, err := utils.Compare(operand1, operand2, orTermConfig.Operator)
	if err != nil {
		log.Error(err)
		return false
	}
	return expressionValue
}

func getOperand(inputData map[string]interface{}, termConfig config.TermConfig, sourceNameMap map[string]string) (interface{}, error) {
	var operand interface{}
	if termConfig.IsLiteral {
		operand, contains := getData(inputData, termConfig, sourceNameMap)
		if !contains {
			operand = utils.ConvertType(termConfig.Type, termConfig.Value)
		} else if utils.IsNumeric(operand) && termConfig.Multiplier != 1.0 {
			multipliedOperand, err := utils.Multiply(operand, termConfig.Multiplier)
			if err != nil {
				log.Error(err)
				return nil, err
			}
			operand = multipliedOperand
		}
		return operand, nil
	} else {
		operand = utils.ConvertType(termConfig.Type, termConfig.Value)
		return operand, nil
	}
}

func getData(inputData map[string]interface{}, termConfig config.TermConfig, sourceNameMap map[string]string) (interface{}, bool) {
	metricName := termConfig.MetricName
	if termConfig.Source != "" {
		sourcePrintName, isPresent := sourceNameMap[termConfig.Source]
		if !isPresent {
			log.Error(fmt.Sprintf("Unknown source identifier %s present in filter config\n", termConfig.Source))
		} else {
			metricName = termConfig.MetricName + "_" + sourcePrintName
		}
	}
	val, ok := inputData[metricName]
	return val, ok
}
