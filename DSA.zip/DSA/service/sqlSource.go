package service

import (
	"data-sanity-alerting/config"
	"data-sanity-alerting/utils"
	"database/sql"
	"fmt"
	"sync"

	log "github.com/sirupsen/logrus"
)

var DbMap sync.Map

func getSQLConnection(sourceName string, driverName string, dataSourceName string) (*sql.DB, error) {
	db, ok := DbMap.Load(sourceName)
	if ok && db != nil {
		log.Info(fmt.Sprintf("reusing DB for %s", sourceName))
		return db.(*sql.DB), nil
	}
	dbCon, err := sql.Open(driverName, dataSourceName)
	if err != nil {
		log.Error(fmt.Sprintf("Error while creating DB connection : %s %s", sourceName, err.Error()))
		return nil, err
	}
	DbMap.Store(sourceName, dbCon)
	return dbCon, nil
}

func GetSQLSourceResponse(dataSourceConfig config.PipelineDatasourceConfig, inputConfig config.PipelineInputConfig, inputParams map[string]interface{}, sourceIdentifier string) ([]map[string]interface{}, error) {
	sourceName := dataSourceConfig.Name
	sourceNameMap := map[string]string{
		sourceIdentifier: dataSourceConfig.PrintName,
	}
	result := make([]map[string]interface{}, 0)
	dbCon, err := getSQLConnection(sourceName, config.ConfigStruct.ConnectionConfigs.SqlConnection[sourceName].DriverClassName, utils.GetSqlDsn(sourceName))

	if err != nil {
		log.Error(fmt.Sprintf("Error %s when opening DB\n", err))
		return result, err
	}
	result, err = getSpOutput(dataSourceConfig, inputConfig, inputParams, dbCon)

	if err != nil {
		log.Error(fmt.Sprintf("Error %s when running SP\n", err))
		return result, err
	}
	result = FilterArray(result, dataSourceConfig.FilterConfig, sourceNameMap)
	return result, nil
}

func getSpOutput(dataSourceConfig config.PipelineDatasourceConfig, inputConfig config.PipelineInputConfig, inputParams map[string]interface{}, dbCon *sql.DB) ([]map[string]interface{}, error) {
	//create sp
	spString := utils.GetModifiedSpString(dataSourceConfig, inputConfig, inputParams)
	log.Info(spString)
	result := make([]map[string]interface{}, 0)
	rows, err := dbCon.Query(spString)
	if err != nil {
		log.Error(err)
		return result, err
	}
	defer rows.Close()
	columns, _ := rows.Columns()
	count := len(columns)
	values := make([]interface{}, count)
	valuePtr := make([]interface{}, count)

	for rows.Next() {
		for i, _ := range columns {
			valuePtr[i] = &values[i]
		}
		rows.Scan(valuePtr...)
		columnToValue := map[string]interface{}{}
		for i, col := range columns {
			val := values[i]
			if data, ok := val.([]uint8); ok {
				columnToValue[col] = string(data)
			} else {
				columnToValue[col] = val
			}
		}
		result = append(result, columnToValue)
	}

	return result, nil
}

func SQLRefresh() error {
	DbMap.Range(func(key, value interface{}) bool {
		db, ok := value.(*sql.DB)
		if !ok {
			return false // Skip non-*sql.DB values
		}
		err := db.Close()
		if err != nil {
			return false
		}

		DbMap.Delete(key)
		return true
	})

	return nil
}
