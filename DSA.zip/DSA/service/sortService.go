package service

import (
	"data-sanity-alerting/config"
	"data-sanity-alerting/utils"
	"sort"
)

func SortAlerts(alertMessage []map[string]interface{}, sortConfigs []config.SortConfig) []map[string]interface{} {
	if len(sortConfigs) == 0 {
		return alertMessage
	}

	// Define a custom sorting function
	sort.Slice(alertMessage, func(i, j int) bool {
		for _, sortConfig := range sortConfigs {
			val1, ok1 := alertMessage[i][sortConfig.Name]
			val2, ok2 := alertMessage[j][sortConfig.Name]
			//handle null values, null values are kept at bottom
			if !ok1 && !ok2 {
				return true
			} else if !ok1 {
				return false
			} else if !ok2 {
				return true
			}
			modifiedVal1 := utils.ConvertType(sortConfig.Type, val1)
			modifiedVal2 := utils.ConvertType(sortConfig.Type, val2)

			if modifiedVal1 != modifiedVal2 {
				if sortConfig.Direction == "asc" {
					comp, _ := utils.Compare(modifiedVal1, modifiedVal2, "lt")
					return comp
				} else {
					comp, _ := utils.Compare(modifiedVal1, modifiedVal2, "gt")
					return comp
				}
			}
		}
		return true
	})

	return alertMessage
}
