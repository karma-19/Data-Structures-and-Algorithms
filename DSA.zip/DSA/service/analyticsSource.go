package service

import (
	"data-sanity-alerting/config"
	"data-sanity-alerting/utils"
	"encoding/json"
	"errors"
	"fmt"

	log "github.com/sirupsen/logrus"
)

type AnalyticsResponseBean struct {
	Data         []map[string]interface{} `json:"data"`
	ResponseCode int                      `json:"responseCode"`
}

func GetAnalyticsSourceResponse(dataSourceConfig config.PipelineDatasourceConfig, inputConfig config.PipelineInputConfig, inputParams map[string]interface{}, sourceIdentifier string) ([]map[string]interface{}, error) {
	sourceName := dataSourceConfig.Name
	sourceNameMap := map[string]string{
		sourceIdentifier: dataSourceConfig.PrintName,
	}
	result := make([]map[string]interface{}, 0)
	spString := utils.GetModifiedSpString(dataSourceConfig, inputConfig, inputParams)
	log.Info(spString)
	response := postApiCallWithHeaders(config.ConfigStruct.ConnectionConfigs.AnalyticsConnection[sourceName].Url, []byte(spString), config.ConfigStruct.ConnectionConfigs.AnalyticsConnection[sourceName].Headers)
	if len(response) == 0 {
		errorMessage := fmt.Sprintf("Error while accessing analytics with: %s", spString)
		log.Error(errorMessage)
		return result, errors.New(errorMessage)
	}
	var responseData AnalyticsResponseBean
	err := json.Unmarshal(response, &responseData)
	if err != nil {
		log.Error("Error unmarshaling JSON:", err)
		return result, err
	} else if responseData.ResponseCode != 200 {
		errorMessage := "non-200 response from analytics API"
		log.Error(errorMessage)
		return result, errors.New(errorMessage)
	} else if len(responseData.Data) == 0 {
		log.Warn(fmt.Sprintf("Empty Data from analytics: %s", response))
	}
	result = FilterArray(responseData.Data, dataSourceConfig.FilterConfig, sourceNameMap)
	return result, nil
}
