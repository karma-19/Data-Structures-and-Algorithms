package service

import (
	"data-sanity-alerting/config"
	"data-sanity-alerting/utils"
	"fmt"

	log "github.com/sirupsen/logrus"
)

func GetDimensionMap(resultsMap map[string][]map[string]interface{}, comparisonConfig config.ComparisonConfig) (map[uint32]map[string]map[string]interface{}, map[uint32]map[string][]int) {
	metricsMap := make(map[uint32]map[string]map[string]interface{})   // hash -> metric_name -> source_name -> value
	hashResultIndexSet := make(map[uint32]map[string]map[int]struct{}) // hash -> source_name -> index -> struct{}
	hashResultMap := make(map[uint32]map[string][]int)                 // hash -> source_name -> array of indices
	for metricName, sourceResultConf := range comparisonConfig.Metrics.Details {
		for sourceName, colConfig := range sourceResultConf {
			for index, result := range resultsMap[sourceName] {
				hash := createHash(result, sourceName, comparisonConfig.Dimensions)
				val, ok := metricsMap[hash][metricName][sourceName]
				if !ok {
					if metricsMap[hash] == nil {
						metricsMap[hash] = make(map[string]map[string]interface{})
					}
					if metricsMap[hash][metricName] == nil {
						metricsMap[hash][metricName] = make(map[string]interface{})
					}
				}
				metricsMap[hash][metricName][sourceName] = getUpdatedMetricValue(result, val, colConfig)
				if _, ok := hashResultIndexSet[hash]; !ok {
					hashResultIndexSet[hash] = make(map[string]map[int]struct{})
				}
				if _, ok := hashResultIndexSet[hash][sourceName]; !ok {
					hashResultIndexSet[hash][sourceName] = make(map[int]struct{})
				}
				hashResultIndexSet[hash][sourceName][index] = struct{}{}
			}
		}
	}
	// Populate hashResultMap based on hashResultIndexSet
	for hash, sourceVal := range hashResultIndexSet {
		hashResultMap[hash] = make(map[string][]int)
		for source, indexMap := range sourceVal {
			intArray := make([]int, 0, len(indexMap))
			for index := range indexMap {
				intArray = append(intArray, index)
			}
			hashResultMap[hash][source] = intArray
		}
	}
	return metricsMap, hashResultMap

}

func GetGroupedInput(inputParamsList []map[string]interface{}, inputGroupingConfig config.InputGroupingConfig) ([]map[string]interface{}, [][]int) {
	metricsMap := make(map[uint32]map[string]interface{}) // hash -> input_param_name -> value
	hashToIndexList := make(map[uint32][]int, 0)          // hash -> list of input indices
	for idx, inputParams := range inputParamsList {
		dimensionMap := make(map[string]interface{})
		for _, fieldName := range inputGroupingConfig.Dimensions {
			val, isPresent := inputParams[fieldName]
			if !isPresent {
				dimensionMap[fieldName] = ""
			} else {
				dimensionMap[fieldName] = val
			}
		}
		hash := utils.HashMap(dimensionMap)
		_, isPresent := metricsMap[hash]
		if !isPresent {
			metricsMap[hash] = dimensionMap
			hashToIndexList[hash] = make([]int, 0)
		}
		hashToIndexList[hash] = append(hashToIndexList[hash], idx)
		for metricName, colConfig := range inputGroupingConfig.Metrics {
			oldValue := metricsMap[hash][metricName]
			metricsMap[hash][metricName] = getUpdatedMetricValue(inputParams, oldValue, colConfig)
		}
	}
	inputIndexList := make([][]int, 0)
	groupedInput := make([]map[string]interface{}, 0)
	for hash, input := range metricsMap {
		inputIndexList = append(inputIndexList, hashToIndexList[hash])
		groupedInput = append(groupedInput, input)
	}
	return groupedInput, inputIndexList
}

func createHash(resultObj map[string]interface{}, sourceName string, dimensions map[string]map[string]config.ColumnConfig) uint32 {
	return utils.HashMap(createDimensionMap(resultObj, sourceName, dimensions))
}

func createDimensionMap(resultObj map[string]interface{}, sourceName string, dimensions map[string]map[string]config.ColumnConfig) map[string]interface{} {
	dimensionMap := make(map[string]interface{})
	for fieldName, sourceCol := range dimensions {
		colConfig := sourceCol[sourceName]
		value, isPresent := resultObj[colConfig.Name]
		if !isPresent {
			dimensionMap[fieldName] = ""
		} else {
			dimensionMap[fieldName] = utils.GetColumnValue(value, colConfig)
		}
	}
	return dimensionMap
}

func getUpdatedMetricValue(resultObj map[string]interface{}, oldValue interface{}, colConfig config.ColumnConfig) interface{} {
	var value interface{}
	if colConfig.Name != "" {
		val, isPresent := resultObj[colConfig.Name]
		if isPresent {
			val = utils.GetColumnValue(val, colConfig)
		}
		value = interface{}(val)
	}
	updatedValue := utils.Aggregate(oldValue, value, colConfig.Operation)
	if updatedValue == nil {
		log.Error(fmt.Sprintf("Obtained null after aggregate operation: %s, old: %v new: %v", colConfig.Operation, oldValue, value))
	}
	return updatedValue
}
