package service

import (
	"data-sanity-alerting/config"
	"data-sanity-alerting/utils"
	"fmt"

	log "github.com/sirupsen/logrus"
)

func EnrichResults(alertingMetrics map[uint32]map[string]map[string]interface{}, sourceResults map[string][]map[string]interface{}, hashResultMap map[uint32]map[string][]int, loggingParamConfig map[string]config.LoggingParamConfig, dimensions map[string]map[string]config.ColumnConfig, sourceNameMap map[string]string) []map[string]interface{} {
	alertResults := make([]map[string]interface{}, 0)
	if len(alertingMetrics) == 0 {
		//Nothing to alert
		return alertResults
	}
	// alertingMetrics : hash -> metric_name -> source_name -> value
	// hashResultMap : hash -> source_name -> array of indices
	// sourceResults : source_name -> array of col_name -> value

	for hash, metricInfo := range alertingMetrics {
		genericResult := make(map[string]interface{})
		// append common metrics
		for metricName, sourceInfo := range metricInfo {
			for sourceName, value := range sourceInfo {
				keyName := metricName + "_" + sourceNameMap[sourceName]
				genericResult[keyName] = value
			}
		}
		// append common dimensions
		if sourceList, ok := hashResultMap[hash]; ok && len(sourceList) > 0 {
			var sourceName string
			for src, indices := range hashResultMap[hash] {
				if len(indices) > 0 {
					sourceName = src
					break
				}
			}
			diamensionMap := createDimensionMap(sourceResults[sourceName][hashResultMap[hash][sourceName][0]], sourceName, dimensions)
			for keyName, value := range diamensionMap {
				genericResult[keyName] = value
			}
		}

		sourceSpecificResultList := make([]map[string]interface{}, 0)
		sourceParamMap := make(map[string]map[string]string) // sourceName -> paramName -> colName
		isOneEntryPerSource := true
		for paramName, paramConf := range loggingParamConfig {
			if !paramConf.IsCalculated {
				// source specific param
				if len(paramConf.SourceList) != 1 {
					// for non calculated additional params, source should be singular
					log.Error(fmt.Sprintf("for non calculated additional param: %s, source should be singular", paramName))
					continue
				}
				if _, ok := sourceParamMap[paramConf.SourceList[0]]; !ok {
					sourceParamMap[paramConf.SourceList[0]] = make(map[string]string)
				}
				sourceParamMap[paramConf.SourceList[0]][paramName] = paramConf.Name
				if len(hashResultMap[hash][paramConf.SourceList[0]]) > 1 {
					isOneEntryPerSource = false
				}
			} else {
				genericResult[paramName] = utils.AggregateNTuple(utils.GetValuesFromMap(metricInfo[paramConf.Name], paramConf.SourceList), paramConf.Formula)
			}
		}
		// if sourceParamMap has entry for multiple sources, to avoid (n x m x p) alert rows, ensure all source entries have count exactly as 1
		if len(sourceParamMap) > 1 && !isOneEntryPerSource {
			log.Error("Unable to add alert rows")
		} else if len(sourceParamMap) > 1 {
			sourceSpecificResult := make(map[string]interface{})
			for sourceName, paramConf := range sourceParamMap {
				if len(hashResultMap[hash][sourceName]) == 1 {
					for paramName, colName := range paramConf {
						sourceSpecificResult[paramName] = sourceResults[sourceName][hashResultMap[hash][sourceName][0]][colName]
					}
				}
			}
			sourceSpecificResultList = append(sourceSpecificResultList, sourceSpecificResult)
		} else {
			for sourceName, paramConf := range sourceParamMap {
				for _, index := range hashResultMap[hash][sourceName] {
					sourceSpecificResult := make(map[string]interface{})
					for paramName, colName := range paramConf {
						sourceSpecificResult[paramName] = sourceResults[sourceName][index][colName]
					}
					sourceSpecificResultList = append(sourceSpecificResultList, sourceSpecificResult)
				}
			}
		}

		if len(sourceSpecificResultList) == 0 {
			alertResults = append(alertResults, genericResult)
		} else {
			for genKey, genVal := range genericResult {
				for index, _ := range sourceSpecificResultList {
					sourceSpecificResultList[index][genKey] = genVal
				}
			}
			for _, specificResult := range sourceSpecificResultList {
				alertResults = append(alertResults, specificResult)
			}
		}
	}
	return alertResults
}
