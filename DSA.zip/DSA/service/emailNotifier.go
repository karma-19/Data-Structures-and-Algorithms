package service

import (
	"bytes"
	"crypto/tls"
	"data-sanity-alerting/config"
	"data-sanity-alerting/utils"
	"math"
	"strings"
	"time"

	"encoding/csv"
	"fmt"
	"net/smtp"
	"os"

	log "github.com/sirupsen/logrus"
)

const (
	Subject          = "DSA : "
	EmailBody        = "Hi\n\nPFA CSV for "
	EmailBodyWithCSV = `
		<!DOCTYPE html>
		<html>
		<body>
			Hi<br>PFA CSV for %s<br>
			<br> %s <br>
			<table border="1" cellpadding="5" cellspacing="0">
				%s
			</table>
		</body>
		</html>
	`
	EmailFooter = `
		<!DOCTYPE html>
		<html>
		<body>
			<i>Job Run ID: %d </i>
		</body>
		</html>
	`
	EmailFooterWithCSV = "\n\nJob Run ID: %d"
)

func WriteToCsv(messageList []map[string]interface{}, notifierName string) {
	fileName := "abc.csv"
	file, err := os.Create(fileName)
	if err != nil {
		log.Error(fmt.Sprintf("Error: %s", err))
		return
	}
	defer file.Close()

	// Create a CSV writer
	writer := csv.NewWriter(file)
	defer writer.Flush()

	// Write the header row
	header := make([]string, 0)
	for _, message := range messageList {
		for key := range message {
			// Check if the key already exists in the header
			found := false
			for _, h := range header {
				if h == key {
					found = true
					break
				}
			}
			if !found {
				header = append(header, key)
			}
		}
	}
	if err := writer.Write(header); err != nil {
		log.Error(fmt.Sprintf("Error: %s", err))
		return
	}

	// Write the data rows
	for _, message := range messageList {
		row := make([]string, len(header))
		for i, key := range header {
			if value, ok := message[key]; ok {
				row[i] = fmt.Sprintf("%v", value)
			} else {
				row[i] = "" // Substitute empty string for missing keys
			}
		}
		if err := writer.Write(row); err != nil {
			log.Error(fmt.Sprintf("Error: %s", err))
			return
		}
	}
}

func SendEmailMessage(messageList []map[string]interface{}, notifierName string, jobIdentifier JobIdentifier, additionalMessage string) {
	if len(messageList) == 0 {
		log.Info("Empty message for email")
		return
	}

	// Headers
	headers := config.ConfigStruct.PipelineConfigs[jobIdentifier.PipelineName].ParamOrder

	tableRows := ""
	tableRow := "<tr>"
	for _, col := range headers {
		tableRow += "<th>" + col + "</th>"
	}
	tableRow += "</tr>"
	tableRows += tableRow

	for _, message := range messageList {
		tableRow := "<tr>"
		for _, header := range headers {
			var colVal string
			if value, ok := message[header]; ok && value != nil {
				numVal, isNumeric := utils.ConvertToDouble(value)
				if isNumeric && numVal != math.Trunc(numVal) {
					rounded := math.Round(numVal*100) / 100
					colVal = fmt.Sprintf("%v", rounded)
				} else {
					colVal = fmt.Sprintf("%v", value)
				}
			} else {
				colVal = "" // Substitute empty string for missing keys
			}
			tableRow += "<td>" + colVal + "</td>"
		}
		tableRow += "</tr>"
		tableRows += tableRow
	}

	// Compose the email message
	message := utils.EmailMessage{
		Subject:          getEmailSubject(jobIdentifier),
		Body:             fmt.Sprintf(EmailBodyWithCSV, jobIdentifier.PipelineName, additionalMessage, tableRows),
		Attachments:      make(map[string][]byte),
		ExtraInformation: fmt.Sprintf(EmailFooter, jobIdentifier.JobRunId),
	}

	sendEmail(message, notifierName)
}

func SendEmailWithAttachment(messageList []map[string]interface{}, notifierName string, jobIdentifier JobIdentifier, additionalMessage string) {
	if len(messageList) == 0 {
		log.Info("Empty message for email")
		return
	}

	// Headers
	headers := config.ConfigStruct.PipelineConfigs[jobIdentifier.PipelineName].ParamOrder

	// Create a buffer to store the CSV data
	csvBuffer := new(bytes.Buffer)

	// Create a CSV writer
	csvWriter := csv.NewWriter(csvBuffer)

	// Write the headers to the CSV file
	csvWriter.Write(headers)

	// Write the data rows to the CSV file
	for _, message := range messageList {
		row := make([]string, len(headers))
		for i, header := range headers {
			if value, ok := message[header]; ok && value != nil {
				numVal, isNumeric := utils.ConvertToDouble(value)
				if isNumeric && numVal != math.Trunc(numVal) {
					rounded := math.Round(numVal*100) / 100
					row[i] = fmt.Sprintf("%v", rounded)
				} else {
					row[i] = fmt.Sprintf("%v", value)
				}
			} else {
				row[i] = "" // Substitute empty string for missing keys
			}
		}
		csvWriter.Write(row)
	}

	// Flush any buffered data to ensure all rows are written
	csvWriter.Flush()

	// Check for any error while writing CSV data
	if err := csvWriter.Error(); err != nil {
		log.Error(fmt.Sprintf("Failed to write CSV data: %v", err))
		return
	}

	// Compose the email message
	message := utils.EmailMessage{
		Subject:          getEmailSubject(jobIdentifier),
		Body:             EmailBody + jobIdentifier.PipelineName + "\n" + additionalMessage,
		Attachments:      make(map[string][]byte),
		ExtraInformation: fmt.Sprintf(EmailFooterWithCSV, jobIdentifier.JobRunId),
	}
	message.Attachments[jobIdentifier.PipelineName+"_"+jobIdentifier.StartTime.Format("20060102150405")+".csv"] = csvBuffer.Bytes()
	// msg := createMessage(senderEmail, recipientEmails, "CSV Data", "Please find attached CSV data.", csvBuffer.Bytes())

	sendEmail(message, notifierName)
}

func getEmailSubject(jobIdentifier JobIdentifier) string {
	// Calculate the duration between start time and end time
	duration := jobIdentifier.EndTime.Sub(jobIdentifier.StartTime)
	var subject string
	if config.ConfigStruct.Profile == "production" {
		subject = Subject + config.ConfigStruct.PipelineConfigs[jobIdentifier.PipelineName].Name + " - "
	} else {
		subject = Subject + utils.CapitalizeFirstLetter(config.ConfigStruct.Profile) + " : " + config.ConfigStruct.PipelineConfigs[jobIdentifier.PipelineName].Name + " - "
	}
	// Check if the duration is less than or equal to 1 hour
	if jobIdentifier.PipelineName == "kcr_star_regex_alerts" {
		subject = subject + jobIdentifier.StartTime.Format("2006-01-02") + " UTC"
	} else if duration <= time.Hour {
		subject = subject + jobIdentifier.StartTime.Format("2006-01-02 15") + " UTC"
	} else {
		subject = subject + jobIdentifier.StartTime.Format("2006-01-02 15") + " to " + jobIdentifier.EndTime.Format("2006-01-02 15") + " UTC"
	}
	return subject
}

func createMessage(from string, to []string, subject, body string, attachment []byte) *bytes.Buffer {
	header := fmt.Sprintf("From: %s\r\n"+
		"To: %s\r\n"+
		"Subject: %s\r\n"+
		"MIME-Version: 1.0\r\n"+
		"Content-Type: multipart/mixed; boundary=boundary\r\n"+
		"\r\n"+
		"--boundary\r\n"+
		"Content-Type: text/plain; charset=utf-8\r\n"+
		"\r\n"+
		"%s\r\n"+
		"\r\n"+
		"--boundary\r\n"+
		"Content-Type: text/csv\r\n"+
		"Content-Disposition: attachment; filename=data.csv\r\n"+
		"\r\n", from, strings.Join(to, ","), subject, body)

	var msg bytes.Buffer
	msg.Write([]byte(header))
	msg.Write(attachment)
	msg.Write([]byte("\r\n--boundary--\r\n"))

	return &msg
}

func sendEmail(message utils.EmailMessage, notifierName string) {
	// SMTP configuration
	smtpConnName, _ := utils.ConvertToString(config.ConfigStruct.NotifierConfigs[notifierName].Parameters["connection_name"])

	smtpHost, _ := utils.ConvertToString(config.ConfigStruct.ConnectionConfigs.EmailConnection[smtpConnName].Host)
	smtpPort, _ := utils.ConvertToString(config.ConfigStruct.ConnectionConfigs.EmailConnection[smtpConnName].Port)
	senderEmail, _ := utils.ConvertToString(config.ConfigStruct.ConnectionConfigs.EmailConnection[smtpConnName].Sender)
	senderUsername, _ := utils.ConvertToString(config.ConfigStruct.ConnectionConfigs.EmailConnection[smtpConnName].Username)
	senderPassword, _ := utils.ConvertToString(config.ConfigStruct.ConnectionConfigs.EmailConnection[smtpConnName].Password)
	// Recipient emails
	recipientEmails, _ := utils.ConvertToStringSlice(config.ConfigStruct.NotifierConfigs[notifierName].Parameters["target_email"])
	message.To = recipientEmails
	// Create the authentication
	auth := smtp.PlainAuth("", senderUsername, senderPassword, smtpHost)

	// Send the email
	tlsconfig := &tls.Config{
		ServerName: smtpHost,
	}

	client, err := smtp.Dial(smtpHost + ":" + smtpPort)
	if err != nil {
		log.Error(err)
		return
	}
	client.StartTLS(tlsconfig)

	// step 1: Use Auth
	if err = client.Auth(auth); err != nil {
		log.Error(err)
		return
	}
	client.Mail(senderEmail)
	for i := 0; i < len(message.To); i++ {
		client.Rcpt(message.To[i])
	}
	writer, _ := client.Data()
	_, err = writer.Write(message.ToBytes())
	writer.Close()

	if err != nil {
		log.Error(fmt.Sprintf("Failed to send email: %v", err))
		return
	}

	connectionCloseError := client.Quit()
	if connectionCloseError != nil {
		log.Error(fmt.Sprintf("Failed to send email: %v", err))
		return
	}

	log.Info("Email sent successfully")
}
