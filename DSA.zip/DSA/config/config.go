package config

import (
	"os"

	log "github.com/sirupsen/logrus"
	"github.com/spf13/viper"
)

type Config struct {
	Profile           string                    `mapstructure:"profile"`
	NotifierConfigs   map[string]NotifierConfig `mapstructure:"notifiers"`
	ConnectionConfigs ConnectionConfig          `mapstructure:"connections"`
	PipelineConfigs   map[string]PipelineConfig `mapstructure:"sanity-check-pipelines"`
}

type NotifierConfig struct {
	Type       string                 `mapstructure:"type"`
	Parameters map[string]interface{} `mapstructure:"additional-param"`
	TriggerUrl string                 `mapstructure:"url"`
}

type ConnectionConfig struct {
	SqlConnection       map[string]SqlConnectionConfig       `mapstructure:"sql"`
	AnalyticsConnection map[string]AnalyticsConnectionConfig `mapstructure:"analytics"`
	VogonConnection     map[string]map[string]string         `mapstructure:"vogon"`
	EmailConnection     map[string]SmtpConnectionConfig      `mapstructure:"email"`
	BQConnection        map[string]BQConnectionConfig        `mapstructure:"bq"`
}

type PipelineInputConfig struct {
	IsArray             bool                      `mapstructure:"is-array"`
	ArgumentCount       int                       `mapstructure:"argument-count"`
	ArgumentConfigs     map[string]ArgumentConfig `mapstructure:"arguments"`
	InputGroupingConfig InputGroupingConfig       `mapstructure:"group-by"`
}

type InputGroupingConfig struct {
	IsEnabled  bool                    `mapstructure:"enabled"`
	Dimensions []string                `mapstructure:"dimensions"`
	Metrics    map[string]ColumnConfig `mapstructure:"metrics"`
}

type ArgumentConfig struct {
	Name   string `mapstructure:"name"`
	Type   string `mapstructure:"type"`
	Source string `mapstructure:"source"`
	Param  string `mapstructure:"param"`
	Format string `mapstructure:"format"`
}

type PipelineDatasourceConfig struct {
	Name              string            `mapstructure:"name"`
	PrintName         string            `mapstructure:"print-name"`
	Type              string            `mapstructure:"type"`
	Sp                string            `mapstructure:"sp"`
	SpInputTimeFormat string            `mapstructure:"sp-input-time-format"`
	FilterConfig      FilterConfig      `mapstructure:"filtering"`
	InnerSp           map[string]string `mapstructure:"inner-sp"`
}

type FilterConfig struct {
	AndTermCount int                                `mapstructure:"and-terms"`
	Expression   map[string]map[string]OrTermConfig `mapstructure:"expression"`
}

type OrTermConfig struct {
	Term1    TermConfig `mapstructure:"term1"`
	Term2    TermConfig `mapstructure:"term2"`
	Operator string     `mapstructure:"operator"`
}

type TermConfig struct {
	IsLiteral  bool    `mapstructure:"literal,default=true"`
	MetricName string  `mapstructure:"metric"`
	Type       string  `mapstructure:"type"`
	Source     string  `mapstructure:"source"`
	Value      string  `mapstructure:"value"`
	Multiplier float64 `mapstructure:"multiplier,default=1.0"`
}

type ColumnConfig struct {
	Name              string `mapstructure:"name"`
	Type              string `mapstructure:"type"`
	TargetType        string `mapstructure:"convert-to"`
	DestinationFormat string `mapstructure:"format"`
	SourceFormat      string `mapstructure:"source-format"`
	Operation         string `mapstructure:"operation"`
}

type MetricConfig struct {
	Count   int                                `mapstructure:"count"`
	Details map[string]map[string]ColumnConfig `mapstructure:"details"`
}

type ComparisonConfig struct {
	Dimensions map[string]map[string]ColumnConfig `mapstructure:"dimensions"`
	Metrics    MetricConfig                       `mapstructure:"metrics"`
}

type AlertDestinationCriteriaConfig struct {
	Criteria     map[string]interface{} `mapstructure:"criteria"`
	Notifiers    []string               `mapstructure:"notifier"`
	Consolidated bool                   `mapstructure:"consolidated"`
	Message      string                 `mapstructure:"message"`
}

type LoggingParamConfig struct {
	Name         string   `mapstructure:"name"`
	Type         string   `mapstructure:"type"`
	SourceList   []string `mapstructure:"source"`
	IsCalculated bool     `mapstructure:"is-calculated"`
	Formula      string   `mapstructure:"formula"`
}

type PipelineConfig struct {
	Name                    string                                    `mapstructure:"name"`
	IsActive                bool                                      `mapstructure:"is-active"`
	PipilineInputConfig     PipelineInputConfig                       `mapstructure:"pipeline-input"`
	DatasourceCount         int                                       `mapstructure:"datasource-count"`
	DataSourceConfigs       map[string]PipelineDatasourceConfig       `mapstructure:"datasources"`
	ComparisonConfig        ComparisonConfig                          `mapstructure:"comparison"`
	AdditionalLoggingParams map[string]LoggingParamConfig             `mapstructure:"additional-logging-info"`
	AlertCriteria           FilterConfig                              `mapstructure:"alert-criteria"`
	AlertDestinations       map[string]AlertDestinationCriteriaConfig `mapstructure:"alert-destinations"`
	ParamOrder              []string                                  `mapstructure:"output-param-order"`
	SortConfigs             []SortConfig                              `mapstructure:"sort-config"`
}

type SortConfig struct {
	Name      string `mapstructure:"name"`
	Type      string `mapstructure:"type"`
	Direction string `mapstructure:"direction"`
}

type SqlConnectionConfig struct {
	Url             string `mapstructure:"url"`
	Database        string `mapstructure:"database"`
	Username        string `mapstructure:"username"`
	Password        string `mapstructure:"password"`
	DriverClassName string `mapstructure:"driverClassName"`
}

type AnalyticsConnectionConfig struct {
	Url     string            `mapstructure:"url"`
	Type    string            `mapstructure:"type"`
	Headers map[string]string `mapstructure:"headers"`
}

type SmtpConnectionConfig struct {
	Host     string `mapstructure:"smtp_host"`
	Port     string `mapstructure:"smtp_port"`
	Username string `mapstructure:"smtp_username"`
	Password string `mapstructure:"smtp_password"`
	Sender   string `mapstructure:"email_sender"`
}

type BQConnectionConfig struct {
	Type                        string `mapstructure:"type"`
	Project_id                  string `mapstructure:"project_id"`
	Private_key_id              string `mapstructure:"private_key_id"`
	Private_key                 string `mapstructure:"private_key"`
	Client_email                string `mapstructure:"client_email"`
	Client_id                   string `mapstructure:"client_id"`
	Auth_uri                    string `mapstructure:"auth_uri"`
	Token_uri                   string `mapstructure:"token_uri"`
	Auth_provider_x509_cert_url string `mapstructure:"auth_provider_x509_cert_url"`
	Client_x509_cert_url        string `mapstructure:"client_x509_cert_url"`
}

type DependenciesConfig struct {
	ConnectionType string            `mapstructure:"connection-type"`
	ConnectionName string            `mapstructure:"connection-name"`
	RequestData    map[string]string `mapstructure:"request-data"`
	ResponseData   map[string]string `mapstructure:"response-data"`
}

var ConfigStruct Config

func (c *Config) populate() *Config {
	profile := os.Args[1]
	viper.SetConfigName("creds-file")
	viper.AddConfigPath("./var/www/common/")
	viper.SetConfigType("yaml")
	if err := viper.ReadInConfig(); err != nil {
		log.Printf("yamlFile.Get err #%v ", err)
	}
	var genericConfig Config
	if err := viper.Unmarshal(&genericConfig); err != nil {
		log.Printf("yamlFile.Get err #%v ", err)
	}

	viper.SetConfigName(profile)
	viper.AddConfigPath("./")
	viper.SetConfigType("yaml")
	if err := viper.MergeInConfig(); err != nil {
		log.Printf("yamlFile.Get err   #%v ", err)
	}

	if err := viper.Unmarshal(c); err != nil {
		log.Printf("yamlFile.Get err   #%v ", err)
	}
	mergeConfigs(c, &genericConfig)
	return c
}

func mergeConfigs(dst, src *Config) {
	dst.ConnectionConfigs = src.ConnectionConfigs
}

func init() {
	ConfigStruct.populate()
}

func Refresh() {
	ConfigStruct.populate()
}
