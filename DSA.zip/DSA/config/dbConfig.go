package config

// type dbConfig struct {
// 	Url             string `yaml:"url"`
// 	Database        string `yaml:"database"`
// 	Username        string `yaml:"username"`
// 	Password        string `yaml:"password"`
// 	DriverClassName string `yaml:"driverClassName"`
// }

// type dataSourceConfig struct {
// 	Job    dbConfig `yaml:"job"`
// 	SemArb dbConfig `yaml:"sem-arb"`
// }

// type conf struct {
// 	Datasource dataSourceConfig `yaml:"datasource"`
// 	FlockAPI   string           `yaml:"flockApi"`
// }

// var Config conf

// func (c *conf) populate() *conf {

// 	yamlFile, err := ioutil.ReadFile("application.yaml")
// 	if err != nil {
// 		log.Printf("yamlFile.Get err   #%v ", err)
// 	}
// 	err = yaml.Unmarshal(yamlFile, c)
// 	if err != nil {
// 		log.Fatalf("Unmarshal: %v", err)
// 	}

// 	return c
// }

// func init() {
// 	Config.populate()
// }
