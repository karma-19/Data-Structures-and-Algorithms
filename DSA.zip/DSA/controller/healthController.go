package controller

import (
	"net/http"

	"github.com/gorilla/mux"
)

func HealthCheckHandler(w http.ResponseWriter, r *http.Request) {
	w.WriteHeader(http.StatusOK)
}

func registerHealthCheckHandler(r *mux.Router) {
	r.HandleFunc("/health", HealthCheckHandler)
}
