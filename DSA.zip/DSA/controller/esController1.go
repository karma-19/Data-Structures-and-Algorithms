package controller

// import (
// 	"bytes"
// 	"context"
// 	"encoding/json"
// 	"fmt"
// 	"log"
// 	"net/http"
// 	"time"

// 	"github.com/elastic/go-elasticsearch/esapi"
// 	"github.com/elastic/go-elasticsearch/v7"
// 	"github.com/gorilla/mux"
// )

// type Response struct {
// 	Took         int                  `json:"took"`
// 	TimedOut     bool                 `json:"timed_out"`
// 	Shards       ShardsResponse       `json:"_shards"`
// 	Hits         HitsResponse         `json:"hits"`
// 	Aggregations AggregationsResponse `json:"aggregations"`
// }

// type ShardsResponse struct {
// 	Total      int `json:"total"`
// 	Successful int `json:"successful"`
// 	Skipped    int `json:"skipped"`
// 	Failed     int `json:"failed"`
// }

// type HitsResponse struct {
// 	Total    TotalResponse `json:"total"`
// 	MaxScore interface{}   `json:"max_score"`
// 	Hits     []interface{} `json:"hits"`
// }

// type TotalResponse struct {
// 	Value    int    `json:"value"`
// 	Relation string `json:"relation"`
// }

// type AggregationsResponse struct {
// 	GroupByField GroupByFieldResponse `json:"group_by_field"`
// }

// type GroupByFieldResponse struct {
// 	DocCountErrorUpperBound int              `json:"doc_count_error_upper_bound"`
// 	SumOtherDocCount        int              `json:"sum_other_doc_count"`
// 	Buckets                 []BucketResponse `json:"buckets"`
// }

// type BucketResponse struct {
// 	Key      string `json:"key"`
// 	DocCount int    `json:"doc_count"`
// }

// func esHandler(w http.ResponseWriter, r *http.Request) {
// 	fmt.Println("In ES")
// 	value := _getDataFromES("2024-03-05")
// 	fmt.Print(value)
// 	w.WriteHeader(http.StatusOK)
// }

// func _getDataFromES(date string) map[string]int {
// 	response := make(map[string]int)
// 	parsedDate, err := time.Parse("2006-01-02", date)
// 	if err != nil {
// 		fmt.Println(err)
// 		return response
// 	}
// 	nextDate := parsedDate.AddDate(0, 0, 1)

// 	startTime := parsedDate.Format("2006-01-02T15:04:05.000Z")
// 	endTime := nextDate.Format("2006-01-02T15:04:05.000Z")

// 	esURL := "https://sem-es7-common-kibana.internal.media.net"
// 	index := "logs-app.conversion-api-admin" //Config

// 	query := map[string]interface{}{
// 		"size":             0,
// 		"track_total_hits": true,
// 		"query": map[string]interface{}{
// 			"bool": map[string]interface{}{
// 				"must": []map[string]interface{}{
// 					{
// 						"match_all": map[string]interface{}{},
// 					},
// 					{
// 						"range": map[string]interface{}{
// 							"@timestamp": map[string]interface{}{
// 								"gte": startTime,
// 								"lt":  endTime,
// 							},
// 						},
// 					},
// 				},
// 				"filter": []map[string]interface{}{
// 					{
// 						"term": map[string]interface{}{
// 							"application.response_status": "success",
// 						},
// 					},
// 				},
// 			},
// 		},
// 		"aggs": map[string]interface{}{
// 			"group_by_field": map[string]interface{}{
// 				"terms": map[string]interface{}{
// 					"field": "application.job_id",
// 					"size":  4000,
// 				},
// 			},
// 		},
// 	}

// 	queryJSON, err := json.Marshal(query)
// 	if err != nil {
// 		log.Fatal(err)
// 	}

// 	// Create the Elasticsearch request
// 	req := esapi.SearchRequest{
// 		Index: []string{index},
// 		Body:  bytes.NewReader(queryJSON),
// 	}

// 	// Create the Elasticsearch client with authentication
// 	esCfg := elasticsearch.Config{
// 		Addresses: []string{esURL},
// 		Username:  "kibana-ro",
// 		Password:  "incEsANE",
// 	}

// 	es, err := elasticsearch.NewClient(esCfg)
// 	if err != nil {
// 		log.Fatal(err)
// 	}

// 	// Send the request to Elasticsearch
// 	res, err := req.Do(context.Background(), es)
// 	if err != nil {
// 		log.Fatal(err)
// 	}
// 	defer res.Body.Close()

// 	// Check the response status
// 	if res.IsError() {
// 		log.Fatalf("Error response: %s", res.Status())
// 	}

// 	// Parse and print the response
// 	var buf bytes.Buffer
// 	if _, err := buf.ReadFrom(res.Body); err != nil {
// 		log.Fatal(err)
// 	}

// 	fmt.Println(buf.String())

// 	var result Response
// 	json.Unmarshal([]byte(buf.String()), &result)
// 	fmt.Println(result.Hits.Total.Value)
// 	for _, bucket := range result.Aggregations.GroupByField.Buckets {
// 		response[bucket.Key] = bucket.DocCount
// 	}

// 	result1 := make([]map[string]interface{}, 0)
// 	for _, bucket := range result.Aggregations.GroupByField.Buckets {
// 		columnToValue := map[string]interface{}{}
// 		columnToValue["job_id"] = bucket.Key
// 		columnToValue["total_uploaded_conversion"] = bucket.DocCount
// 		result1 = append(result1, columnToValue)
// 		response[bucket.Key] = bucket.DocCount
// 	}

// 	fmt.Println(result1)
// 	return response
// }

// func registerEsHandler(r *mux.Router) {
// 	r.HandleFunc("/es", esHandler)
// }

// //Connection Class like db
// //
