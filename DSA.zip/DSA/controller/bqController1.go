package controller

import (
	"context"
	"data-sanity-alerting/config"
	"encoding/json"
	"fmt"
	"net/http"

	"cloud.google.com/go/bigquery"
	"github.com/gorilla/mux"
	"google.golang.org/api/iterator"
	"google.golang.org/api/option"
)

func bqHandler(w http.ResponseWriter, r *http.Request) {
	fmt.Println("In BQ")
	_getDataFromBq()
	w.WriteHeader(http.StatusOK)
}

func _getDataFromBq() {
	ctx := context.Background()
	projectId := "titanium-production"
	creds := config.ConfigStruct.ConnectionConfigs.BQConnection["titanium-production"]
	credentialsJSON, err := json.Marshal(creds)
	// keywa, err := ioutil.ReadFile("/Users/anshu/Desktop/Projects/DSA/On_O.json")

	// credentialsFile := "/Users/anshu/Desktop/Projects/DSA/On_O.json"
	// Create a BigQuery client
	client, err := bigquery.NewClient(ctx, projectId, option.WithCredentialsJSON(credentialsJSON))
	if err != nil {
		fmt.Println("Error creating BigQuery client:", err)
		return
	}
	defer client.Close()

	// Define your BigQuery query
	query := "SELECT count(*) as impressions FROM `titanium_realtime.titanium_impressions_realtime` WHERE _PARTITIONTIME = '2024-04-23' AND utc_hour=15 GROUP BY utc_date, utc_hour"

	queryJob := client.Query(query)

	q, err := queryJob.Read(ctx)
	if err != nil {
		fmt.Println("Error reading query results:", err)
		return
	}

	// Iterate through query results
	for {
		var row map[string]bigquery.Value
		err := q.Next(&row)
		if err == iterator.Done {
			break
		}
		if err != nil {
			fmt.Println("Error reading next row:", err)
			return
		}
		// Process the row data
		fmt.Println(row)
	}
}

func registerBqHandler(r *mux.Router) {
	r.HandleFunc("/bq", bqHandler)
}
