package controller

import (
	"data-sanity-alerting/service"
	"encoding/json"
	"net/http"

	"github.com/gorilla/mux"
)

type PipelineTriggerRequestData struct {
	service.JobIdentifier
	Data interface{} `json:"LookupResponse"`
}

type ResponseData struct {
	Message string `json:"message"`
}

// AddPipelineTriggerHandler handles the POST request for adding data
func AddPipelineTriggerHandler(w http.ResponseWriter, r *http.Request) {
	// Decode the request body
	var requestData PipelineTriggerRequestData
	err := json.NewDecoder(r.Body).Decode(&requestData)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}
	isActive := service.IsPipelineActive(requestData.PipelineName)
	if !isActive {
		// Return a message
		responseData := ResponseData{Message: "Pipeline is inactive"}
		json.NewEncoder(w).Encode(responseData)
		return
	}
	isValid := service.ValidateInput(requestData.PipelineName, requestData.Data)
	if !isValid {
		http.Error(w, "Invalid data format", http.StatusBadRequest)
		return
	}
	go service.StartPipeline(requestData.JobIdentifier, requestData.Data)
	// Return a success message
	responseData := ResponseData{Message: "Pipeline triggered successfully"}
	json.NewEncoder(w).Encode(responseData)
}

// RegisterHandlers registers the HTTP handlers for the controller
func RegisterHandlers(r *mux.Router) {
	registerHealthCheckHandler(r)
	registerPipelineHandlers(r)
	registerRefreshHandler(r)
	registerBqHandler(r)
}

func registerPipelineHandlers(r *mux.Router) {
	r.HandleFunc("/pipeline/start", AddPipelineTriggerHandler).Methods(http.MethodPost)
}
