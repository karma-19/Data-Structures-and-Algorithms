package controller

import (
	"data-sanity-alerting/config"
	"data-sanity-alerting/service"
	"encoding/json"
	"net/http"

	log "github.com/sirupsen/logrus"

	"github.com/gorilla/mux"
)

func RefreshHandler(w http.ResponseWriter, r *http.Request) {
	var err error
	log.Info("Connection refresh initiated")
	service.RwMutex.Lock()
	defer service.RwMutex.Unlock()
	config.Refresh()
	err = service.SQLRefresh()
	if err != nil {
		service.RwMutex.Unlock()
		log.Fatal(err)
	}
	log.Info("Connection refresh completed")
	responseData := ResponseData{Message: "Connections refreshed successfully"}
	json.NewEncoder(w).Encode(responseData)
}

func registerRefreshHandler(r *mux.Router) {
	r.HandleFunc("/refresh", RefreshHandler).Methods(http.MethodPost)
}
