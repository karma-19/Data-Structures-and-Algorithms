package utils

import (
	"data-sanity-alerting/config"
	"fmt"
	"math"
	"reflect"
	"regexp"
	"strconv"
	"time"

	log "github.com/sirupsen/logrus"
)

const (
	IntTypeEnum    = "int"
	StringTypeEnum = "string"
	BoolTypeEnum   = "bool"
	TimeTypeEnum   = "time"
	DoubleTypeEnum = "double"
)

var TypeMapping = map[string][]interface{}{
	IntTypeEnum:    {int(0), int8(0), int16(0), int32(0), int64(0), uint(0), uint8(0), uint16(0), uint32(0), uint64(0)},
	StringTypeEnum: {""},
	BoolTypeEnum:   {true, false},
	TimeTypeEnum:   {time.Now()},
	DoubleTypeEnum: {float32(0), float64(0)},
}

func GetColumnValue(value interface{}, colConfig config.ColumnConfig) interface{} {
	if value == nil {
		return ""
	} else if colConfig.TargetType == "" {
		return value
	} else if colConfig.Type == TimeTypeEnum {
		if colConfig.SourceFormat != "" {
			var err error
			value, err = time.Parse(colConfig.SourceFormat, value.(string))
			if err != nil {
				log.Error("Error parsing time:", err)
				return ""
			}
		}
		return ConvertType(colConfig.TargetType, value.(time.Time).Format(colConfig.DestinationFormat))
	} else if colConfig.TargetType == TimeTypeEnum {
		val, _ := time.Parse(colConfig.DestinationFormat, ConvertType(StringTypeEnum, value).(string))
		return val
	} else if colConfig.Type == StringTypeEnum && colConfig.DestinationFormat != "" {
		re := regexp.MustCompile(colConfig.DestinationFormat)
		match := re.FindStringSubmatch(value.(string))
		if len(match) < 2 {
			return ""
		}
		return match[1]
	} else {
		return ConvertType(StringTypeEnum, value)
	}
}

func GetEnumType(value interface{}) string {
	valueType := reflect.TypeOf(value).String()

	for enumType, possibleTypes := range TypeMapping {
		for _, possibleType := range possibleTypes {
			if reflect.TypeOf(possibleType).String() == valueType {
				return enumType
			}
		}
	}

	return ""
}

func ConvertType(typeEnum string, value interface{}) interface{} {
	switch typeEnum {
	case IntTypeEnum:
		convertedValue, ok := value.(int)
		if ok {
			return convertedValue
		} else {
			doubleVal, ok := ConvertToDouble(value)
			if ok {
				return int(doubleVal)
			}
			return nil
		}
	case DoubleTypeEnum:
		convertedValue, ok := value.(float64)
		if ok {
			return convertedValue
		} else {
			doubleVal, ok := ConvertToDouble(value)
			if ok {
				return doubleVal
			}
			return nil
		}
	case StringTypeEnum:
		convertedValue, ok := value.(string)
		if ok {
			return convertedValue
		} else {
			convertedValue = fmt.Sprintf("%v", value)
			return convertedValue
		}
	case BoolTypeEnum:
		convertedValue, ok := value.(bool)
		if ok {
			return convertedValue
		} else {
			strVal, ok := value.(string)
			if ok {
				bVal, err := strconv.ParseBool(strVal)
				if err == nil {
					return bVal
				}
			}
			return nil
		}
	case TimeTypeEnum:
		convertedValue, ok := value.(time.Time)
		if ok {
			return convertedValue
		} else {
			return nil
		}
	default:
		return nil
	}
}

func ConvertToString(value interface{}) (string, error) {
	if str, ok := value.(string); ok {
		return str, nil
	}
	return "", fmt.Errorf("unable to convert %v to string", value)
}

func ConvertToInt(value interface{}) (int, error) {
	if num, ok := value.(int); ok {
		return num, nil
	}
	return 0, fmt.Errorf("unable to convert %v to int", value)
}

func ConvertToStringSlice(data interface{}) ([]string, error) {
	if dataSlice, ok := data.([]interface{}); ok {
		strSlice := make([]string, len(dataSlice))
		for i, v := range dataSlice {
			str, err := ConvertToString(v)
			if err == nil {
				strSlice[i] = str
			} else {
				return nil, fmt.Errorf("unable to convert element at index %d to string", i)
			}
		}
		return strSlice, nil
	}
	return nil, fmt.Errorf("unable to convert %v to []string", data)
}

func IsNumeric(value interface{}) bool {
	switch data := value.(type) {
	case int, int8, int16, int32, int64, uint, uint8, uint16, uint32, uint64, float32, float64:
		return true
	case string:
		_, err := strconv.ParseFloat(data, 64)
		if err == nil {
			return true
		} else {
			return false
		}
	default:
		return false
	}
}

func ConvertToOriginalType(value interface{}) (interface{}, error) {
	originalType := reflect.TypeOf(value)

	if originalType.Kind() != reflect.Ptr {
		originalType = originalType.Elem()
	}

	convertedValue := reflect.New(originalType).Interface()

	if reflect.TypeOf(convertedValue).AssignableTo(originalType) {
		reflect.ValueOf(convertedValue).Elem().Set(reflect.ValueOf(value))
		return convertedValue, nil
	}

	return nil, fmt.Errorf("unsupported type: %T", value)
}

func Multiply(value interface{}, multiplier float64) (float64, error) {
	v, ok := ConvertToDouble(value)
	if !ok {
		return 0.0, fmt.Errorf("unsupported type: %T", value)
	}
	return v * multiplier, nil
}

func Compare(value1, value2 interface{}, operator string) (bool, error) {
	switch operator {
	case "eq":
		return isEqual(value1, value2)
	case "neq":
		return isNotEqual(value1, value2)
	case "lt":
		return isLessThan(value1, value2)
	case "gt":
		return isGreaterThan(value1, value2)
	case "lte":
		return isLessThanOrEqual(value1, value2)
	case "gte":
		return isGreaterThanOrEqual(value1, value2)
	default:
		return false, fmt.Errorf("unsupported operator: %s", operator)
	}
}

func Aggregate(aggregate, value interface{}, operator string) interface{} {
	if aggregate == nil {
		if operator == "count" {
			return 1
		} else if operator != "diff_percentage" {
			return value
		}
	}
	switch operator {
	case "sum":
		return sum(aggregate, value)
	case "min":
		return min(aggregate, value)
	case "max":
		return max(aggregate, value)
	case "count":
		return aggregate.(int) + 1
	case "diff_percentage":
		return diffPercentage(aggregate, value)
	case "comma_concat":
		return concatenate(aggregate, value, ",")
	case "abs_diff":
		return absDiff(aggregate, value)
	default:
		return nil // Handle unsupported operator
	}

}

func AggregateNTuple(valuesList []interface{}, operator string) interface{} {
	if len(valuesList) == 0 {
		return nil
	}
	result := valuesList[0]
	for i := 1; i < len(valuesList); i++ {
		value1 := result
		value2 := valuesList[i]
		result = Aggregate(value1, value2, operator)
	}
	return result
}

func sum(val1, val2 interface{}) interface{} {
	if IsNumeric(val1) {
		convertedVal1, _ := ConvertToDouble(val1)
		convertedVal2, _ := ConvertToDouble(val2)
		return convertedVal1 + convertedVal2
	}
	switch v1 := val1.(type) {
	case time.Time:
		return v1.Add(toDuration(val2))
	default:
		return nil // Handle unsupported types
	}
}

func absDiff(val1, val2 interface{}) interface{} {
	if IsNumeric(val1) && IsNumeric(val2) {
		convertedVal1, _ := ConvertToDouble(val1)
		convertedVal2, _ := ConvertToDouble(val2)
		diff := (convertedVal1 - convertedVal2)
		if diff < 0 {
			return -diff
		}
		return diff
	}
	return nil
}

func concatenate(val1, val2 interface{}, delimiter string) interface{} {
	if val1 == nil && val2 == nil {
		return ""
	} else if val1 == nil {
		return val2
	} else if val2 == nil {
		return val1
	}
	convertedVal1, _ := ConvertToString(ConvertType(StringTypeEnum, val1))
	convertedVal2, _ := ConvertToString(ConvertType(StringTypeEnum, val2))
	return convertedVal1 + delimiter + convertedVal2
}

func diffPercentage(val1, val2 interface{}) interface{} {
	if val1 == nil && val2 == nil {
		return 0
	} else if val1 == nil {
		return -100
	} else if val2 == nil {
		return 100
	}
	if !IsNumeric(val1) || !IsNumeric(val2) {
		return nil
	}
	convertedVal1, _ := ConvertToDouble(val1)
	convertedVal2, _ := ConvertToDouble(val2)
	diff := (convertedVal1 - convertedVal2)
	if diff == 0.0 {
		return 0.0
	} else if convertedVal2 == 0.0 {
		return 100.0
	}
	diff = (diff / convertedVal2) * 100
	return diff
}

func min(val1, val2 interface{}) interface{} {
	if IsNumeric(val1) {
		convertedVal1, _ := ConvertToDouble(val1)
		convertedVal2, _ := ConvertToDouble(val2)
		return math.Min(convertedVal1, convertedVal2)
	}
	switch v1 := val1.(type) {
	case time.Time:
		if toTime(val2).Before(v1) {
			return toTime(val2)
		}
		return val1
	default:
		return nil
	}
}

func max(val1, val2 interface{}) interface{} {
	if IsNumeric(val1) {
		convertedVal1, _ := ConvertToDouble(val1)
		convertedVal2, _ := ConvertToDouble(val2)
		return math.Max(convertedVal1, convertedVal2)
	}
	switch v1 := val1.(type) {
	case time.Time:
		if toTime(val2).After(v1) {
			return toTime(val2)
		}
		return val1
	default:
		return nil
	}
}

func toTime(val interface{}) time.Time {
	switch v := val.(type) {
	case time.Time:
		return v
	default:
		return time.Time{}
	}
}

func toDuration(val interface{}) time.Duration {
	switch v := val.(type) {
	case time.Duration:
		return v
	default:
		return 0
	}
}

func isEqual(value1, value2 interface{}) (bool, error) {
	switch v1 := value1.(type) {
	case string:
		if v2, ok := value2.(string); ok {
			return v1 == v2, nil
		}
	case time.Time:
		if v2, ok := value2.(time.Time); ok {
			return v1.Equal(v2), nil
		}
	}
	num1, isNumeric1 := ConvertToDouble(value1)
	num2, isNumeric2 := ConvertToDouble(value2)
	if isNumeric1 && isNumeric2 {
		return num1 == num2, nil
	}
	return false, fmt.Errorf("unsupported types for equality comparison")
}

func isNotEqual(value1, value2 interface{}) (bool, error) {
	equal, err := isEqual(value1, value2)
	if err != nil {
		return false, err
	}
	return !equal, nil
}

func isLessThan(value1, value2 interface{}) (bool, error) {
	switch v1 := value1.(type) {
	case time.Time:
		if v2, ok := value2.(time.Time); ok {
			return v1.Before(v2), nil
		}
	}
	num1, isNumeric1 := ConvertToDouble(value1)
	num2, isNumeric2 := ConvertToDouble(value2)
	if isNumeric1 && isNumeric2 {
		return num1 < num2, nil
	}
	switch v1 := value1.(type) {
	case string:
		if v2, ok := value2.(string); ok {
			return v1 < v2, nil
		}
	}
	return false, fmt.Errorf("unsupported types for less than comparison")
}

func isGreaterThan(value1, value2 interface{}) (bool, error) {
	switch v1 := value1.(type) {
	case time.Time:
		if v2, ok := value2.(time.Time); ok {
			return v1.After(v2), nil
		}
	}
	num1, isNumeric1 := ConvertToDouble(value1)
	num2, isNumeric2 := ConvertToDouble(value2)
	if isNumeric1 && isNumeric2 {
		return num1 > num2, nil
	}
	switch v1 := value1.(type) {
	case string:
		if v2, ok := value2.(string); ok {
			return v1 > v2, nil
		}
	}
	return false, fmt.Errorf("unsupported types for greater than comparison")
}

func isLessThanOrEqual(value1, value2 interface{}) (bool, error) {
	lessThan, err := isLessThan(value1, value2)
	if err != nil {
		return false, err
	}
	isEqual, err := isEqual(value1, value2)
	if err != nil {
		return false, err
	}
	return lessThan || isEqual, nil
}

func isGreaterThanOrEqual(value1, value2 interface{}) (bool, error) {
	greaterThan, err := isGreaterThan(value1, value2)
	if err != nil {
		return false, err
	}
	isEqual, err := isEqual(value1, value2)
	if err != nil {
		return false, err
	}
	return greaterThan || isEqual, nil
}

func ConvertToDouble(value interface{}) (float64, bool) {
	if IsNumeric(value) {
		v := reflect.ValueOf(value)
		switch v.Kind() {
		case reflect.Int, reflect.Int8, reflect.Int16, reflect.Int32, reflect.Int64:
			return float64(v.Int()), true
		case reflect.Uint, reflect.Uint8, reflect.Uint16, reflect.Uint32, reflect.Uint64:
			return float64(v.Uint()), true
		case reflect.Float32, reflect.Float64:
			return v.Float(), true
		}
	}
	v, ok := value.(string)
	if ok {
		if len(v) == 0 {
			return 0.0, true
		}
		converted, err := strconv.ParseFloat(v, 64)
		if err == nil {
			return converted, true
		}
	}
	return 0.0, false
}

func GetTypeName(value interface{}) string {
	// Get the type of the value
	valueType := reflect.TypeOf(value)

	// Check if the type is a named type (not an interface or pointer)
	if valueType.Kind() != reflect.Ptr && valueType.Kind() != reflect.Interface {
		return valueType.String()
	}

	// If the value is a pointer or interface, get the underlying type
	return reflect.TypeOf(value).Elem().String()
}
