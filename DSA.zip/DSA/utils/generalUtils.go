package utils

import (
	"fmt"
	"hash/fnv"
	"sort"
	"strings"

	log "github.com/sirupsen/logrus"
)

var B2i = map[bool]int64{false: 0, true: 1}

func PanicOnErr(err error) {
	if err != nil {
		log.Error(err)
		panic(err.Error())
	}
}

func GetDiffPercentage(count1 int64, count2 int64) float64 {
	if count1 == count2 {
		return 0
	}
	if count1 == 0 {
		return -100
	}
	return (float64(count1-count2) * 100.0) / float64(count1)
}

func HashMap(m map[string]interface{}) uint32 {
	// Sort the keys
	var keys []string
	for k := range m {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	// Create a new FNV-1a hash object
	hash := fnv.New32a()

	// Iterate over the sorted keys and hash the key-value pairs
	for _, k := range keys {
		v := m[k]
		hash.Write([]byte(k))
		valueString := fmt.Sprintf("%v", v)
		hash.Write([]byte(valueString))
	}

	// Get the final hash value
	return hash.Sum32()
}

func GetValuesFromMap(inputMap map[string]interface{}, sourceList []string) []interface{} {
	values := make([]interface{}, 0, len(inputMap))

	for _, source := range sourceList {
		if value, isPresent := inputMap[source]; isPresent {
			values = append(values, value)
		} else {
			values = append(values, nil)
		}
	}

	return values
}

func CapitalizeFirstLetter(input string) string {
	if input == "" {
		return input
	}

	firstLetter := strings.ToUpper(input[:1])
	restOfString := input[1:]

	return firstLetter + restOfString
}

func ReorderParams(messageList []map[string]interface{}, headers []string) []map[string]interface{} {
	// populate the headers list
	headerMap := make(map[string]bool)
	for _, header := range headers {
		if _, isPresent := headerMap[header]; !isPresent {
			headerMap[header] = true
		}
	}

	for _, message := range messageList {
		for key := range message {
			// Check if the key already exists in the header
			if _, isPresent := headerMap[key]; !isPresent {
				headers = append(headers, key)
				headerMap[key] = true
			}
		}
	}
	//reorder map
	reorderedList := make([]map[string]interface{}, len(messageList))

	for i, msg := range messageList {
		reorderedMsg := make(map[string]interface{})
		for _, header := range headers {
			reorderedMsg[header] = msg[header]
		}
		reorderedList[i] = reorderedMsg
	}

	return reorderedList
}
