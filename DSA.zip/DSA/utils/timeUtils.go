package utils

import "time"

func TruncateMinutes(dateTime time.Time) time.Time {
	newTime := time.Date(dateTime.Year(), dateTime.Month(), dateTime.Day(), dateTime.Hour(), 0, 0, 0, dateTime.Location())
	return newTime
}
