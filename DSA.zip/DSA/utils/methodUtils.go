package utils

type MethodCallerStruct struct {
}

//Implement methods here
// func (m MethodCallerStruct) GetAbc() string {}
