package utils

import (
	"context"
	"data-sanity-alerting/config"
	"encoding/json"
	"fmt"
	"strings"
	"time"

	"cloud.google.com/go/bigquery"
	"google.golang.org/api/option"
)

func GetSqlDsn(connectionName string) string {
	if config.ConfigStruct.ConnectionConfigs.SqlConnection[connectionName].DriverClassName == "mysql" {
		return mySQLDsn(connectionName)
	} else if config.ConfigStruct.ConnectionConfigs.SqlConnection[connectionName].DriverClassName == "mssql" {
		return msSQLDsn(connectionName)
	} else {
		return ""
	}
}

func mySQLDsn(connectionName string) string {
	return fmt.Sprintf("%s:%s@tcp(%s)/%s", config.ConfigStruct.ConnectionConfigs.SqlConnection[connectionName].Username, config.ConfigStruct.ConnectionConfigs.SqlConnection[connectionName].Password, config.ConfigStruct.ConnectionConfigs.SqlConnection[connectionName].Url, config.ConfigStruct.ConnectionConfigs.SqlConnection[connectionName].Database)
}

func msSQLDsn(connectionName string) string {
	return fmt.Sprintf("server=%s;database=%s;user id=%s;password=%s;", config.ConfigStruct.ConnectionConfigs.SqlConnection[connectionName].Url, config.ConfigStruct.ConnectionConfigs.SqlConnection[connectionName].Database, config.ConfigStruct.ConnectionConfigs.SqlConnection[connectionName].Username, config.ConfigStruct.ConnectionConfigs.SqlConnection[connectionName].Password)
}

func GetModifiedSpString(dataSourceConfig config.PipelineDatasourceConfig, inputConfig config.PipelineInputConfig, inputParams map[string]interface{}) string {
	spString := dataSourceConfig.Sp
	for _, arg := range inputConfig.ArgumentConfigs {
		placeholder := "%{" + arg.Name + "}%"
		var replacement string
		if arg.Type == TimeTypeEnum {
			replacement = inputParams[arg.Name].(time.Time).Format(dataSourceConfig.SpInputTimeFormat)
		} else {
			replacement = ConvertType(StringTypeEnum, inputParams[arg.Name]).(string)
		}
		spString = strings.Replace(spString, placeholder, replacement, -1)
	}
	for argName, argConf := range inputConfig.InputGroupingConfig.Metrics {
		placeholder := "%{" + argName + "}%"
		var replacement string
		if argConf.Type == TimeTypeEnum {
			replacement = inputParams[argName].(time.Time).Format(dataSourceConfig.SpInputTimeFormat)
		} else {
			replacement = ConvertType(StringTypeEnum, inputParams[argName]).(string)
		}
		spString = strings.Replace(spString, placeholder, replacement, -1)
	}
	return spString
}

func GetBQConnection(sourceName string) (*bigquery.Client, context.Context, error) {
	ctx := context.Background()
	projectId := "titanium-production"
	creds := config.ConfigStruct.ConnectionConfigs.BQConnection["titanium-production"]
	credentialsJSON, err := json.Marshal(creds)
	if err != nil {
		return nil, ctx, err
	}
	bqClient, err := bigquery.NewClient(ctx, projectId, option.WithCredentialsJSON(credentialsJSON))
	return bqClient, ctx, err
}
