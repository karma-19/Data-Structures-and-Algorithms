package main

import (
	"data-sanity-alerting/controller"
	"net/http"

	log "github.com/sirupsen/logrus"

	"github.com/gorilla/mux"
)

func init() {
	log.SetLevel(log.DebugLevel)
}

func main() {
	router := mux.NewRouter()
	controller.RegisterHandlers(router)

	// Create a new HTTP server and bind it to a specific address and port
	server := &http.Server{
		Addr:    ":8080",
		Handler: router,
	}

	// Start the server
	log.Fatal(server.ListenAndServe())
}
